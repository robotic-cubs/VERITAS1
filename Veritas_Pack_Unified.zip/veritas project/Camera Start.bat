@echo off
setlocal EnableExtensions
title VERITAS Start (launcher)

rem ======================================================================
rem  VERITAS - ONE-CLICK START: Backend + ONE AI window that runs 723image.pt
rem
rem  Double-click this file. It starts, each in its own window:
rem    1/2  Backend   (FastAPI on port 8000: the dashboard still needs it)
rem    2/2  AI camera (veritas_bridge.py loading veritas-cv-main\models\723image.pt). THIS window owns the physical camera.
rem  One model, one camera, one detection process: Leanbot, Plate and Pedestrian all come from 723image.pt.
rem  Before starting something it checks whether it is already running, so clicking twice does not start a second copy.
rem  After starting something it waits until that program really answers (no blind waiting).
rem
rem  Optional: drag a video file onto this .bat to test without a camera.
rem  The same file starts itself in the child windows (--run-backend / --run-ai).
rem ======================================================================

rem ---------- settings (the dashboard expects backend 8000 and video 8001: do not change those two) ----------
set "ROOT=%~dp0"
set "BACKEND_DIR=%ROOT%veritas-backend"
set "BRIDGE_DIR=%ROOT%veritas-bridge"
set "LOGDIR=%ROOT%logs"
set "CAMERA_ID=CAM-001"
set "LOCATION=Intersection A"
set "BACKEND_PORT=8000"
set "BRIDGE_PORT=8001"
set "MODEL=%ROOT%..\veritas-cv-main\models\723image.pt"

if /i "%~1"=="--run-backend"    goto :run_backend
if /i "%~1"=="--run-ai"         goto :run_ai

set "SRC=%~1"
set "S_BACKEND=not started"
set "S_AI=not started"

echo ============================================================
echo   VERITAS - starting Backend + AI camera (723image.pt)
echo   One camera, one model: Leanbot + Pedestrian.
echo ============================================================
echo.

where python >nul 2>&1
if errorlevel 1 (
  echo [X] Python was not found. Install Python 3.10 or newer and tick "Add python.exe to PATH", then double-click this file again.
  echo.
  pause
  exit /b 1
)
if not exist "%MODEL%" (
  echo [X] Model file not found: %MODEL%
  echo     723image.pt must be in veritas-cv-main\models, next to the "veritas project" folder.
  echo.
  pause
  exit /b 1
)
if not exist "%LOGDIR%" mkdir "%LOGDIR%"

rem ---------- step 1: get both Python environments ready (nothing is started yet) ----------
echo [1/3] Preparing the backend environment ...
call :prep_backend
if errorlevel 1 (
  echo [X] Could not prepare veritas-backend. Read the message above.
  pause
  exit /b 1
)
echo [2/3] Preparing the camera + AI environment. The first time can take several minutes (PyTorch is downloaded) ...
call :prep_bridge
if errorlevel 2 (
  echo.
  echo [X] No .env in veritas-bridge. Copy .env.phase0.example to .env and fill in INGEST_KEY and BACKEND_URL.
  echo     Nothing was started.
  pause
  exit /b 1
)
if errorlevel 1 (
  echo [X] Could not prepare veritas-bridge. Read the message above.
  pause
  exit /b 1
)
echo       Environments are ready.
echo.

rem ---------- step 2: backend ----------
echo [3/3] Starting the programs. Each opens in its own window - leave them open.
call :probe "http://127.0.0.1:%BACKEND_PORT%/api/health"
if not errorlevel 1 goto :backend_already
del "%LOGDIR%\backend.exit" >nul 2>&1
echo       1/2 Backend ...
start "VERITAS 1/2 Backend" cmd /k call "%~f0" --run-backend
call :wait_http "http://127.0.0.1:%BACKEND_PORT%/api/health" 90 "" "%LOGDIR%\backend.exit"
set "WRC=%errorlevel%"
set "S_BACKEND=RUNNING  http://127.0.0.1:%BACKEND_PORT%"
if "%WRC%"=="1" set "S_BACKEND=NOT READY - see the Backend window for the error"
if "%WRC%"=="2" set "S_BACKEND=FAILED - the Backend window shows why"
goto :ai
:backend_already
set "S_BACKEND=ALREADY RUNNING  http://127.0.0.1:%BACKEND_PORT% - not started a second time"
echo       1/2 Backend is already running, keeping it.

rem ---------- step 3: the AI (723image.pt, owns the camera) ----------
:ai
call :probe "http://127.0.0.1:%BRIDGE_PORT%/health"
if not errorlevel 1 goto :ai_already
del "%LOGDIR%\leanbot.exit" >nul 2>&1
echo       2/2 AI camera - 723image.pt ...
start "VERITAS 2/2 AI camera (723image.pt)" cmd /k call "%~f0" --run-ai "%SRC%"
call :wait_http "http://127.0.0.1:%BRIDGE_PORT%/health" 240 camera_ok "%LOGDIR%\leanbot.exit"
set "WRC=%errorlevel%"
set "S_AI=RUNNING  723image.pt loaded, camera is giving pictures"
if "%WRC%"=="1" set "S_AI=NOT READY - see the AI camera window for the error"
if "%WRC%"=="2" set "S_AI=FAILED - the AI camera window shows why  [camera plugged in? other programs closed? CAMERA= in veritas-bridge\.env]"
goto :summary
:ai_already
set "S_AI=ALREADY RUNNING  - not started a second time"
echo       2/2 The AI camera is already running, keeping it.

:summary
echo.
echo Summary
echo ------------------------------------------------------------
echo   Backend         : %S_BACKEND%
echo   AI (723image.pt): %S_AI%
echo ------------------------------------------------------------
echo   Camera id %CAMERA_ID%, location %LOCATION%.
echo   Open admin.html in your browser for the dashboard.
echo   To stop: press Q in the video window, or close the two VERITAS windows.
echo   Problems? Start Camera Start.bat again, it never starts a second copy of something that is already running.
echo.
pause
exit /b 0


rem ======================================================================
rem  Helpers
rem ======================================================================

:prep_backend
rem  Exactly what "Backend Start.bat" did before starting uvicorn.
setlocal
pushd "%BACKEND_DIR%" || exit /b 1
if not exist .venv python -m venv .venv
call .venv\Scripts\activate
pip install -q -r requirements.txt
if errorlevel 1 echo       [!] Could not check the backend packages - offline? Trying to start anyway.
if not exist .env echo INGEST_KEY=veritas%RANDOM%%RANDOM%%RANDOM%%RANDOM%> .env
popd
exit /b 0

:prep_bridge
rem  Exactly what the old "Camera Start.bat" did before starting the camera program.
setlocal
pushd "%BRIDGE_DIR%" || exit /b 1
if not exist .venv python -m venv .venv
call .venv\Scripts\activate
pip install -q -r requirements.txt
if errorlevel 1 echo       [!] Could not check the camera packages - offline? Trying to start anyway.
rem  723image.pt is a YOLO26 model: an old ultralytics cannot open it, so keep ultralytics current.
pip install -q -U ultralytics
if errorlevel 1 echo       [!] Could not update ultralytics - offline? Trying to start anyway.
pip install -q pygrabber easyocr >nul 2>&1
rem EasyOCR drags in opencv-python-headless, which has NO video window. Put the normal OpenCV back:
pip uninstall -y opencv-python-headless >nul 2>&1
pip install -q --force-reinstall --no-deps opencv-python >nul 2>&1
if not exist .env (
  popd
  exit /b 2
)
popd
exit /b 0

:probe
rem  %1 = URL. Returns 0 if something answers there within 2 seconds, otherwise 1.
call :wait_http "%~1" 2 "" ""
exit /b %errorlevel%

:wait_http
rem  %1 = URL   %2 = max seconds   %3 = JSON field that must be true (or "")   %4 = file that appears when the program has died (or "")
rem  Returns 0 = ready, 1 = timed out, 2 = the program died (its .exit file appeared).
powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='%~1'; $f='%~3'; $x='%~4'; $end=(Get-Date).AddSeconds(%~2); while((Get-Date) -lt $end){ if($x -ne '' -and (Test-Path -LiteralPath $x)){ exit 2 }; try{ $r=Invoke-WebRequest -Uri $u -UseBasicParsing -TimeoutSec 2; if($r.StatusCode -eq 200){ if($f -eq ''){ exit 0 }; $j=$r.Content | ConvertFrom-Json; if($j.$f -eq $true){ exit 0 } } }catch{}; Start-Sleep -Milliseconds 700 }; exit 1"
exit /b %errorlevel%


rem ======================================================================
rem  Child windows (this same file, started by the launcher above)
rem ======================================================================

:run_backend
title VERITAS 1/2 Backend - keep this window open
cd /d "%BACKEND_DIR%"
call .venv\Scripts\activate
echo.
echo Backend is starting on http://127.0.0.1:%BACKEND_PORT% . Leave this window open.
python -m uvicorn main:app --host 127.0.0.1 --port %BACKEND_PORT%
set "RC=%errorlevel%"
> "%LOGDIR%\backend.exit" echo %RC%
echo.
echo [BACKEND] stopped, exit code %RC%. Read the message above, fix it, then double-click Camera Start.bat again.
exit /b %RC%

:run_ai
title VERITAS 2/2 AI camera (723image.pt) - press Q in the video window to stop
cd /d "%BRIDGE_DIR%"
call .venv\Scripts\activate
set "SRC=%~2"
echo.
echo Model: %MODEL%
echo This window owns the physical camera and runs Leanbot + Pedestrian detection with that ONE model.
echo Plate text: the first time EasyOCR downloads its models, which takes a few minutes. The video keeps playing meanwhile.
echo.
if "%SRC%"=="" goto :ai_camera
python veritas_bridge.py --model "%MODEL%" --ocr --camera "%SRC%" --camera-id %CAMERA_ID% --location "%LOCATION%" --stream-port %BRIDGE_PORT%
goto :ai_done
:ai_camera
python veritas_bridge.py --model "%MODEL%" --ocr --camera-id %CAMERA_ID% --location "%LOCATION%" --stream-port %BRIDGE_PORT%
:ai_done
set "RC=%errorlevel%"
> "%LOGDIR%\leanbot.exit" echo %RC%
echo.
echo [AI] stopped, exit code %RC%. Read the message above, fix it, then double-click Camera Start.bat again.
exit /b %RC%
