"""Tests for veritas_identity.ObjectBook. Run:  python test_identity.py
The tracker output is SCRIPTED (confidence swings, ids that change, boxes with no id, dropouts, objects close together), so these
prove the duplicate-prevention LOGIC. They say nothing about how well ByteTrack or 723image.pt behave on your camera."""
import random
import sys
import time

from veritas_identity import ObjectBook, iou

DT = 1 / 6.0                       # the AI runs about 6 times a second
CONF_SWING = [0.75, 0.81, 0.88, 0.79]
results = []


def line(x0, y0, vx, vy):
    return lambda f: (x0 + vx * f, y0 + vy * f)


def simulate(objs, frames, flip=lambda g, f: None, noise=2.0, seed=1, confirm=2):
    """objs: {gt: (cat, (w, h), fn(frame) -> (cx, cy) | None)}.  flip(gt, f) -> 'new' (tracker re-numbers it), 'none' (no id), or None.
    Returns: records (entries that reached the confirm count, i.e. would be saved), served: entry rid -> set of ground-truth objects."""
    random.seed(seed)
    book = ObjectBook(confirm=confirm, say=lambda *_: None)
    tid, nxt, served = {}, [1], {}
    for f in range(frames):
        now = f * DT
        by_cat, gts = {}, {}
        for g, (cat, (w, h), fn) in objs.items():
            c = fn(f)
            if c is None:
                continue
            cx, cy = c[0] + random.gauss(0, noise), c[1] + random.gauss(0, noise)
            box = [cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2]
            how = flip(g, f)
            if g not in tid or how == "new":
                tid[g], nxt[0] = nxt[0], nxt[0] + 1
            tracker_id = None if how == "none" else tid[g]
            conf = CONF_SWING[f % 4] if len(objs) == 1 else random.uniform(0.45, 0.95)
            by_cat.setdefault(cat, []).append({"id": tracker_id, "box": box, "conf": conf, "gt": g})
            gts[g] = box
        for cat, items in by_cat.items():
            book.associate(cat, items, now)
            for it in items:
                e = it["entry"]
                if e is not None:
                    served.setdefault(e["rid"], set()).add(it["gt"])
        book.forget(now)
    records = [e for e in list(book.entries.values()) if e["seen"] >= confirm]
    return book, records, served


def check(name, cond, detail=""):
    results.append(bool(cond))
    print(("PASS  " if cond else "FAIL  ") + name + (("  -  " + detail) if detail else ""))


BOT, PED = (60, 80), (40, 100)
still = line(300, 200, 0, 0)

# 1. one Leanbot, confidence 75/81/88/79 repeating, tracker id stable
b, rec, srv = simulate({"L": ("leanbot", BOT, still)}, 60)
check("1 one Leanbot, confidence 75/81/88/79 repeating -> ONE record", len(rec) == 1, f"records={len(rec)}")
# 2. same for a pedestrian
b, rec, srv = simulate({"P": ("pedestrian", PED, still)}, 60)
check("2 one pedestrian, same -> ONE record", len(rec) == 1, f"records={len(rec)}")
# 3. tracker keeps changing the id (every 7th frame) of a slowly moving object
b, rec, srv = simulate({"L": ("leanbot", BOT, line(100, 200, 2, 1))}, 70, flip=lambda g, f: "new" if f % 7 == 3 else None)
check("3 tracker re-numbers the Leanbot 10 times -> still ONE record", len(rec) == 1, f"records={len(rec)} relinked={b.stats['relinked']}")
# 4. fast pedestrian: new id EVERY frame, boxes of consecutive frames do not even overlap (25 px/step on a 40 px box)
b, rec, srv = simulate({"P": ("pedestrian", PED, line(20, 200, 25, 1))}, 24, flip=lambda g, f: "new")
check("4 fast pedestrian, new tracker id every frame -> ONE record", len(rec) == 1, f"records={len(rec)}")
# 5. tracker gives NO id for 6 frames in the middle
b, rec, srv = simulate({"L": ("leanbot", BOT, line(100, 200, 3, 0))}, 50, flip=lambda g, f: "none" if 20 <= f < 26 else None)
e = rec[0]
check("5 no tracker id for 6 frames -> same record keeps being updated", len(rec) == 1 and e["hits"] >= 48, f"records={len(rec)} updates={e['hits']}")
# 6. a second Leanbot enters later, touching the first one
objs = {"A": ("leanbot", BOT, still), "B": ("leanbot", BOT, lambda f: None if f < 30 else (345, 200))}
b, rec, srv = simulate(objs, 60)
check("6 second Leanbot enters right next to the first -> TWO records, no merge", len(rec) == 2 and all(len(v) == 1 for v in srv.values()), f"records={len(rec)}")
# 6b. same, but the tracker also re-numbers the first one the moment the second appears
b, rec, srv = simulate(objs, 60, flip=lambda g, f: "new" if (g == "A" and f == 31) else None)
check("6b ... and the tracker re-numbers the first one at that moment -> still TWO records, none swapped",
      len(rec) == 2 and all(len(v) == 1 for v in srv.values()), f"records={len(rec)} serves={ {k: sorted(v) for k, v in srv.items()} }")
# 7. temporary loss of 2 s, returns with a new tracker id
hide = lambda fn, lo, hi: (lambda f: None if lo <= f < hi else fn(f))
b, rec, srv = simulate({"P": ("pedestrian", PED, hide(still, 20, 32))}, 60, flip=lambda g, f: "new" if f == 32 else None)
check("7 pedestrian lost for 2 s, comes back with a new id -> ONE record", len(rec) == 1, f"records={len(rec)}")
# 7b. gone for much longer than the link window (6 s) = a new appearance
b, rec, srv = simulate({"P": ("pedestrian", PED, hide(still, 20, 56))}, 90, flip=lambda g, f: "new" if f == 56 else None)
check("7b gone for 6 s (longer than the 4 s window) -> counted as a NEW appearance (2 records)", len(rec) == 2, f"records={len(rec)}")
# 8. two pedestrians walking side by side, tracker re-numbers them at random
objs = {"A": ("pedestrian", PED, line(100, 200, 6, 1)), "B": ("pedestrian", PED, line(150, 205, 6, 1))}
b, rec, srv = simulate(objs, 70, flip=lambda g, f: "new" if random.random() < 0.08 else None)
check("8 two pedestrians side by side, ids re-numbered at random -> never merged into one", all(len(v) == 1 for v in srv.values()) and len(rec) >= 2,
      f"records={len(rec)} (2 = perfect), merges={sum(len(v) > 1 for v in srv.values())}")
# 9. Leanbot and pedestrian on top of each other, ids flipping: classes must never link
objs = {"L": ("leanbot", BOT, still), "P": ("pedestrian", PED, line(302, 201, 0, 0))}
b, rec, srv = simulate(objs, 60, flip=lambda g, f: "new" if f % 5 == 0 else None)
cats = {e["cat"] for e in rec}
check("9 Leanbot and pedestrian overlapping, ids flipping -> one record per class, never mixed",
      len(rec) == 2 and cats == {"leanbot", "pedestrian"}, f"records={[(e['cat'], e['rid']) for e in rec]}")
# 10. several Leanbots and pedestrians together
objs = {f"L{i}": ("leanbot", BOT, line(80 + i * 140, 120, 0, 0)) for i in range(3)}
objs.update({f"P{i}": ("pedestrian", PED, line(60 + i * 110, 300, 3, -1)) for i in range(4)})
b, rec, srv = simulate(objs, 80)
check("10 3 Leanbots + 4 pedestrians -> 7 records", len(rec) == 7 and all(len(v) == 1 for v in srv.values()), f"records={len(rec)}")

# fuzz: random id flips / missing ids / dropouts, close pairs and crossing pairs; counts duplicates and wrong merges
def fuzz(name, objs, frames, n=300, **kw):
    dup = merge = perfect = 0
    for s in range(n):
        random.seed(5000 + s)
        flips = {}
        def flip(g, f, flips=flips):
            r = random.random()
            return "new" if r < 0.06 else ("none" if r < 0.12 else None)
        b, rec, srv = simulate(objs, frames, flip=flip, seed=5000 + s, **kw)
        gt_entries = {}
        for rid, gs in srv.items():
            for g in gs:
                gt_entries.setdefault(g, set()).add(rid)
        m = sum(len(v) > 1 for v in srv.values())
        d = sum(len(v) - 1 for v in gt_entries.values() if len(v) > 1)
        merge += m > 0
        dup += d > 0
        perfect += (m == 0 and d == 0)
    print(f"      fuzz {name:<52} perfect {perfect:3d}/{n}   duplicate-record runs {dup:3d}   wrong-merge runs {merge:3d}")
    return merge


print("\n-- randomized (6% re-numbered ids, 6% frames with no id) --")
m1 = fuzz("one Leanbot, moving", {"L": ("leanbot", BOT, line(100, 200, 4, 1))}, 80)
m2 = fuzz("two Leanbots 40 px apart, still", {"A": ("leanbot", BOT, line(200, 150, 0, 0)), "B": ("leanbot", BOT, line(240, 150, 0, 0))}, 80)
m3 = fuzz("two pedestrians walking together", {"A": ("pedestrian", PED, line(100, 200, 6, 1)), "B": ("pedestrian", PED, line(145, 205, 6, 1))}, 80)
m4 = fuzz("two pedestrians crossing paths", {"A": ("pedestrian", PED, line(100, 200, 8, 0)), "B": ("pedestrian", PED, line(580, 208, -8, 0))}, 70)
check("11 randomized: two different objects were never merged into one record", m1 + m2 + m3 + m4 == 0)

# speed
b = ObjectBook(say=lambda *_: None)
t0 = time.perf_counter()
for f in range(500):
    for cat, y in (("leanbot", 100), ("pedestrian", 250)):
        items = [{"id": (f * 3 + i) if f % 5 == 0 else i + (1 if cat == "leanbot" else 100), "box": [20 + i * 60 + f % 7, y, 70 + i * 60 + f % 7, y + 80], "conf": 0.8} for i in range(10)]
        b.associate(cat, items, f * DT)
    b.forget(f * DT)
ms = (time.perf_counter() - t0) * 1000 / 500
check("12 speed: 20 objects per AI run, ids changing every 5th run", ms < 5, f"{ms:.2f} ms per run (the model takes tens of ms on a Pi 5)")
print(f"\n{sum(results)} passed, {len(results) - sum(results)} failed")
sys.exit(0 if all(results) else 1)
