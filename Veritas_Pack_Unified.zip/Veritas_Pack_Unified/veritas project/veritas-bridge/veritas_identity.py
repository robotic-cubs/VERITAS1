"""VERITAS object identity: one RECORD per physical object, whatever the tracker or the confidence does.

ByteTrack (inside model.track) is the tracker; it gives boxes ids. This module sits behind it and answers one question for every
box of every AI run: "is this a record we already have, or a different object?". It never tracks anything itself and it never
looks at confidence to decide.

  1. A box whose tracker id is already known keeps that object (the tracker's identity is trusted first).
  2. A box with a NEW id, or with NO id at all, is compared with the objects of the SAME class that are not visible right now and
     were seen within `relink_s` seconds. The comparison uses where the object should be now (last box + its own speed),
     overlap, centre distance measured in object sizes and size similarity. If exactly one object fits clearly, the box is that object.
  3. Matching is one-to-one for the whole frame (Hungarian algorithm): two boxes can never take the same object.
  4. If two objects fit about equally well the box is NOT linked, and becomes a new object. Wrongly merging two different objects is
     worse than occasionally keeping an extra record.
  5. Objects that are visible in the current frame are never candidates: two things on screen at the same time stay two things.
Pure Python, no extra install; a frame with 20 objects takes well under 1 ms.
"""
import math

BIG = 1e6


def iou(a, b):
    ix, iy = min(a[2], b[2]) - max(a[0], b[0]), min(a[3], b[3]) - max(a[1], b[1])
    if ix <= 0 or iy <= 0:
        return 0.0
    inter = ix * iy
    u = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / u if u > 0 else 0.0


def assign(cost):
    """Cheapest one-to-one assignment (Hungarian algorithm). Returns [(row, col)] and skips pairs that cost >= BIG."""
    n = len(cost)
    m = len(cost[0]) if n else 0
    if not n or not m:
        return []
    flip = n > m
    if flip:
        cost = [list(r) for r in zip(*cost)]
        n, m = m, n
    u, v, p, way = [0.0] * (n + 1), [0.0] * (m + 1), [0] * (m + 1), [0] * (m + 1)
    for i in range(1, n + 1):
        p[0], j0 = i, 0
        minv, used = [float("inf")] * (m + 1), [False] * (m + 1)
        while True:
            used[j0] = True
            i0, delta, j1 = p[j0], float("inf"), 0
            for j in range(1, m + 1):
                if not used[j]:
                    cur = cost[i0 - 1][j - 1] - u[i0] - v[j]
                    if cur < minv[j]:
                        minv[j], way[j] = cur, j0
                    if minv[j] < delta:
                        delta, j1 = minv[j], j
            for j in range(m + 1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minv[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while True:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
            if j0 == 0:
                break
    out = []
    for j in range(1, m + 1):
        if p[j]:
            r, c = p[j] - 1, j - 1
            if cost[r][c] < BIG:
                out.append((c, r) if flip else (r, c))
    return out


class ObjectBook:
    def __init__(self, confirm=2, forget=30.0, relink_s=4.0, gate=0.8, ambiguity=0.85, run_id=lambda: "run", say=print):
        self.confirm, self.forget_s, self.relink_s, self.gate, self.ambiguity = confirm, forget, relink_s, gate, ambiguity
        self.run_id, self.say = run_id, say
        self.session, self.entries, self.alias = 0, {}, {}
        self.stats = {"new": 0, "relinked": 0, "ambiguous": 0}

    # ---- sessions: a restarted tracker (ids start again) or a long camera gap must never be mistaken for the old objects ----
    def new_session(self, why):
        self.session += 1
        self.entries.clear()
        self.alias.clear()
        self.say(f"[tracking] new tracking session {self.session}: {why}")

    def forget(self, now):
        for k in [k for k, e in self.entries.items() if now - e["last"] > self.forget_s]:
            e = self.entries.pop(k)
            for t in e["tids"]:
                self.alias.pop((e["cat"], t), None)

    # ---- matching ----
    def _cost(self, e, box, now):
        dt = max(0.0, now - e["last"])
        cx, cy = (e["box"][0] + e["box"][2]) / 2 + e["vx"] * min(dt, self.relink_s), (e["box"][1] + e["box"][3]) / 2 + e["vy"] * min(dt, self.relink_s)
        pb = [cx - e["w"] / 2, cy - e["h"] / 2, cx + e["w"] / 2, cy + e["h"] / 2]
        wd, hd = box[2] - box[0], box[3] - box[1]
        if wd <= 0 or hd <= 0 or e["w"] <= 0 or e["h"] <= 0:
            return BIG, "bad box"
        a_e, a_d = e["w"] * e["h"], wd * hd
        ratio = min(a_e, a_d) / max(a_e, a_d)
        if ratio < 0.35:
            return BIG, f"size differs ({ratio:.2f})"
        size = 0.5 * (math.sqrt(a_e) + math.sqrt(a_d))
        dn = math.hypot(cx - (box[0] + box[2]) / 2, cy - (box[1] + box[3]) / 2) / size
        g = self.gate * (1.0 + 0.25 * min(dt, self.relink_s))       # an object missing for longer is allowed to be a little further away
        if dn > g:
            return BIG, f"too far ({dn:.1f} object sizes)"
        return 0.5 * (1.0 - iou(pb, box)) + 0.5 * (dn / g), ""

    def _link(self, cat, items, pool, now):
        """Returns {item index: entry} for the boxes that are clearly an already-known, currently invisible object."""
        if not items or not pool:
            return {}
        costs = [[self._cost(e, it["box"], now) for e in pool] for it in items]
        mat = [[c for c, _ in row] for row in costs]
        out = {}
        for i, j in assign(mat):
            c = mat[i][j]
            rivals_row = [x for k, x in enumerate(mat[i]) if k != j and x < BIG]                  # other objects this box could be
            rivals_col = [mat[k][j] for k in range(len(items)) if k != i and mat[k][j] < BIG]     # other boxes this object could be
            ambiguous = any(r > 0 and c / r > self.ambiguity for r in rivals_row + rivals_col) or any(r <= 1e-9 for r in rivals_row + rivals_col)
            if ambiguous:
                self.stats["ambiguous"] += 1
                items[i]["_why"] = f"two objects fit about equally (kept apart): #{pool[j]['rid']}"
                continue
            out[i] = pool[j]
        for i, it in enumerate(items):
            if i not in out and "_why" not in it:
                best = min(((costs[i][j][1] or "", j) for j in range(len(pool))), key=lambda z: z[1], default=None)
                it["_why"] = f"no lost object fits ({costs[i][0][1] if len(pool) == 1 else 'nearest: ' + (best[0] if best else '')})"
        return out

    def _touch(self, e, it, now):
        dt = now - e["last"]
        ox, oy = (e["box"][0] + e["box"][2]) / 2, (e["box"][1] + e["box"][3]) / 2
        nx, ny = (it["box"][0] + it["box"][2]) / 2, (it["box"][1] + it["box"][3]) / 2
        if 0.02 < dt <= 2.0:                                         # own speed of this object, pixels per second
            e["vx"], e["vy"] = 0.5 * (nx - ox) / dt + 0.5 * e["vx"], 0.5 * (ny - oy) / dt + 0.5 * e["vy"]
        e["seen"] += 1
        e["hits"] += 1
        e["last"], e["box"], e["w"], e["h"], e["conf"] = now, list(it["box"]), it["box"][2] - it["box"][0], it["box"][3] - it["box"][1], it["conf"]
        e["max"] = max(e["max"], it["conf"])
        it["entry"], it["id"] = e, e["rid"]                           # the id everyone downstream sees is the OBJECT's stable id

    def associate(self, cat, items, now):
        """items: dicts with 'id' (tracker id or None), 'box', 'conf'. Sets item['entry'] and item['id'] on every item."""
        fresh, unid = [], []
        for it in items:
            it["entry"] = None
            tid = it["id"]
            if tid is None:
                unid.append(it)
                continue
            e = self.alias.get((cat, tid))
            if e is None:
                fresh.append(it)
            elif e["last"] != now:                                   # a known id: the tracker's identity is trusted
                self._touch(e, it, now)
            else:                                                    # a second tracker id on an object already matched this frame: live only
                it["id"] = e["rid"]
        pool = [e for e in self.entries.values() if e["cat"] == cat and e["last"] < now and now - e["last"] <= self.relink_s]
        cand = fresh + unid
        links = self._link(cat, cand, pool, now)
        for i, it in enumerate(cand):
            e = links.get(i)
            if e is not None:                                        # same object, new or missing tracker id
                if it["id"] is not None:
                    self.alias[(cat, it["id"])] = e
                    e["tids"].add(it["id"])
                    self.stats["relinked"] += 1
                    e["relinks"] = e.get("relinks", 0) + 1
                    if e["relinks"] == 1 or e["relinks"] % 25 == 0:
                        self.say(f"[tracking] {cat} id {it['id']} is the same object as #{e['rid']} (position matches): one record"
                                 + (f" [{e['relinks']} tracker id changes so far]" if e["relinks"] > 1 else ""))
                self._touch(e, it, now)
            elif it["id"] is not None:                               # a genuinely new object
                rid = it["id"]
                e = {"cat": cat, "rid": rid, "tids": {rid}, "first": now, "last": now, "seen": 1, "hits": 1, "box": list(it["box"]),
                     "w": it["box"][2] - it["box"][0], "h": it["box"][3] - it["box"][1], "vx": 0.0, "vy": 0.0, "conf": it["conf"], "max": it["conf"],
                     "sent": False, "sent_t": 0.0, "text": "", "pbox": None, "pconf": None, "why": it.pop("_why", "first time seen"),
                     "event_id": f"{'LB' if cat == 'leanbot' else 'PED'}-{self.run_id()}-{rid}"}
                self.entries[(cat, rid)] = e
                self.alias[(cat, rid)] = e
                it["entry"] = e
                self.stats["new"] += 1
        return items
