"""VERITAS Phase 2 - test 723image.pt ON ITS OWN. Read-only: changes nothing in the project.

Run it from the 'veritas project\\veritas-bridge' folder with that folder's venv:
    .venv\\Scripts\\activate
    pip install -U ultralytics            (723image.pt is a YOLO26 model: an old ultralytics cannot load it)
    python Test_723image.py --source 0                      live camera (press q to stop)
    python Test_723image.py --source some_video.mp4         video file
    python Test_723image.py --source some_photo.jpg         one picture (or a folder of pictures)

It prints: model type, class names, and for every frame which classes were seen. At the end it prints a summary that says
exactly what was seen: Leanbot, Plate, Pedestrian, and whether Leanbot + Pedestrian ever appeared in the SAME frame.
Annotated pictures are saved to ./test723_out so you can check boxes, labels and confidence with your own eyes.
"""
import argparse, sys, time
from pathlib import Path

import cv2

HERE = Path(__file__).resolve().parent
DEFAULT_MODEL = HERE.parent.parent / "veritas-cv-main" / "models" / "723image.pt"
if not DEFAULT_MODEL.exists():                      # also works if this file is placed elsewhere in the project
    DEFAULT_MODEL = HERE / "veritas-cv-main" / "models" / "723image.pt"

ap = argparse.ArgumentParser()
ap.add_argument("--model", default=str(DEFAULT_MODEL))
ap.add_argument("--source", default="0", help="camera number, video file, picture or folder")
ap.add_argument("--conf", type=float, default=0.4)
ap.add_argument("--imgsz", type=int, default=640)
ap.add_argument("--max-frames", type=int, default=0, help="stop after N frames (0 = until q / end of file)")
ap.add_argument("--no-window", action="store_true")
a = ap.parse_args()

if not Path(a.model).exists():
    sys.exit(f"Model not found: {a.model}")
try:
    from ultralytics import YOLO
    import ultralytics
except ImportError:
    sys.exit("ultralytics is not installed in this environment:  pip install -U ultralytics")

print(f"ultralytics {ultralytics.__version__}  |  loading {a.model}")
model = YOLO(a.model)
names = model.names
print(f"task: {model.task}  |  classes: {names}")
want = {"leanbot": None, "plate": None, "pedestrian": None}
for k, v in names.items():
    if str(v).lower() in want:
        want[str(v).lower()] = k
missing = [k for k, v in want.items() if v is None]
if missing:
    print(f"!! class(es) not in this model: {missing}")

src = Path(a.source)
out = HERE / "test723_out"; out.mkdir(exist_ok=True)
if src.is_dir():
    items = sorted(p for p in src.iterdir() if p.suffix.lower() in (".jpg", ".jpeg", ".png", ".bmp", ".webp"))
    is_images, cap = True, None
elif src.is_file() and src.suffix.lower() in (".jpg", ".jpeg", ".png", ".bmp", ".webp"):
    items, is_images, cap = [src], True, None
else:
    is_images, items = False, []
    cap = cv2.VideoCapture(int(a.source) if a.source.isdigit() else a.source)
    if not cap.isOpened():
        sys.exit(f"Could not open the source: {a.source}  (camera busy? wrong number? close VERITAS, Zoom, Teams first)")
    print(f"opened source {a.source}: {int(cap.get(3))}x{int(cap.get(4))}")

count = {k: 0 for k in names.values()}
frames = both = saved = 0
ms_list = []
t_start = time.time()
idx = 0
while True:
    if is_images:
        if idx >= len(items):
            break
        frame = cv2.imread(str(items[idx])); label = items[idx].name; idx += 1
        if frame is None:
            continue
    else:
        ok, frame = cap.read()
        if not ok:
            break
        label = f"frame{frames}"
    t0 = time.time()
    r = model.predict(frame, imgsz=a.imgsz, conf=a.conf, verbose=False)[0]
    ms_list.append((time.time() - t0) * 1000)
    seen = set()
    for b in r.boxes:
        cls = int(b.cls[0]); nm = str(names[cls]); conf = float(b.conf[0])
        x1, y1, x2, y2 = map(int, b.xyxy[0])
        count[names[cls]] += 1; seen.add(nm.lower())
        col = {"leanbot": (0, 200, 0), "plate": (0, 0, 255), "pedestrian": (0, 255, 255)}.get(nm.lower(), (255, 0, 0))
        cv2.rectangle(frame, (x1, y1), (x2, y2), col, 2)
        cv2.putText(frame, f"{nm} {conf * 100:.0f}%", (x1, max(y1 - 6, 14)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, col, 2)
    frames += 1
    if {"leanbot", "pedestrian"} <= seen:
        both += 1
        if saved < 20:                                   # keep up to 20 pictures where both appear together
            cv2.imwrite(str(out / f"both_{saved:02d}.jpg"), frame); saved += 1
    if seen and not {"leanbot", "pedestrian"} <= seen and frames % 15 == 0:
        cv2.imwrite(str(out / f"seen_{'_'.join(sorted(seen))}_{frames}.jpg"), frame)
    if is_images:
        cv2.imwrite(str(out / f"annotated_{label}"), frame)
        print(f"{label}: {sorted(seen) or 'nothing detected'}")
    if not a.no_window:
        cv2.imshow("Test 723image.pt (q = stop)", frame)
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break
    if a.max_frames and frames >= a.max_frames:
        break

if cap is not None:
    cap.release()
cv2.destroyAllWindows()
print("\n================ SUMMARY (what was ACTUALLY seen) ================")
print(f"frames/pictures tested : {frames}  in {time.time() - t_start:.1f} s   (model {sum(ms_list) / max(len(ms_list), 1):.0f} ms per frame on this PC)")
for k, v in count.items():
    print(f"  {k:<11}: {v} detections")
print(f"frames with Leanbot AND Pedestrian together: {both}")
print(f"pictures saved in: {out}")
print("Look at the saved pictures yourself: are the boxes on the right objects, and are the labels/percentages right?")
