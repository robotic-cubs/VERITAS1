"""Decides WHEN the bridge may send a detection to the backend. Pure Python (no camera or model), so it can be tested alone.

Why this exists: the bridge used to send every box it saw, including boxes with no tracker id (the tracker only gives an id
once it trusts a box), and all of those shared one throttle slot. A flickering false box therefore became a saved
"vehicle" every few seconds. Now a box is sent only after its tracker id has been seen in MIN_HITS frames, and then at a
steady rate per tracker id."""
import time


class TrackGate:
    def __init__(self, min_hits=3, send_every=5.0, retry_every=2.0, forget_after=60.0, allow_untracked=False):
        self.min_hits, self.send_every, self.retry_every = min_hits, send_every, retry_every
        self.forget_after, self.allow_untracked = forget_after, allow_untracked
        self.hits, self.last_sent, self.last_seen, self.has_plate = {}, {}, {}, {}
        self.stats = {"frames": 0, "boxes": 0, "untracked": 0, "ids": set(), "sent": 0, "held_back": 0}

    def see_frame(self, now=None):
        """Call once per frame, after every box of that frame was passed to offer()."""
        now = time.time() if now is None else now
        self.stats["frames"] += 1
        for k in [k for k, t in self.last_seen.items() if now - t > self.forget_after]:
            for d in (self.hits, self.last_sent, self.last_seen, self.has_plate):
                d.pop(k, None)

    def offer(self, tid, has_plate, now=None):
        """True if this box should be sent now. tid is the tracker id or None. has_plate: a plate text was already read."""
        now = time.time() if now is None else now
        s = self.stats
        s["boxes"] += 1
        if tid is None:
            s["untracked"] += 1
            if not self.allow_untracked:
                s["held_back"] += 1
                return False
            tid = "none"
        else:
            s["ids"].add(tid)
        self.hits[tid] = self.hits.get(tid, 0) + 1
        self.last_seen[tid] = now
        if self.hits[tid] < self.min_hits:          # not confirmed yet: a one-frame flicker never becomes a record
            s["held_back"] += 1
            return False
        if has_plate:
            self.has_plate[tid] = True
        # Until a plate is read, retry sooner so the plate appears quickly; after that, a gentle rate.
        gap = self.send_every if self.has_plate.get(tid) else min(self.retry_every, self.send_every)
        last = self.last_sent.get(tid)
        if last is not None and now - last < gap:
            return False
        self.last_sent[tid] = now
        s["sent"] += 1
        return True

    def summary(self):
        s = self.stats
        pct = 100 * s["untracked"] / s["boxes"] if s["boxes"] else 0
        return (f"[stats] frames={s['frames']} boxes={s['boxes']} untracked={s['untracked']} ({pct:.0f}%) "
                f"distinct_ids={len(s['ids'])} sent={s['sent']} held_back={s['held_back']}")
