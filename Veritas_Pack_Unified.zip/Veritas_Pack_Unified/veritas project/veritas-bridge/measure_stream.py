"""Measure what the DASHBOARD actually sees from a bridge stream.
    python measure_stream.py http://127.0.0.1:8001/video_feed 30
Prints, every 5 s and at the end: frames/s received, UNIQUE frames/s (a re-sent identical frame is not real video),
the longest gap between frames (a freeze shows up here) and the average frame size.
Uses only the standard library, so it runs anywhere the bridge runs."""
import hashlib, http.client, sys, time
from urllib.parse import urlparse


def main(url, seconds):
    u = urlparse(url)
    conn = http.client.HTTPConnection(u.hostname, u.port or 80, timeout=10)
    conn.request("GET", u.path or "/")
    r = conn.getresponse()
    if r.status != 200:
        raise SystemExit(f"stream answered HTTP {r.status}")
    buf, t0, last_print = b"", time.time(), time.time()
    arrivals, hashes, sizes = [], [], []
    seen = set()
    while time.time() - t0 < seconds:
        chunk = r.read1(65536)
        if not chunk:
            print("stream closed by the server"); break
        buf += chunk
        while True:
            a = buf.find(b"\xff\xd8")
            b = buf.find(b"\xff\xd9", a + 2) if a >= 0 else -1
            if a < 0 or b < 0:
                if a > 0:
                    buf = buf[a:]
                break
            jpg, buf = buf[a:b + 2], buf[b + 2:]
            now = time.time(); h = hashlib.md5(jpg).digest()
            arrivals.append(now); sizes.append(len(jpg)); hashes.append(h in seen); seen.add(h)
        if time.time() - last_print >= 5:
            report(arrivals, hashes, sizes, time.time() - t0, "so far"); last_print = time.time()
    report(arrivals, hashes, sizes, time.time() - t0, "FINAL")
    conn.close()


def report(arr, dup, sizes, elapsed, tag):
    n = len(arr)
    if n < 2:
        print(f"[{tag}] {n} frames in {elapsed:.0f}s"); return
    gaps = [b - a for a, b in zip(arr, arr[1:])]
    uniq = n - sum(dup)
    print(f"[{tag}] {elapsed:4.0f}s  received {n / elapsed:5.1f} fps | unique {uniq / elapsed:5.1f} fps | "
          f"longest gap {max(gaps) * 1000:5.0f} ms | avg frame {sum(sizes) / n / 1024:4.0f} KB", flush=True)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8001/video_feed", float(sys.argv[2]) if len(sys.argv) > 2 else 20)
