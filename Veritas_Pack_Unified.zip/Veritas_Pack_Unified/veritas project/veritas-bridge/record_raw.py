"""Record CLEAN training footage from the camera: no boxes, no text drawn on the saved video.
    python record_raw.py --camera 0 --out clip1.mp4 --seconds 90          (press q in the preview window to stop early)
Use the SAME camera and position as the final demo. Do NOT record the VERITAS window or a screen/monitor - record the camera itself."""
import argparse, time
import cv2 as cv
import camera_utils
p = argparse.ArgumentParser()
p.add_argument("--camera", default="0"); p.add_argument("--camera-name", default=""); p.add_argument("--camera-backend", default="")
p.add_argument("--width", type=int, default=0); p.add_argument("--height", type=int, default=0); p.add_argument("--fps", type=float, default=0)
p.add_argument("--fourcc", default="", help="e.g. MJPG: many USB webcams only reach 30 fps at HD with this")
p.add_argument("--out", default="clip.mp4"); p.add_argument("--seconds", type=float, default=90); p.add_argument("--no-preview", action="store_true")
a = p.parse_args()
cap, info = camera_utils.open_camera(source=a.camera, name=a.camera_name, backend=a.camera_backend, width=a.width, height=a.height, fps=a.fps, fourcc=a.fourcc)
W, H = info["width"], info["height"]
# The camera's advertised fps (often 60) can be far from what it really delivers (5 fps in dim light). Measure it for 2 s,
# so the saved clip plays at the real speed instead of racing.
fps = info["fps"] or 25
if info["kind"] == "device":
    t0 = time.time(); k = 0
    while time.time() - t0 < 2.0:
        if cap.read()[0]: k += 1
    if k >= 3: fps = max(1.0, round(k / (time.time() - t0), 1))
print(f"Camera really delivers about {fps:g} fps (advertised: {info['fps'] or 'unknown'}).")
if fps < 15: print("WARNING: under 15 fps. Add more light and/or use --fourcc MJPG before recording training clips.")
wr = cv.VideoWriter(a.out, cv.VideoWriter_fourcc(*"mp4v"), fps, (W, H)); t0 = time.time(); n = 0
print(f"Recording {info['label']} {W}x{H} @ {fps:g} fps -> {a.out}  (q = stop)")
while time.time() - t0 < a.seconds:
    ok, fr = cap.read()
    if not ok: break
    wr.write(fr); n += 1                                   # the SAVED frame is untouched
    if not a.no_preview:
        v = fr.copy(); cv.putText(v, f"REC {time.time()-t0:4.0f}s (preview only)", (10, 30), 0, 0.8, (0, 0, 255), 2)
        cv.imshow("record_raw (q to stop)", v)
        if cv.waitKey(1) & 0xFF == ord("q"): break
wr.release(); cap.release(); cv.destroyAllWindows(); print(f"Saved {n} frames ({n/fps:.0f}s) to {a.out}")
if n < 30: print("WARNING: fewer than 30 frames saved. This is not a usable clip - record again.")
