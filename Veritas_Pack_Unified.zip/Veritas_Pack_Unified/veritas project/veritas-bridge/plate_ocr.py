"""OPTIONAL plate-text reading. The original AI has NO OCR, so this is new and separate.
If easyocr isn't installed, read_plate() returns None and detections are saved without plate text."""
import os, re

_reader = None
_failed = False
PLATE_REGEX = re.compile(os.getenv("PLATE_REGEX", r"^[A-Z]{3} ?[0-9]{3,4}$"))


def available() -> bool:
    global _reader, _failed
    if _reader or _failed:
        return _reader is not None
    try:
        import easyocr
        _reader = easyocr.Reader(["en"], gpu=False, verbose=False)
    except Exception as e:  # not installed, or model download failed
        print(f"[ocr] disabled: {e}")
        _failed = True
    return _reader is not None


def read_plate(crop, min_conf=0.4):
    """crop = BGR image of the plate box. Returns (text, confidence) or None if unsure."""
    if crop is None or crop.size == 0 or not available():
        return None
    import cv2
    g = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    g = cv2.resize(g, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    parts = _reader.readtext(g, allowlist="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", detail=1)
    if not parts:
        return None
    text = " ".join(p[1] for p in sorted(parts, key=lambda p: p[0][0][0])).upper().strip()
    conf = sum(p[2] for p in parts) / len(parts)
    compact = re.sub(r"[^A-Z0-9]", "", text)
    m = re.match(r"^([A-Z]+)([0-9]+)$", compact)
    text = f"{m.group(1)} {m.group(2)}" if m else text
    if conf < min_conf or not PLATE_REGEX.match(text):
        return None  # better blank than a wrong plate
    return text, float(conf)
