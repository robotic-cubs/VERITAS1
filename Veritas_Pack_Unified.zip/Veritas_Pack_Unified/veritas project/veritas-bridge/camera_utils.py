"""Camera helpers for the VERITAS bridge.

Opens ONE camera that you chose on purpose. If it cannot be opened it raises a clear error.
It never switches to a different camera by itself.
"""
import os
import time

import cv2 as cv


class CameraError(Exception):
    pass


_API = {"dshow": cv.CAP_DSHOW, "msmf": cv.CAP_MSMF, "v4l2": cv.CAP_V4L2, "auto": cv.CAP_ANY}


def default_backend():
    # DirectShow gives stable camera numbers on Windows and lets us set resolution reliably.
    return "dshow" if os.name == "nt" else "auto"


def device_names():
    """Camera names in DirectShow order (the same order as the numbers when backend is dshow).
    Returns None if the optional 'pygrabber' package is not installed or fails."""
    try:
        from pygrabber.dshow_graph import FilterGraph
        return list(FilterGraph().get_input_devices())
    except Exception:
        return None


def resolve_source(source, name, backend):
    """Turn the user's settings into ('device'|'file', value, label). Never guesses."""
    name = (name or "").strip()
    source = "" if source is None else str(source).strip()
    if name:
        if backend != "dshow":
            raise CameraError("CAMERA_NAME only works on Windows with CAMERA_BACKEND=dshow. "
                              "Use CAMERA=<number> instead.")
        names = device_names()
        if names is None:
            raise CameraError("CAMERA_NAME needs the 'pygrabber' package, which is not installed. "
                              "Run 5-LIST-CAMERAS.bat once (it installs it), or use CAMERA=<number> instead.")
        hits = [i for i, n in enumerate(names) if name.lower() in n.lower()]
        listing = ", ".join(f"{i} = {n}" for i, n in enumerate(names)) or "none"
        if not hits:
            raise CameraError(f"No camera has '{name}' in its name. Cameras found: {listing}")
        if len(hits) > 1:
            raise CameraError(f"More than one camera matches '{name}'. Cameras found: {listing}. "
                              "Make CAMERA_NAME more specific, or use CAMERA=<number>.")
        return "device", hits[0], f"'{names[hits[0]]}' (camera {hits[0]})"
    if not source:
        raise CameraError("No camera selected. VERITAS will not pick one for you, so it cannot grab the "
                          "laptop's built-in webcam by accident.\n"
                          "  1) Plug in the USB camera and run 5-LIST-CAMERAS.bat\n"
                          "  2) Note the number of the USB camera\n"
                          "  3) Put CAMERA=<that number> in veritas-bridge\\.env")
    if source.isdigit():
        i = int(source)
        names = device_names() if backend == "dshow" else None
        label = f"camera {i}" + (f" '{names[i]}'" if names and i < len(names) else "")
        return "device", i, label
    return "file", source, source


def open_camera(source=None, name=None, backend=None, width=0, height=0, fps=0, fourcc=""):
    """Open the chosen camera and prove it gives a picture. Returns (cap, info)."""
    backend = (backend or default_backend()).strip().lower()
    if backend not in _API:
        raise CameraError(f"CAMERA_BACKEND '{backend}' is not valid. Use dshow, msmf or auto.")
    kind, value, label = resolve_source(source, name, backend)

    cap = cv.VideoCapture(value, _API[backend]) if kind == "device" else cv.VideoCapture(value)
    if not cap.isOpened():
        cap.release()
        if kind == "device":
            raise CameraError(f"Could not open {label}. Is it plugged in, and is every other program "
                              "(Zoom, Teams, the Windows Camera app, another VERITAS window) closed? "
                              "Run 5-LIST-CAMERAS.bat to see which cameras exist.")
        raise CameraError(f"Could not open '{value}'.")

    if kind == "device":  # settings only make sense for real cameras, not video files
        if fourcc:
            cap.set(cv.CAP_PROP_FOURCC, cv.VideoWriter_fourcc(*fourcc.upper()[:4]))
        if width:
            cap.set(cv.CAP_PROP_FRAME_WIDTH, int(width))
        if height:
            cap.set(cv.CAP_PROP_FRAME_HEIGHT, int(height))
        if fps:
            cap.set(cv.CAP_PROP_FPS, float(fps))

    frame = None
    for _ in range(30):  # cameras need a moment to warm up
        ok, frame = cap.read()
        if ok and frame is not None:
            break
        frame = None
        time.sleep(0.1)
    if frame is None:
        cap.release()
        raise CameraError(f"Opened {label} but it gave no picture. Try another USB port (plug it straight "
                          "into the laptop, not a hub), lower CAMERA_WIDTH/HEIGHT, or set CAMERA_BACKEND=msmf.")

    h, w = frame.shape[:2]
    reported_fps = cap.get(cv.CAP_PROP_FPS) or 0
    warnings = []
    if kind == "device":
        if width and height and (w, h) != (int(width), int(height)):
            warnings.append(f"asked for {width}x{height} but the camera is giving {w}x{h}")
        if fps and reported_fps and abs(reported_fps - fps) > 1:
            warnings.append(f"asked for {fps:g} fps but the camera reports {reported_fps:g} fps")
    info = {"kind": kind, "label": label, "width": w, "height": h, "fps": reported_fps,
            "backend": backend, "warnings": warnings}
    return cap, info
