"""VERITAS unified AI pipeline: ONE camera, ONE model (723image.pt), ONE detection loop.

The model has three classes (read from the model file itself at start-up): Leanbot, Plate, Pedestrian.
  Leanbot + Plate -> saved through the existing Apps Script URL (BACKEND_URL in .env), exactly as before
  Leanbot + Pedestrian + live status -> the VERITAS backend (FastAPI, port 8000) -> Leanbot AI / Pedestrian Safety on admin.html
Each box is sorted by the model's real class NAME. A class the pipeline does not know is ignored, never guessed.
TRACKING: model.track(..., tracker="bytetrack.yaml") gives every physical object one id. Records are keyed by that id:
  confidence / box changes only UPDATE the object (Apps Script row and backend event are updated, never duplicated);
  a new record needs a new id seen for --confirm-frames runs; unseen ids are cleaned up; a tracker restart or a long
  camera gap starts a new "tracking session" so recycled ids cannot be mistaken for old objects.

HOW IT STAYS SMOOTH: independent parts, so a slow one can never freeze another.
  capture thread   reads the camera as fast as it delivers and keeps ONLY the newest frame (no backlog, no stale pictures)
  AI thread        takes the newest frame when it is free (skips the rest), runs the model once, stores the boxes
  sender threads   post to the Sheet and to the backend; a slow network never blocks the camera
  main thread      shows the newest frame at a steady rate with the newest boxes on top, and feeds the dashboard stream
Video FPS, AI FPS and AI latency are different numbers; a [perf] line prints all of them.

This process is the ONLY one that opens the physical camera. It only LOADS the model file; it never edits it.
Run:  python veritas_bridge.py --camera 0        (Camera Start.bat does this for you)
Stop: press q in the preview window (or Ctrl+C)."""
import argparse, json, os, queue, socket, sys, threading, time
from pathlib import Path
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from random import randint, seed

import cv2 as cv
import numpy as np
import requests
from dotenv import load_dotenv

import camera_utils
import veritas_identity
import plate_ocr

load_dotenv()
def _env_num(name, kind=int):
    try:
        return kind(os.getenv(name, "") or 0)
    except ValueError:
        raise SystemExit(f"{name} in .env must be a number.")


p = argparse.ArgumentParser()
DEFAULT_MODEL = Path(__file__).resolve().parents[2] / "veritas-cv-main" / "models" / "723image.pt"
p.add_argument("--model", default=str(DEFAULT_MODEL), help="the ONE model file (default: veritas-cv-main\\models\\723image.pt)")
p.add_argument("--camera", default=os.getenv("CAMERA", ""),
               help="USB camera number (run 5-LIST-CAMERAS.bat to see them), or a video file / stream URL. Also CAMERA in .env")
p.add_argument("--camera-name", default=os.getenv("CAMERA_NAME", ""), help="part of the camera's name, e.g. Logitech (Windows)")
p.add_argument("--camera-backend", default=os.getenv("CAMERA_BACKEND", ""), help="dshow (default on Windows), msmf or auto")
p.add_argument("--width", type=int, default=_env_num("CAMERA_WIDTH"), help="requested camera width, 0 = camera default")
p.add_argument("--height", type=int, default=_env_num("CAMERA_HEIGHT"), help="requested camera height, 0 = camera default")
p.add_argument("--fps", type=float, default=_env_num("CAMERA_FPS", float), help="requested frame rate, 0 = camera default")
p.add_argument("--fourcc", default=os.getenv("CAMERA_FOURCC", ""), help="optional, e.g. MJPG for smoother HD on USB cameras")
p.add_argument("--camera-id", default="CAM-001")
p.add_argument("--location", default="")
p.add_argument("--backend", default=os.getenv("BACKEND_URL", "http://127.0.0.1:8000"),
               help="Google Apps Script /exec URL (or the old local backend URL): where Leanbot/Plate detections are saved")
p.add_argument("--ai-backend", default=os.getenv("AI_BACKEND_URL", "http://127.0.0.1:8000"),
               help="VERITAS FastAPI backend: live AI status, Leanbot and Pedestrian detections for the dashboard")
p.add_argument("--state-hz", type=float, default=2.0, help="how often the live state is sent to the backend (per second)")
p.add_argument("--stream-port", type=int, default=8001)
p.add_argument("--conf", type=float, default=0.4)
p.add_argument("--send-every", type=float, default=5, help="seconds between UPDATES of an already-recorded object (an update, never a new record)")
p.add_argument("--tracker", default="bytetrack.yaml", help="ultralytics tracker config. ByteTrack gives every physical object one id")
p.add_argument("--track-conf", type=float, default=0.1, help="lowest confidence handed to ByteTrack so it can keep an object's id while its confidence dips (ByteTrack's low-score pass). Nothing below --conf is ever shown or recorded")
p.add_argument("--confirm-frames", type=int, default=2, help="an id must be seen this many AI runs, as the same class, before it is recorded (a one-frame flicker is never saved)")
p.add_argument("--track-forget", type=float, default=30.0, help="seconds after which the record-keeping for an unseen id is cleaned up")
p.add_argument("--session-gap", type=float, default=10.0, help="no AI frames for this many seconds (camera away) = start a new tracking session")
p.add_argument("--relink-gate", type=float, default=0.8, help="a box with a new/missing tracker id can be an already-recorded object that is not visible now if it is within this many object sizes of where that object should be. 0 = never link")
p.add_argument("--relink-seconds", type=float, default=4.0, help="how recently the object must have been seen for that link")
p.add_argument("--ocr", action="store_true", help="try to read plate text (needs easyocr)")
p.add_argument("--no-preview", action="store_true")
p.add_argument("--stream-fps", type=float, default=30, help="max video frames/s for the dashboard and preview window (0 = every camera frame)")
p.add_argument("--stream-width", type=int, default=960, help="dashboard video is scaled to this width (0 = full size). The AI always sees the full picture")
p.add_argument("--detect-fps", type=float, default=6, help="max AI runs per second (0 = as fast as the computer allows). Leaves CPU free for smooth video")
p.add_argument("--loop", action="store_true", help="video files: play again at the end (for testing)")
p.add_argument("--stats-every", type=float, default=5, help="seconds between [perf] lines (0 = off)")
a = p.parse_args()
if not a.no_preview:  # the "headless" OpenCV build has no windows: keep running (dashboard stream still works) instead of crashing
    try:
        cv.namedWindow("probe"); cv.destroyWindow("probe")
    except cv.error:
        a.no_preview = True
        print("[preview] This OpenCV has no window support (opencv-python-headless). Running WITHOUT the preview window; "
              "the dashboard stream still works. To get the window: pip uninstall -y opencv-python-headless opencv-python "
              "&& pip install opencv-python")
if not Path(a.model).is_file():
    raise SystemExit(f"\n[model] Model file not found: {a.model}\n        723image.pt must be in veritas-cv-main\\models.\n")

MODEL_NAME = Path(a.model).name   # defined before the stream server starts: /health can be asked while the model is still loading
KEY = os.getenv("INGEST_KEY", "")
if not KEY:
    raise SystemExit("INGEST_KEY is missing. Put it in .env (same value as the backend).")
HDR = {"X-API-Key": KEY}
APPS_SCRIPT = "script.google.com" in a.backend  # Apps Script takes one URL; path and key travel in the body


def _backend_key():
    f = Path(__file__).resolve().parents[1] / "veritas-backend" / ".env"
    if os.getenv("AI_INGEST_KEY"):
        return os.getenv("AI_INGEST_KEY")
    try:
        from dotenv import dotenv_values
        return (dotenv_values(f).get("INGEST_KEY") or "") if f.is_file() else ""
    except Exception:
        return ""


AI_KEY = _backend_key() or KEY


def colour(n):  # same idea as veritascli.get_color
    seed(n)
    return tuple(randint(0, 255) for _ in range(3))


# ---- video stream for the dashboard (MJPEG) ----
stop = threading.Event()


class Bus:
    """Hands the newest JPEG to every dashboard connection. A connection that is slow just skips frames - it never queues them."""
    def __init__(self):
        self.cv, self.jpg, self.seq, self.clients = threading.Condition(), None, 0, 0

    def publish(self, jpg):
        with self.cv:
            self.jpg, self.seq = jpg, self.seq + 1
            self.cv.notify_all()

    def wait(self, last, timeout):
        with self.cv:
            if self.seq == last:
                self.cv.wait(timeout)
            return self.seq, self.jpg


bus = Bus()
perf = {}   # filled in by the stats thread, served on /health
BOOT = str(int(time.time() * 1000))   # changes every time the bridge starts, so the dashboard knows to rebuild its video element


def _infer_running():
    try:                                  # the stream server starts before the model is loaded: answer "not yet" instead of failing
        return ai_state_now()["inference_running"]
    except NameError:
        return False


class Feed(BaseHTTPRequestHandler):
    timeout = 15                       # a stalled or vanished browser connection frees its thread instead of hanging forever

    def _send_bytes(self, code, ctype, body):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?")[0]
        try:
            if path == "/health":      # tiny and cheap: the dashboard checks THIS instead of opening the video stream
                return self._send_bytes(200, "application/json", json.dumps(
                    {"ok": True, "boot": BOOT, "camera_id": a.camera_id, "camera_ok": cam_state["ok"], "model": MODEL_NAME, "inference_running": _infer_running(), **perf}).encode())
            if path == "/snapshot.jpg":
                if bus.jpg is None:
                    return self.send_error(503, "no frame yet")
                return self._send_bytes(200, "image/jpeg", bus.jpg)
            if path != "/video_feed":
                return self.send_error(404)
            feed = bus
            self.send_response(200)
            self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=frame")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            try:
                self.connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            except OSError:
                pass
            with feed.cv:
                feed.clients += 1
            try:
                last = 0
                while not stop.is_set():
                    seq, jpg = feed.wait(last, 2.0)        # sleeps until there is a NEW frame (keep-alive resend every 2 s)
                    if jpg is None:
                        continue
                    last = seq
                    self.wfile.write(b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: %d\r\n\r\n" % len(jpg) + jpg + b"\r\n")
            finally:
                with feed.cv:
                    feed.clients -= 1
        except OSError:
            pass                                           # browser closed the tab / reloaded: normal on Windows (ConnectionAbortedError)

    def log_message(self, *x):
        pass


class Server(ThreadingHTTPServer):
    daemon_threads = True

    def handle_error(self, request, client_address):
        if isinstance(sys.exc_info()[1], OSError):
            return                                          # a dropped browser connection is not an error worth a traceback
        super().handle_error(request, client_address)


try:
    srv = Server(("127.0.0.1", a.stream_port), Feed)
except OSError as e:
    raise SystemExit(f"\n[stream] Port {a.stream_port} is already in use ({e}). Is another VERITAS bridge still running? "
                     "Close it, or give this one its own port with --stream-port (one port per camera).\n")
threading.Thread(target=srv.serve_forever, daemon=True, name="stream-server").start()

# ---- background sender so a slow network never freezes the camera ----
q = queue.Queue(maxsize=50)


def sender():
    while True:
        path, body = q.get()
        try:
            if APPS_SCRIPT:
                r = requests.post(a.backend, data=json.dumps({**body, "path": path.replace("/api/", "", 1), "key": KEY}),
                                  headers={"Content-Type": "text/plain;charset=utf-8"}, timeout=30)
                r.raise_for_status()
                err = r.json().get("error") if r.content else None
                if err:
                    print(f"[send] sheet said: {err}")
            else:
                requests.post(a.backend + path, json=body, headers=HDR, timeout=5).raise_for_status()
        except Exception as e:
            print(f"[send] failed: {e}")


threading.Thread(target=sender, daemon=True).start()


cam_state = {"ok": False}  # the dashboard should only say "Connected" while the camera really gives pictures


def heartbeat():
    last = 0
    while True:
        if cam_state["ok"] and time.time() - last >= 30:  # Apps Script has a daily run-time quota, so beat gently
            last = time.time()
            try:
                q.put_nowait(("/api/ingest/camera", {"camera_id": a.camera_id, "location": a.location,
                                                     "stream_url": f"http://127.0.0.1:{a.stream_port}/video_feed"}))
            except queue.Full:
                pass
        time.sleep(1)


threading.Thread(target=heartbeat, daemon=True).start()

# ---- camera ----
CAM = dict(source=a.camera, name=a.camera_name, backend=a.camera_backend,
           width=a.width, height=a.height, fps=a.fps, fourcc=a.fourcc)
try:
    cap, cam_info = camera_utils.open_camera(**CAM)
except camera_utils.CameraError as e:
    raise SystemExit(f"\n[camera] ERROR: {e}\n")
is_device = cam_info["kind"] == "device"
print(f"[camera] using {cam_info['label']} at {cam_info['width']}x{cam_info['height']}"
      + (f", {cam_info['fps']:g} fps" if cam_info["fps"] else "") + f" (backend: {cam_info['backend']})")
for w_ in cam_info["warnings"]:
    print(f"[camera] WARNING: {w_}")
cam_state["ok"] = True
WIN = f"VERITAS bridge - {cam_info['label']} (q to quit)"


def down_frame(msg):
    img = np.zeros((480, 854, 3), np.uint8)
    cv.putText(img, "CAMERA DISCONNECTED", (40, 200), cv.FONT_HERSHEY_SIMPLEX, 1.4, (0, 0, 255), 3)
    cv.putText(img, msg[:60], (40, 260), cv.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    cv.putText(img, "Trying to reconnect. Not switching to any other camera.", (40, 310),
               cv.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    return img


class Capture(threading.Thread):
    """Reads the camera continuously and keeps ONLY the newest frame. Because nothing else ever slows this loop down,
    the camera driver's buffer can never fill up with old pictures (the cause of video that drifts further and further behind)."""
    def __init__(self, cap, info):
        super().__init__(daemon=True, name="capture")
        self.cap, self.info = cap, info
        self.cv, self.frame, self.seq, self.t, self.down, self.ended, self.n = threading.Condition(), None, 0, 0.0, False, False, 0

    def _publish(self, frame, down):
        with self.cv:
            self.frame, self.seq, self.t, self.down = frame, self.seq + 1, time.time(), down
            self.n += 0 if down else 1
            self.cv.notify_all()

    def wait_new(self, last, timeout):
        with self.cv:
            if self.seq == last and not self.ended:
                self.cv.wait(timeout)
            return self.seq, self.frame, self.t, self.down, self.ended

    def run(self):
        try:
            self.cap.set(cv.CAP_PROP_BUFFERSIZE, 1)         # best effort; the continuous read below is the real fix
        except Exception:
            pass
        file_dt = 1.0 / (self.info["fps"] if self.info["fps"] and self.info["fps"] < 240 else 30)
        nxt, fails, last_retry, last_note = time.time(), 0, 0.0, 0.0
        while not stop.is_set():
            ok, frame = self.cap.read()
            if ok and frame is not None:
                fails = 0
                if not is_device:                            # a video FILE plays at its own speed, like a camera, not as fast as the CPU allows
                    nxt += file_dt
                    if nxt - time.time() > 0:
                        stop.wait(nxt - time.time())
                    else:
                        nxt = time.time()
                self._publish(frame, False)
                continue
            if not is_device:
                if a.loop:
                    self.cap.set(cv.CAP_PROP_POS_FRAMES, 0)
                    continue
                with self.cv:                                # a video file simply ended
                    self.ended = True
                    self.cv.notify_all()
                return
            fails += 1
            if fails < 15:                                   # ignore a few dropped frames
                time.sleep(0.03)
                continue
            now = time.time()
            if cam_state["ok"]:
                cam_state["ok"] = False
                last_note = now
                print(f"[camera] ERROR: lost {self.info['label']}. Waiting for it to come back. "
                      "NOT switching to another camera.")
            elif now - last_note >= 15:
                last_note = now
                print("[camera] still waiting for the camera...")
            self._publish(down_frame(self.info["label"]), True)
            if now - last_retry >= 3:
                last_retry = now
                self.cap.release()
                try:
                    self.cap, self.info = camera_utils.open_camera(**CAM)   # same choice, re-resolved, never another camera
                    cam_state["ok"], fails = True, 0
                    print(f"[camera] back: {self.info['label']} at {self.info['width']}x{self.info['height']}")
                except camera_utils.CameraError:
                    pass
            time.sleep(0.2)


# ---- AI: ONE model, loaded once ----
from ultralytics import YOLO
model = YOLO(a.model)
use_ocr = a.ocr and plate_ocr.available()
CLASS_NAMES = {int(k): str(v) for k, v in model.names.items()}
CAT_OF = {k: v.strip().lower() for k, v in CLASS_NAMES.items() if v.strip().lower() in ("leanbot", "plate", "pedestrian")}
CAT_COLOUR = {"leanbot": (0, 200, 0), "plate": (0, 0, 255), "pedestrian": (0, 215, 255)}   # BGR: green / red / yellow
print(f"[model] {MODEL_NAME} loaded. Classes in the model file: {CLASS_NAMES}")
for need in ("leanbot", "pedestrian"):
    if need not in CAT_OF.values():
        print(f"[model] WARNING: this model has NO '{need.capitalize()}' class, so {need.capitalize()} detection is NOT available. "
              "Nothing is faked: that dashboard section will say so.")
IGNORED = set(CLASS_NAMES) - set(CAT_OF)
if IGNORED:
    print(f"[model] classes the VERITAS pipeline does not use (ignored, never guessed): {[CLASS_NAMES[i] for i in sorted(IGNORED)]}")
# ---- Tracking identities. ByteTrack (inside model.track) gives every physical object ONE id; this part only USES those ids. ----
# It never decides by itself that two boxes are "the same object" because they are close: only the tracker's id (and, for a
# pedestrian that the tracker re-numbered, a strict one-to-one box-overlap link) does that.
# Confidence or box changes only UPDATE the object; a new record needs a new id that has been seen for --confirm-frames runs.
def run_id():                                            # Apps Script keys a vehicle by run_id:track_id, so a restarted tracker gets its own keys
    return BOOT if book.session == 0 else f"{BOOT}s{book.session}"


book = veritas_identity.ObjectBook(confirm=a.confirm_frames, forget=a.track_forget, relink_s=a.relink_seconds,
                                   gate=a.relink_gate, run_id=run_id)
_last_run = {"t": None, "token": None}


def session_before(now):
    t = _last_run["t"]
    if t is not None and now - t > a.session_gap:
        try:                                             # ByteTrack counts frames, not seconds: after a long gap its old tracks must not be revived
            for tr in model.predictor.trackers:
                tr.reset()
        except Exception:
            pass
        book.new_session(f"no AI frames for {now - t:.0f} s (camera was away)")
    _last_run["t"] = now


def session_after():
    try:
        tok = id(model.predictor.trackers[0])
    except Exception:
        return
    if _last_run["token"] is not None and tok != _last_run["token"]:
        book.new_session("the tracker was restarted, so its ids start again")
    _last_run["token"] = tok


def queue_detection(body):
    try:
        q.put_nowait(("/api/ingest/detection", body))
    except queue.Full:
        print("[send] queue full, dropped one detection")


def queue_ai(path, body):
    try:
        ai_q.put_nowait((path, body))
    except queue.Full:
        pass


def iso(ts):
    return datetime.fromtimestamp(ts, timezone.utc).isoformat(timespec="milliseconds")


def event_body(e, engine, etype, stamp, payload):
    return {"schema": "veritas-event/1", "engine": engine, "event_id": e["event_id"][:64], "event_type": etype, "camera_id": a.camera_id,
            "timestamp": iso(e["first"]), "status": "DETECTED", "confidence": round(e["conf"], 4), "zone_id": "", "track_id": e["rid"],
            "evidence_refs": [], "payload": {**payload, "hits": e["hits"], "first_seen": iso(e["first"]), "last_seen": stamp, "max_confidence": round(e["max"], 4)}}


def detect(frame):
    """ONE model run per frame (ByteTrack inside). Every box is sorted by the model's class NAME into Leanbot / Plate / Pedestrian."""
    now = time.time()
    session_before(now)
    res = model.track(frame, persist=True, tracker=a.tracker, conf=min(a.track_conf, a.conf), verbose=False)[0]
    session_after()
    bots, plates, peds = [], [], []
    for b in res.boxes:
        conf = float(b.conf[0])
        if conf <= a.conf:
            continue
        cls = int(b.cls[0])
        cat = CAT_OF.get(cls)
        if cat is None:                                   # a class this pipeline does not know: never guess
            continue
        x1, y1, x2, y2 = map(int, b.xyxy[0])
        tid = int(b.id[0]) if b.id is not None else None  # None = the tracker has not given this box an id: it is drawn, never recorded
        item = {"name": CLASS_NAMES[cls], "cat": cat, "conf": conf, "box": [x1, y1, x2, y2], "id": tid, "colour": CAT_COLOUR[cat]}
        {"leanbot": bots, "plate": plates, "pedestrian": peds}[cat].append(item)
    stamp = iso(now)
    book.associate("leanbot", bots, now)                  # tracker id first; a new / missing id is matched to an invisible recorded object by position
    book.associate("pedestrian", peds, now)
    for bot in bots:
        e = bot["entry"]
        if e is None or e["seen"] < a.confirm_frames or (e["sent"] and now - e["sent_t"] < a.send_every):
            continue
        first, e["sent"], e["sent_t"] = not e["sent"], True, now
        if first:
            print(f"[record] NEW leanbot #{e['rid']} ({bot['conf'] * 100:.0f}%): {e['why']}")
        bx1, by1, bx2, by2 = bot["box"]
        # a Plate belongs to a Leanbot if the plate's centre is inside the Leanbot box
        mine = [pl for pl in plates
                if bx1 <= (pl["box"][0] + pl["box"][2]) / 2 <= bx2 and by1 <= (pl["box"][1] + pl["box"][3]) / 2 <= by2]
        pl = max(mine, key=lambda z: z["conf"]) if mine else None
        if pl:
            e["pbox"], e["pconf"] = pl["box"], pl["conf"]
            if use_ocr and not e["text"]:                  # read the plate until it has been read once; a read text is kept for this object
                x1, y1, x2, y2 = pl["box"]
                got = plate_ocr.read_plate(frame[max(y1, 0):y2, max(x1, 0):x2])
                if got:
                    e["text"] = got[0]
        src_tag = "ocr" if e["text"] else "none"
        # Apps Script keys one Detections row by run_id:track_id: the first send creates it, every later send UPDATES the same row
        queue_detection({"camera_id": a.camera_id, "leanbot_label": bot["name"], "leanbot_confidence": bot["conf"],
                         "plate_confidence": e["pconf"], "plate_number": e["text"], "plate_text_source": src_tag,
                         "leanbot_box": bot["box"], "plate_box": e["pbox"], "track_id": e["rid"], "run_id": run_id(),
                         "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds")})
        queue_ai("/api/ingest/event", event_body(e, "leanbot", "LEANBOT_DETECTED", stamp, {   # same event_id every time = the hub UPDATES it, never a second row
            "leanbot_label": bot["name"], "plate_number": e["text"], "plate_confidence": e["pconf"], "plate_text_source": src_tag,
            "leanbot_box": bot["box"], "plate_box": e["pbox"], "tracking_session": book.session}))
    for pd in peds:
        e = pd["entry"]
        if e is None or e["seen"] < a.confirm_frames or (e["sent"] and now - e["sent_t"] < a.send_every):
            continue
        if not e["sent"]:
            print(f"[record] NEW pedestrian #{e['rid']} ({pd['conf'] * 100:.0f}%): {e['why']}")
        e["sent"], e["sent_t"] = True, now
        queue_ai("/api/ingest/event", event_body(e, "pedestrian", "PEDESTRIAN_DETECTED", stamp, {
            "label": pd["name"], "bbox": pd["box"], "model": MODEL_NAME, "tracking_session": book.session,
            "notes": "Pedestrian seen by the unified AI model. Crossing and crosswalk events need a calibrated crosswalk, which is not set up."}))
    book.forget(now)
    return bots + plates + peds


class Detector(threading.Thread):
    """Takes the NEWEST frame whenever it is free and skips everything in between, so frames can never pile up behind a slow AI."""
    def __init__(self, capture):
        super().__init__(daemon=True, name="ai")
        self.cap_, self.lock, self.result, self.last, self.done, self.skipped, self.ms = capture, threading.Lock(), None, 0, 0, 0, 0.0

    def get(self):
        with self.lock:
            return self.result

    def run(self):
        gap, nxt = (1.0 / a.detect_fps if a.detect_fps > 0 else 0.0), 0.0
        while not stop.is_set():
            if gap and nxt - time.time() > 0:
                stop.wait(nxt - time.time())                      # rate limit FIRST, then grab the newest frame (never a stale one)
            seq, frame, t_cap, down, ended = self.cap_.wait_new(self.last, 0.5)
            if ended and seq == self.last:
                return
            if seq == self.last or frame is None:
                continue
            if self.last:
                self.skipped += seq - self.last - 1
            self.last = seq
            if down:
                with self.lock:
                    self.result = None
                continue
            t0 = time.time()
            try:
                items = detect(frame)
            except Exception as e:                                # one bad frame must not kill the AI thread
                print(f"[ai] error on one frame, continuing: {e}")
                stop.wait(0.5)
                continue
            dt = time.time() - t0
            self.ms = dt * 1000 if not self.done else 0.8 * self.ms + 0.2 * dt * 1000
            self.done += 1
            nxt = t0 + gap
            with self.lock:
                self.result = {"t": time.time(), "items": items}


def draw_overlay(view, items):
    for it in items:
        x1, y1, x2, y2 = it["box"]
        cv.rectangle(view, (x1, y1), (x2, y2), it["colour"], 2)
        tag = f"{it['name']} {it['conf'] * 100:.0f}%" + (f" #{it['id']}" if it["id"] is not None else "")
        cv.putText(view, tag, (x1, max(y1 - 10, 20)), cv.FONT_HERSHEY_SIMPLEX, 0.6, it["colour"], 2)


def rss_mb():
    try:
        with open("/proc/self/status") as f:                      # Linux only; the number is just for leak testing
            for line in f:
                if line.startswith("VmRSS"):
                    return round(int(line.split()[1]) / 1024)
    except OSError:
        pass
    return None


shown = {"n": 0}
capture = Capture(cap, cam_info)
detector = Detector(capture)

# ---- live state + events for the dashboard (FastAPI backend). Real values only: nothing here is simulated. ----
ai_q = queue.Queue(maxsize=200)
AI_LINK = {"ok": None}


def ai_state_now(stopping=False):
    """What the dashboard shows for 'model loaded / camera connected / inference running' and the boxes of the newest frame."""
    res, now = detector.get(), time.time()
    running = bool(res and cam_state["ok"] and detector.is_alive() and now - res["t"] < 5)
    items = res["items"] if running else []
    return {"camera_id": a.camera_id, "model": MODEL_NAME, "model_loaded": True, "camera_connected": bool(cam_state["ok"]),
            "inference_running": running, "stopping": stopping, "fps": perf.get("detect_fps"), "inference_ms": perf.get("inference_ms"),
            "frame_size": [cam_info["width"], cam_info["height"]], "classes": list(CLASS_NAMES.values()),
            "detections": [{"category": it["cat"], "label": it["name"], "confidence": round(it["conf"], 4),
                            "box": it["box"], "track_id": it["id"]} for it in items]}


def ai_post(path, body, tries=1):
    for n in range(tries):
        try:
            r = requests.post(a.ai_backend.rstrip("/") + path, json=body, headers={"X-API-Key": AI_KEY}, timeout=3)
            if r.status_code < 300:
                if AI_LINK["ok"] is not True:
                    print(f"[backend] connected to {a.ai_backend}")
                AI_LINK["ok"] = True
                return True
            if r.status_code in (400, 401, 403, 404, 413, 422):          # retrying cannot fix these
                print(f"[backend] refused {path}: HTTP {r.status_code} {r.text[:240]}")
                AI_LINK["ok"] = False
                return False
            raise RuntimeError(f"HTTP {r.status_code}")
        except Exception as e:
            if AI_LINK["ok"] is not False:
                print(f"[backend] {a.ai_backend} is not reachable ({e}). The dashboard cannot show live AI data until the Backend window is running.")
            AI_LINK["ok"] = False
            time.sleep(0.5)
    return False


def state_loop():
    gap = 1.0 / max(a.state_hz, 0.2)
    while not stop.wait(gap):
        ai_post("/api/ingest/ai-state", ai_state_now())


def event_loop():
    while not stop.is_set():
        try:
            path, body = ai_q.get(timeout=0.5)
        except queue.Empty:
            continue
        ai_post(path, body, tries=3)


threading.Thread(target=state_loop, daemon=True, name="ai-state").start()
threading.Thread(target=event_loop, daemon=True, name="ai-events").start()


def stats_loop():
    last_t, last = time.time(), (0, 0, 0)
    while not stop.wait(1.0):
        now = time.time()
        if now - last_t < max(a.stats_every, 1):
            continue
        dt, cur = now - last_t, (capture.n, shown["n"], detector.done)
        vf, sf, df = [(c - l) / dt for c, l in zip(cur, last)]
        perf.update(camera_fps=round(vf, 1), video_fps=round(sf, 1), detect_fps=round(df, 1), inference_ms=round(detector.ms),
                    ai_skipped_frames=detector.skipped, clients=bus.clients, rss_mb=rss_mb())
        if a.stats_every > 0:
            extra = f" | backend {'ok' if AI_LINK['ok'] else 'NOT reachable'}"
            mem = f" | {perf['rss_mb']} MB" if perf.get("rss_mb") else ""
            print(f"[perf] camera {vf:5.1f} fps | VIDEO shown {sf:5.1f} fps | AI {df:4.1f} runs/s at {detector.ms:4.0f} ms each | "
                  f"AI skipped {detector.skipped} frames to stay live{extra} | viewers {bus.clients}{mem}", flush=True)
        last_t, last = now, cur


print(f"Running {MODEL_NAME}. Dashboard stream: http://127.0.0.1:{a.stream_port}/video_feed  OCR: {'on' if use_ocr else 'off'}"
      f"  (video max {a.stream_fps:g} fps at {a.stream_width or 'full'} px, AI max {a.detect_fps:g}/s)")
capture.start(); detector.start()
threading.Thread(target=stats_loop, daemon=True, name="stats").start()

# ---- main thread: show the newest frame at a steady rate, newest boxes on top ----
interval = 1.0 / a.stream_fps if a.stream_fps > 0 else 0.0
last_seq, next_t = 0, 0.0
try:
    while True:
        seq, frame, t_cap, down, ended = capture.wait_new(last_seq, 0.05 if not a.no_preview else 0.2)
        if ended and seq == last_seq:
            break                                                  # a video file simply ended
        if seq == last_seq or frame is None:
            if not a.no_preview and cv.waitKey(1) & 0xFF == ord("q"):   # keep the window alive even while the camera is silent
                break
            continue
        last_seq, now = seq, time.time()
        if interval and now < next_t - 0.25 * interval:
            continue                                               # more camera frames than the video needs: skip, the next one is coming
        next_t = max(next_t + interval, now - interval) if interval else 0.0
        view, res = frame, detector.get()
        if res and not down and now - res["t"] <= max(1.0, 3 * detector.ms / 1000) and res["items"]:   # boxes older than this are stale: hide them
            view = frame.copy()                                    # never draw on the shared camera frame
            draw_overlay(view, res["items"])
        small = view
        if a.stream_width and view.shape[1] > a.stream_width:
            small = cv.resize(view, (a.stream_width, int(view.shape[0] * a.stream_width / view.shape[1])), interpolation=cv.INTER_AREA)
        if bus.clients:                                            # nobody watching the dashboard: skip the JPEG work
            ok2, jpg = cv.imencode(".jpg", small, [cv.IMWRITE_JPEG_QUALITY, 75])
            if ok2:
                bus.publish(jpg.tobytes())
        shown["n"] += 1
        if not a.no_preview:
            cv.imshow(WIN, view)
            if cv.waitKey(1) & 0xFF == ord("q"):                   # waitKey can cost ~15 ms on Windows: once per SHOWN frame only
                break
except KeyboardInterrupt:
    pass
finally:
    try:
        ai_post("/api/ingest/ai-state", ai_state_now(stopping=True))   # tells the dashboard at once that the AI service has stopped
    except Exception:
        pass
    stop.set()
    capture.join(timeout=2)
    detector.join(timeout=3)
    try:
        capture.cap.release()
    except Exception:
        pass
    try:
        cv.destroyAllWindows()
    except cv.error:
        pass
    srv.shutdown()
    srv.server_close()
    print("[bridge] stopped cleanly")
