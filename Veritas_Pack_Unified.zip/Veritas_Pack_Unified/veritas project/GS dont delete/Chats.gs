/**
 * VERITAS AI chat history (server side). Add as a NEW file in the SAME Apps Script project (+ > Script > "Chats").
 * Saves every AI conversation in two tabs of your Google Sheet ("ChatSessions", "ChatMessages"), created automatically.
 * Needs the 2 hook lines in Code.gs (see README). Reuses httpError, fail, out, nowIso, ADMIN_TOKEN from Code.gs.
 *
 * - Only a request with the admin token can read or write chats (and none can if ADMIN_TOKEN is empty).
 * - Messages carry an id made by the browser, so a retried save can never create a duplicate.
 * - Everyone who has the admin token sees the same conversation list (there are no per-person accounts yet).
 */
const CHAT_COLS = {
  ChatSessions: ["chat_id", "title", "created_at", "updated_at", "owner", "msg_count"],
  ChatMessages: ["msg_id", "chat_id", "seq", "role", "kind", "content", "created_at"]
};
const CHAT_MAX_CONTENT = 20000, CHAT_MAX_BATCH = 12, CHAT_LIST_MAX = 200, CHAT_SEARCH_ROWS = 4000;

function chatSheet_(tab) {
  const ss = SpreadsheetApp.getActiveSpreadsheet(), cols = CHAT_COLS[tab];
  let sh = ss.getSheetByName(tab);
  if (!sh) {
    sh = ss.insertSheet(tab);
    sh.appendRow(cols); sh.setFrozenRows(1); sh.getRange(1, 1, 1, cols.length).setFontWeight("bold");
    sh.getRange(2, 1, Math.max(1, sh.getMaxRows() - 1), cols.length).setNumberFormat("@");   // plain text: Sheets must never reinterpret a message
  }
  return sh;
}
function chatRead_(tab) {
  const sh = chatSheet_(tab), cols = CHAT_COLS[tab], last = sh.getLastRow();
  if (last < 2) return [];
  return sh.getRange(2, 1, last - 1, cols.length).getValues().map(function (r, i) {
    const o = { _row: i + 2 }; cols.forEach(function (c, j) { o[c] = r[j] instanceof Date ? r[j].toISOString() : r[j]; }); return o;
  }).filter(function (o) { return o[cols[0]] !== ""; });
}
function chatPub_(s) { return { chat_id: s.chat_id, title: s.title, created_at: s.created_at, updated_at: s.updated_at, msg_count: Number(s.msg_count) || 0 }; }
function chatTitle_(t) {
  t = String(t || "").replace(/```[\s\S]*?```/g, " ").replace(/[*_`#>]/g, "").replace(/\s+/g, " ").trim();
  return !t ? "New chat" : (t.length > 48 ? t.slice(0, 47) + "\u2026" : t);
}
function chatId_(v) { v = String(v || ""); if (!/^c_[a-z0-9]{6,30}$/.test(v)) throw httpError(422, "Bad conversation id."); return v; }

/** Routes chats/list, chats/get (no write lock needed) and chats/append, chats/rename, chats/delete (called inside the write lock). */
function chatsHandle_(b) {
  try {
    if (!adminTokenOk_(b.token)) {          // a verified admin session, or the legacy shared token while ALLOW_LEGACY_ADMIN_TOKEN is true
      if (!ADMIN_TOKEN && !b.token) throw httpError(403, "Saved chats are disabled until ADMIN_TOKEN is set.");
      throw httpError(401, "Admin token required.");
    }
    switch (String(b.path)) {
      case "chats/list":   return chatsList_(b);
      case "chats/get":    return chatsGet_(b);
      case "chats/append": return chatsAppend_(b);
      case "chats/rename": return chatsRename_(b);
      case "chats/delete": return chatsDelete_(b);
    }
    throw httpError(404, "Unknown chat path.");
  } catch (err) { return fail(err && err.http || 500, String(err && err.message || err)); }
}

function chatsList_(b) {
  const q = String(b.q || "").trim().toLowerCase().slice(0, 60);
  const sessions = chatRead_("ChatSessions").sort(function (a, c) { return String(c.updated_at).localeCompare(String(a.updated_at)); });
  if (!q) return out({ chats: sessions.slice(0, CHAT_LIST_MAX).map(chatPub_) });
  const snip = {}, sh = chatSheet_("ChatMessages"), last = sh.getLastRow();
  if (last >= 2) {                                   // search message text too (newest CHAT_SEARCH_ROWS messages)
    const first = Math.max(2, last - CHAT_SEARCH_ROWS + 1);
    sh.getRange(first, 2, last - first + 1, 5).getValues().forEach(function (r) {   // columns 2..6: chat_id, seq, role, kind, content
      const text = String(r[4] || ""), i = text.toLowerCase().indexOf(q);
      if (i >= 0 && !snip[r[0]]) snip[r[0]] = (i > 30 ? "\u2026" : "") + text.slice(Math.max(0, i - 30), i + q.length + 40).replace(/\s+/g, " ");
    });
  }
  const hits = sessions.filter(function (s) { return String(s.title).toLowerCase().indexOf(q) >= 0 || snip[s.chat_id]; });
  return out({ chats: hits.slice(0, CHAT_LIST_MAX).map(function (s) { const p = chatPub_(s); if (snip[s.chat_id]) p.snippet = snip[s.chat_id]; return p; }) });
}

function chatMsgRows_(chatId) {            // row numbers of one conversation's messages, reading only the chat_id column
  const sh = chatSheet_("ChatMessages"), last = sh.getLastRow(), rows = [];
  if (last < 2) return rows;
  sh.getRange(2, 2, last - 1, 1).getValues().forEach(function (r, i) { if (r[0] === chatId) rows.push(i + 2); });
  return rows;
}
function chatsGet_(b) {
  const id = chatId_(b.chat_id), s = chatRead_("ChatSessions").filter(function (x) { return x.chat_id === id; })[0];
  if (!s) throw httpError(404, "Conversation not found.");
  const sh = chatSheet_("ChatMessages"), msgs = [];
  chatMsgRows_(id).forEach(function (row) {
    const v = sh.getRange(row, 1, 1, 7).getValues()[0];
    msgs.push({ id: v[0], seq: Number(v[2]) || 0, role: v[3], kind: v[4], content: String(v[5]), ts: v[6] instanceof Date ? v[6].toISOString() : String(v[6]) });
  });
  msgs.sort(function (a, c) { return a.seq - c.seq; });
  return out({ chat: chatPub_(s), messages: msgs });
}

function chatsAppend_(b) {
  const id = chatId_(b.chat_id), list = Array.isArray(b.messages) ? b.messages.slice(0, CHAT_MAX_BATCH) : [];
  if (!list.length) throw httpError(422, "No messages.");
  const ssh = chatSheet_("ChatSessions"), msh = chatSheet_("ChatMessages"), now = nowIso();
  let s = chatRead_("ChatSessions").filter(function (x) { return x.chat_id === id; })[0];
  if (!s) { ssh.appendRow([id, "New chat", now, now, String(b.owner || "").slice(0, 40), 0]); s = { chat_id: id, title: "New chat", msg_count: 0, _row: ssh.getLastRow() }; }
  const have = {}, last = msh.getLastRow();
  if (last >= 2) msh.getRange(2, 1, last - 1, 1).getValues().forEach(function (r) { have[r[0]] = 1; });   // ids already stored: this is what stops duplicates
  const fresh = [];
  list.forEach(function (m) {
    const mid = String(m && m.id || "");
    if (!/^m_[a-z0-9_]{6,40}$/.test(mid) || have[mid]) return;
    const role = m.role === "assistant" ? "assistant" : (m.role === "user" ? "user" : "");
    const content = String(m.content == null ? "" : m.content).slice(0, CHAT_MAX_CONTENT);
    if (!role || !content.trim()) return;
    have[mid] = 1;
    fresh.push({ id: mid, role: role, kind: m.kind === "cmd" ? "cmd" : "chat", content: content, ts: isFinite(Date.parse(m.ts)) ? new Date(Date.parse(m.ts)).toISOString() : now });
  });
  let title = s.title;
  if (fresh.length) {
    let seq = Number(s.msg_count) || 0;
    const rows = fresh.map(function (m) { return [m.id, id, ++seq, m.role, m.kind, m.content, m.ts]; });
    const rng = msh.getRange(msh.getLastRow() + 1, 1, rows.length, 7); rng.setNumberFormat("@"); rng.setValues(rows);
    if (!title || title === "New chat") { const u = fresh.filter(function (m) { return m.role === "user"; })[0]; if (u) title = chatTitle_(u.content); }
    ssh.getRange(s._row, 2, 1, 5).setValues([[title, s.created_at || now, now, s.owner || String(b.owner || "").slice(0, 40), seq]]);
  }
  return out({ ok: true, added: fresh.length, title: title });
}

function chatsRename_(b) {
  const id = chatId_(b.chat_id), title = String(b.title || "").replace(/\s+/g, " ").trim().slice(0, 80);
  if (!title) throw httpError(422, "A title is required.");
  const s = chatRead_("ChatSessions").filter(function (x) { return x.chat_id === id; })[0];
  if (!s) throw httpError(404, "Conversation not found.");
  chatSheet_("ChatSessions").getRange(s._row, 2).setValue(title);
  return out({ ok: true, title: title });
}

function chatsDelete_(b) {
  const id = chatId_(b.chat_id), s = chatRead_("ChatSessions").filter(function (x) { return x.chat_id === id; })[0];
  if (!s) throw httpError(404, "Conversation not found.");
  const rows = chatMsgRows_(id), msh = chatSheet_("ChatMessages");
  let end = rows.length - 1;                        // delete bottom-up in contiguous blocks so row numbers stay valid
  while (end >= 0) { let start = end; while (start > 0 && rows[start - 1] === rows[start] - 1) start--; msh.deleteRows(rows[start], end - start + 1); end = start - 1; }
  chatSheet_("ChatSessions").deleteRow(s._row);
  return out({ ok: true, deleted: rows.length });
}
