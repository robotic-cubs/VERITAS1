/**
 * VERITAS backend on Google Apps Script + Google Sheets.
 * Replaces the Python backend (main.py / store.py). Paste this whole file into the
 * Apps Script editor of your Google Sheet (Extensions > Apps Script).
 *
 * Tabs are created for you the first time anything runs.
 * Apps Script web apps only accept GET and POST, so everything goes through one URL:
 *   GET   <url>?path=all            -> everything the dashboard needs
 *   POST  <url>  body {"path": "...", ...}   (sent as text/plain so browsers skip the preflight check)
 */

// ===== SETTINGS =====
const INGEST_KEY = PropertiesService.getScriptProperties().getProperty("INGEST_KEY") || "";  // set in Project Settings > Script properties. Same value goes in veritas-bridge/.env
const ADMIN_TOKEN = PropertiesService.getScriptProperties().getProperty("ADMIN_TOKEN") || "";  // Script property. The dashboard asks for it when you open it

// ---- Administrator access (see portal/Portal.gs: adminTokenOk_) ----
// An administrator is proven by a portal login whose role is "admin" (checked against the Users sheet on every call).
// The old shared ADMIN_TOKEN above ALSO still works while this is true, because admin.html currently has that token typed into it.
// After admin.html has been switched to portal sign-in, set this to false and change/clear ADMIN_TOKEN: then the shared token is dead.
const ALLOW_LEGACY_ADMIN_TOKEN = false;   // the shared token typed into admin.html is gone: only a portal administrator session is accepted
// When true, the public GET reads (?path=all, violations, vehicles, ...) also demand an administrator (token in the request).
// Leave false until admin.html sends its sign-in token on reads, otherwise the dashboard would stop loading.
const REQUIRE_ADMIN_FOR_READS = true;    // dashboard reads (?path=all ...) need the administrator session token (&token=...)
// Live-feed tracking (see ingestDetection). One Detections row = one tracked vehicle on one camera; repeat sightings UPDATE it.
const TRACK_TTL_S = 600;                 // same camera + same tracker id (same bridge run) = same vehicle if seen within this many seconds
const PLATE_TTL_S = 60;                  // tracker id changed but the same readable plate was seen on this camera within this many seconds
const SPATIAL_TTL_S = 4;                 // id changed, no plate: only merge if the box overlaps strongly with exactly one very recent record
const SPATIAL_IOU = 0.6;                 // minimum box overlap (intersection over union) for that spatial merge
const MIN_PLATE_LEN = 4;                 // plate text shorter than this is never used as an identity signal
const TAIL_ROWS = 150;                   // how many of the newest Detections rows are searched for a match
const CAMERA_TIMEOUT = 90;               // seconds without a heartbeat -> "Disconnected"
// Old 3-REGISTER.html lets ANYONE register ANY plate with no login. Leave true until the Driver Portal
// is live, then set to false so plates can only be claimed through portal accounts (admin-verified).
const ALLOW_LEGACY_OPEN_REGISTRATION = true;
// ====================

const SCHEMA = {
  Vehicles: ["leanbot_id", "plate_number", "robot_name", "vehicle_type", "status", "last_location", "last_detection"],
  Detections: ["detection_id", "timestamp", "camera_id", "leanbot_label", "leanbot_confidence", "plate_number",
    "plate_confidence", "plate_text_source", "track_id", "leanbot_box", "plate_box",
    "first_seen", "hits", "track_key", "plate_status", "plate_guess", "status", "note"],   // plate_status = confirmed|unconfirmed|unread; plate_guess = unverified OCR text (never treated as the plate). timestamp = LAST detected. first_seen/hits/track_key were added for per-vehicle tracking.
  Violations: ["violation_id", "plate_number", "violation_type", "date", "time", "location", "camera_id",
    "ai_confidence", "evidence_url", "review_status", "reviewer", "remarks"],
  Cameras: ["camera_id", "location", "stream_url", "last_seen"],
  AuditLog: ["timestamp", "action", "record_id", "reviewer", "remarks"],
  // Display state only (e.g. when each camera's "Latest detections" feed was cleared). Never holds history.
  FeedState: ["key", "value", "updated_at", "updated_by"],
  // ---- Driver Portal tabs (see Portal.gs). Nothing in doGet reads these, so ?path=all never exposes them. ----
  Users: ["user_id", "email", "mobile", "password_hash", "role", "status", "token_version", "first_name", "middle_name",
    "last_name", "birth_date", "address", "city", "province", "postal_code", "license_number", "license_expiry",
    "license_type", "email_verified", "mobile_verified", "pending_email", "pending_mobile", "created_at",
    "must_change_pw", "admin_perms"],   // role: user | admin | super_admin. must_change_pw = "yes" until the person sets their own password. admin_perms: "manage_admins" (optional extra right)
  OwnerVehicles: ["link_id", "user_id", "leanbot_id", "plate_number", "vehicle_type", "make", "model", "year", "color",
    "or_number", "cr_number", "registration_expiry", "verification_status", "effective_from", "ended_at",
    "decided_by", "decided_at", "remarks", "created_at"],
  Payments: ["payment_id", "user_id", "violation_ids", "amount", "currency", "method", "provider", "provider_session",
    "checkout_url", "txn_ref", "user_ref", "payer_name", "status", "created_at", "paid_at", "verified_by",
    "verified_via", "remarks", "receipt_no"],
  Disputes: ["dispute_id", "violation_id", "user_id", "reason", "status", "created_at", "resolved_by", "resolved_at",
    "resolution_note"],
  Fines: ["violation_type", "amount"]
};
const NUMERIC = ["leanbot_confidence", "plate_confidence", "ai_confidence", "track_id", "hits"];

/* ---------- entry points ---------- */
function doGet(e) {
  try {
    const path = (e && e.parameter && e.parameter.path) || "health";
    if (REQUIRE_ADMIN_FOR_READS && path !== "health" && !adminTokenOk_(e.parameter.token)) return fail(401, "Administrator sign-in required.");
    switch (path) {
      case "health":     return out({ ok: true, storage: "sheets" });
      case "all":        return out({ vehicles: listVehicles(), detections: listDetections(),
                                      violations: listViolations(), cameras: listCameras(), feed: readFeedState() });
      case "live":       return out(liveData());                                    // light poll for Live AI Monitoring
      case "vehicles":   return out(listVehicles());
      case "detections": return out(listDetections());
      case "violations": return out(listViolations());
      case "cameras":    return out(listCameras());
      case "feed":       return out(readFeedState());
      case "ai_status":  return out(aiStatus_());                           // VERITAS AI (AI.gs)
      default:           return fail(404, "Unknown path: " + path);
    }
  } catch (err) { return fail(500, String(err && err.message || err)); }
}

function doPost(e) {
  let body;
  try { body = JSON.parse(e.postData.contents); } catch (err) { return fail(400, "Body must be JSON."); }
  if (typeof body.path === "string" && body.path.indexOf("portal/") === 0) return portalHandle(body);   // Driver Portal (Portal.gs)
  if (body.path === "chat" || body.path === "translate") return aiRoute_(body);   // VERITAS AI (AI.gs): read-only, before the write lock
  if (body.path === "chats/list" || body.path === "chats/get") return chatsHandle_(body);   // saved AI chats (Chats.gs): reads need no write lock
  if (body.path === "agent") return agentRoute_(body);   // VERITAS AI controller (Agent.gs): plan only, never changes data
  if (body.path === "agent/ping") return agentPing_(body);   // VERITAS AI: confirms the admin sign-in really works (chat status uses it)
  const lock = LockService.getScriptLock();
  try { lock.waitLock(15000); } catch (err) { return fail(503, "Busy, try again."); }
  try {
    switch (body.path) {
      case "vehicles":
        if (!ALLOW_LEGACY_OPEN_REGISTRATION) return fail(401, "Registration is locked. Use the Driver Portal.");
        return registerVehicle(body);                                    // open: the old 3-REGISTER.html uses this
      case "vehicles/delete":  requireAdmin(body); return unregisterVehicle(body);
      case "violations":       requireAdmin(body); return createViolation(body);
      case "violations/approve": requireAdmin(body); return review(body, "Confirmed");
      case "violations/reject":  requireAdmin(body); return review(body, "Rejected");
      case "feed/clear":       requireAdmin(body); return clearFeed(body);        // hides rows from Latest detections only
      case "chats/append": case "chats/rename": case "chats/delete": return chatsHandle_(body);   // saved AI chats (Chats.gs)
      case "agent/exec":       return agentExec_(body);    // VERITAS AI controller: needs admin token + signed ticket + confirmed:true
      case "agent/audit":      return agentAudit_(body);   // VERITAS AI controller: audit trail for browser-side actions
      case "ingest/camera":    requireIngest(body); return cameraHeartbeat(body);
      case "ingest/detection": requireIngest(body); return ingestDetection(body);
      default:                 return fail(404, "Unknown path: " + body.path);
    }
  } catch (err) {
    if (err && err.http) return fail(err.http, err.message);
    return fail(500, String(err && err.message || err));
  } finally { lock.releaseLock(); }
}

/** Run this once from the editor (select "setup" and press Run) to create the tabs and approve permissions. */
function setup() {
  Object.keys(SCHEMA).forEach(sheetFor);
  Logger.log("Tabs ready: " + Object.keys(SCHEMA).join(", "));
}

/* ---------- auth ---------- */
function httpError(code, msg) { const e = new Error(msg); e.http = code; return e; }
function requireAdmin(b) {
  if (adminTokenOk_(b.token)) return;                                   // a verified admin session, or the legacy shared token while it is allowed
  if (!ADMIN_TOKEN && ALLOW_LEGACY_ADMIN_TOKEN) return;                 // legacy behaviour: no token configured = open
  throw httpError(401, "Admin token required.");
}
function requireIngest(b) {
  if (!INGEST_KEY) throw httpError(503, "INGEST_KEY is not set.");
  if (b.key !== INGEST_KEY) throw httpError(401, "Bad API key.");
}

/* ---------- output ---------- */
function out(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
function fail(status, msg) { return out({ error: msg, status: status }); }

/* ---------- sheet helpers ---------- */
function sheetFor(tab) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(tab);
  const cols = SCHEMA[tab];
  if (!sh) {
    sh = ss.insertSheet(tab);
    sh.appendRow(cols);
    sh.setFrozenRows(1);
    sh.getRange(1, 1, 1, cols.length).setFontWeight("bold");
    // Plain-text cells so Sheets never turns "2026-11-04" or "ABC 123" into something else.
    sh.getRange(2, 1, sh.getMaxRows() - 1, cols.length).setNumberFormat("@");
  }
  ensureColumns_(sh, tab);
  return sh;
}

/** Older sheets were created before new columns existed. Append the missing header cells (once per run). */
const _colsChecked = {};
function ensureColumns_(sh, tab) {
  if (_colsChecked[tab]) return;
  _colsChecked[tab] = true;
  const cols = SCHEMA[tab], have = sh.getLastColumn();
  if (have >= cols.length || have < 1) return;
  const hdr = sh.getRange(1, 1, 1, have).getValues()[0];
  for (let i = 0; i < have; i++) if (hdr[i] !== cols[i]) return;   // someone rearranged the sheet: leave it alone
  sh.getRange(1, have + 1, 1, cols.length - have).setValues([cols.slice(have)]).setFontWeight("bold");
  sh.getRange(2, have + 1, Math.max(1, sh.getMaxRows() - 1), cols.length - have).setNumberFormat("@");
}

function readAll(tab) {
  const cols = SCHEMA[tab], sh = sheetFor(tab), last = sh.getLastRow();
  if (last < 2) return [];
  const vals = sh.getRange(2, 1, last - 1, cols.length).getValues();
  const rows = [];
  vals.forEach(function (r) {
    if (r[0] === "" || r[0] === null) return;
    const o = {};
    cols.forEach(function (c, i) {
      let v = r[i];
      if (v instanceof Date) v = v.toISOString();
      if (NUMERIC.indexOf(c) >= 0 && v !== "" && !isNaN(Number(v))) v = Number(v);
      o[c] = v;
    });
    rows.push(o);
  });
  return rows;
}

function cell(v) {
  if (v === null || v === undefined) return "";
  if (typeof v === "object") return JSON.stringify(v);
  return v;
}

function appendRow(tab, row) {
  const sh = sheetFor(tab), cols = SCHEMA[tab];
  const r = sh.getLastRow() + 1;
  const rng = sh.getRange(r, 1, 1, cols.length);
  rng.setNumberFormat("@");
  rng.setValues([cols.map(function (c) { return cell(row[c]); })]);
}

function findRow(sh, colIndex, key) {   // returns sheet row number or 0
  const last = sh.getLastRow();
  if (last < 2) return 0;
  const keys = sh.getRange(2, colIndex, last - 1, 1).getValues();
  for (let i = 0; i < keys.length; i++) if (String(keys[i][0]) === String(key)) return i + 2;
  return 0;
}

function updateRow(tab, keyField, key, updates) {
  const sh = sheetFor(tab), cols = SCHEMA[tab];
  const r = findRow(sh, cols.indexOf(keyField) + 1, key);
  if (!r) return false;
  Object.keys(updates).forEach(function (f) {
    const i = cols.indexOf(f);
    if (i >= 0) sh.getRange(r, i + 1).setNumberFormat("@").setValue(cell(updates[f]));
  });
  return true;
}

function deleteRow(tab, keyField, key) {
  const sh = sheetFor(tab), cols = SCHEMA[tab];
  const r = findRow(sh, cols.indexOf(keyField) + 1, key);
  if (!r) return false;
  sh.deleteRow(r);
  return true;
}

function nowIso() { return new Date().toISOString().replace(/\.\d+Z$/, "+00:00"); }
function shortId(prefix) { return prefix + Utilities.getUuid().replace(/-/g, "").slice(0, 8).toUpperCase(); }

function normalizePlate(text) {
  const s = String(text || "").replace(/[^A-Za-z0-9]/g, "").toUpperCase();
  const m = s.match(/^([A-Z]+)(\d+)$/);
  return m ? m[1] + " " + m[2] : s;
}

/* ---------- reads ---------- */
function listVehicles() { return readAll("Vehicles"); }
function listDetections() {
  return readAll("Detections").sort(function (a, b) { return String(b.timestamp).localeCompare(String(a.timestamp)); }).slice(0, 500);
}
function listViolations() {
  return readAll("Violations").sort(function (a, b) {
    return (b.date + " " + b.time).localeCompare(a.date + " " + a.time);
  });
}
function listCameras() {
  return readAll("Cameras").map(function (c) {
    const age = (Date.now() - new Date(String(c.last_seen)).getTime()) / 1000;
    c.status = (isFinite(age) && age < CAMERA_TIMEOUT) ? "Connected" : "Disconnected";
    return c;
  });
}

/* ---------- writes ---------- */
function registerVehicle(b) {
  const plate = normalizePlate(b.plate_number);
  if (!plate) return fail(422, "Plate number is required.");
  const all = readAll("Vehicles");
  if (all.some(function (v) { return normalizePlate(v.plate_number) === plate; }))
    return fail(409, "That plate is already registered.");
  let id = String(b.leanbot_id || "").trim();
  if (!id) {   // next LB-00N
    const top = all.reduce(function (m, v) { return Math.max(m, parseInt(String(v.leanbot_id).replace(/\D/g, ""), 10) || 0); }, 0);
    id = "LB-" + ("000" + (top + 1)).slice(-3);
  }
  const row = { leanbot_id: id, plate_number: plate, robot_name: String(b.robot_name || "").trim(),
    vehicle_type: b.vehicle_type || "Leanbot", status: b.status || "Active", last_location: "", last_detection: "" };
  appendRow("Vehicles", row);
  return out(row);
}

function unregisterVehicle(b) {
  // Only removes the registration. Past detections and violations stay on record.
  if (!deleteRow("Vehicles", "leanbot_id", b.id)) return fail(404, "Vehicle not found.");
  appendRow("AuditLog", { timestamp: nowIso(), action: "Unregistered", record_id: b.id, reviewer: "Admin", remarks: "" });
  return out({ ok: true });
}

function createViolation(b) {
  const n = nowIso();
  const row = { violation_id: shortId("VIO-"), plate_number: normalizePlate(b.plate_number),
    violation_type: b.violation_type || "", date: n.slice(0, 10), time: n.slice(11, 19), location: b.location || "",
    camera_id: b.camera_id || "", ai_confidence: b.ai_confidence === undefined ? "" : b.ai_confidence,
    evidence_url: b.evidence_url || "", review_status: "Pending", reviewer: "", remarks: "" };
  appendRow("Violations", row);
  return out(row);
}

function review(b, status) {
  const rec = readAll("Violations").filter(function (v) { return v.violation_id === b.id; })[0];
  if (!rec) return fail(404, "Violation not found.");
  if (rec.review_status !== "Pending") return fail(409, "Already " + rec.review_status + ".");
  const remarks = String(b.remarks || "");
  if (status === "Rejected" && !remarks.trim()) return fail(422, "A remark is required to reject.");
  const upd = { review_status: status, reviewer: b.reviewer || "Admin", remarks: remarks };
  updateRow("Violations", "violation_id", b.id, upd);
  appendRow("AuditLog", { timestamp: nowIso(), action: status, record_id: b.id, reviewer: upd.reviewer, remarks: remarks });
  return out(Object.assign({}, rec, upd));
}

/* ---------- camera program (AI bridge) ---------- */
function cameraHeartbeat(b) {
  if (!b.camera_id) return fail(422, "camera_id is required.");
  const upd = { last_seen: nowIso() };
  if (b.location) upd.location = b.location;
  if (b.stream_url) upd.stream_url = b.stream_url;
  if (!updateRow("Cameras", "camera_id", b.camera_id, upd))
    appendRow("Cameras", { camera_id: b.camera_id, location: b.location || "", stream_url: b.stream_url || "", last_seen: upd.last_seen });
  return out({ ok: true });
}

/* ---------- latest-detections tracking ----------
 * One Detections row = one tracked vehicle on ONE camera. A repeat sighting updates that row (timestamp = last detected,
 * hits + 1, confidences, plate) instead of appending another one. Cameras are never merged with each other.
 * Identity, strongest signal first:
 *   1. same camera + same tracker id from the same bridge run          (track_key = run_id:track_id)
 *   2. tracker id changed, but the same readable plate was seen on this camera within PLATE_TTL_S
 *   3. tracker id changed, no plate evidence: box overlaps (IoU >= SPATIAL_IOU) exactly ONE record seen < SPATIAL_TTL_S ago
 * Anything else becomes a new row: two detections we cannot confidently link are kept apart. */

function parseBox_(v) {
  if (typeof v === "string") { try { v = JSON.parse(v); } catch (e) { return null; } }
  return (Array.isArray(v) && v.length >= 4 && v.slice(0, 4).every(function (n) { return n !== "" && n !== null && isFinite(Number(n)); }))
    ? v.slice(0, 4).map(Number) : null;
}
function iou_(a, b) {
  const w = Math.min(a[2], b[2]) - Math.max(a[0], b[0]), h = Math.min(a[3], b[3]) - Math.max(a[1], b[1]);
  if (w <= 0 || h <= 0) return 0;
  const inter = w * h, u = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter;
  return u > 0 ? inter / u : 0;
}
function usablePlate_(p) { return String(p || "").replace(/[^A-Z0-9]/gi, "").length >= MIN_PLATE_LEN; }
function ms_(v) { const t = new Date(String(v)).getTime(); return isFinite(t) ? t : 0; }

/** cands: [{row, rec}] on the same camera. d: {tsMs, trackKey, plate, box, label}. Returns {row, rec, why} or null. */
function matchDetection_(cands, d) {
  const age = function (c) { return (d.tsMs - ms_(c.rec.timestamp)) / 1000; };
  const newest = cands.slice().sort(function (a, b) { return ms_(b.rec.timestamp) - ms_(a.rec.timestamp); });
  if (d.trackKey) {                                                              // 1. tracker id
    const hit = newest.filter(function (c) { return c.rec.track_key === d.trackKey && age(c) <= TRACK_TTL_S; })[0];
    if (hit) return { row: hit.row, rec: hit.rec, why: "track" };
  }
  if (usablePlate_(d.plate)) {                                                   // 2. same plate, new tracker id
    const hit = newest.filter(function (c) { return normalizePlate(c.rec.plate_number) === d.plate && age(c) <= PLATE_TTL_S; })[0];
    if (hit) return { row: hit.row, rec: hit.rec, why: "plate" };
  }
  if (d.box) {                                                                   // 3. spatial continuity, unique candidate only
    const near = newest.filter(function (c) {
      if (age(c) > SPATIAL_TTL_S || age(c) < -SPATIAL_TTL_S) return false;
      if (c.rec.leanbot_label !== d.label) return false;
      const cp = normalizePlate(c.rec.plate_number);
      if (usablePlate_(cp) && usablePlate_(d.plate) && cp !== d.plate) return false;   // two different readable plates = two vehicles
      const cb = parseBox_(c.rec.leanbot_box);
      return !!cb && iou_(cb, d.box) >= SPATIAL_IOU;
    });
    if (near.length === 1) return { row: near[0].row, rec: near[0].rec, why: "spatial" };
  }
  return null;
}

function readTailRows(tab, n) {
  const cols = SCHEMA[tab], sh = sheetFor(tab), last = sh.getLastRow();
  if (last < 2) return [];
  const first = Math.max(2, last - n + 1);
  const vals = sh.getRange(first, 1, last - first + 1, cols.length).getValues(), rows = [];
  vals.forEach(function (r, i) {
    if (r[0] === "" || r[0] === null) return;
    const o = {};
    cols.forEach(function (c, j) {
      let v = r[j];
      if (v instanceof Date) v = v.toISOString();
      if (NUMERIC.indexOf(c) >= 0 && v !== "" && !isNaN(Number(v))) v = Number(v);
      o[c] = v;
    });
    rows.push({ row: first + i, rec: o });
  });
  return rows;
}

function writeRow_(tab, rowNum, rec) {            // one write for the whole row (updateRow does one call per cell)
  const sh = sheetFor(tab), cols = SCHEMA[tab], rng = sh.getRange(rowNum, 1, 1, cols.length);
  rng.setNumberFormat("@");
  rng.setValues([cols.map(function (c) { return cell(rec[c]); })]);
}

function ingestDetection(b) {
  const camera = b.camera_id || "CAM-001";
  const hasTrack = b.track_id !== null && b.track_id !== undefined && b.track_id !== "";
  const ts = b.timestamp || nowIso(), plate = normalizePlate(b.plate_number);
  const rnd = function (x) { return (x === null || x === undefined || x === "") ? "" : Math.round(Number(x) * 1000) / 1000; };
  const label = b.leanbot_label || "Leanbot", box = parseBox_(b.leanbot_box);
  const trackKey = hasTrack ? String(b.run_id || "") + ":" + b.track_id : "";
  const d = { tsMs: ms_(ts) || Date.now(), trackKey: trackKey, plate: plate, box: box, label: label };

  const cands = readTailRows("Detections", TAIL_ROWS).filter(function (c) { return c.rec.camera_id === camera; });
  const m = matchDetection_(cands, d);
  let id, status;
  if (m) {                                                    // ---- same vehicle seen again: update its record ----
    const r = m.rec;
    const newer = d.tsMs >= ms_(r.timestamp);                 // a late, out-of-order message must not move "last detected" back
    if (newer) { r.timestamp = ts; r.leanbot_confidence = rnd(b.leanbot_confidence); r.leanbot_box = b.leanbot_box || r.leanbot_box; }
    r.hits = (Number(r.hits) || 1) + 1;
    if (!r.first_seen) r.first_seen = r.timestamp;
    if (hasTrack && newer) { r.track_id = b.track_id; r.track_key = trackKey; }
    if (plate) {                                              // a readable plate is never erased by an unreadable frame
      const oldP = normalizePlate(r.plate_number), pc = rnd(b.plate_confidence), pcv = pc === "" ? -1 : pc,
        ocv = (r.plate_confidence === "" || r.plate_confidence == null) ? -1 : Number(r.plate_confidence);
      if (!oldP || oldP === plate || pcv > ocv) {                // first read, same read again, or a more confident different read
        r.plate_number = plate; r.plate_text_source = b.plate_text_source || "ocr";
        const best = oldP === plate ? Math.max(pcv, ocv) : pcv;
        r.plate_confidence = best < 0 ? "" : best;
        r.plate_box = b.plate_box || r.plate_box;
      }
    } else if (b.plate_confidence !== null && b.plate_confidence !== undefined && b.plate_confidence !== "" && !normalizePlate(r.plate_number)) {
      r.plate_confidence = rnd(b.plate_confidence); r.plate_box = b.plate_box || r.plate_box;   // plate box seen, text still unread
    }
    if (normalizePlate(r.plate_number)) { r.plate_status = "confirmed"; r.plate_guess = ""; }   // only a confirmed read ever fills plate_number
    else { r.plate_status = b.plate_status || r.plate_status || "unread"; if (b.plate_guess) r.plate_guess = String(b.plate_guess); }
    writeRow_("Detections", m.row, r);
    id = r.detection_id; status = "updated";
  } else {                                                    // ---- first sighting of this vehicle ----
    const row = { detection_id: shortId("DET-"), timestamp: ts, camera_id: camera,
      leanbot_label: label, leanbot_confidence: rnd(b.leanbot_confidence), plate_number: plate,
      plate_confidence: rnd(b.plate_confidence), plate_text_source: b.plate_text_source || "none",
      track_id: hasTrack ? b.track_id : "", leanbot_box: b.leanbot_box || "", plate_box: b.plate_box || "",
      first_seen: ts, hits: 1, track_key: trackKey,
      plate_status: plate ? "confirmed" : (b.plate_status || "unread"), plate_guess: plate ? "" : String(b.plate_guess || "") };
    appendRow("Detections", row);
    id = row.detection_id; status = "saved";
  }
  if (plate) {
    const veh = readAll("Vehicles").filter(function (v) { return normalizePlate(v.plate_number) === plate; })[0];
    if (veh) {
      const cam = readAll("Cameras").filter(function (c) { return c.camera_id === camera; })[0];
      updateRow("Vehicles", "leanbot_id", veh.leanbot_id, { last_detection: ts, last_location: cam ? cam.location : "" });
    }
  }
  return out({ status: status, detection_id: id });
}

/* ---------- live feed (display state only) ---------- */
function readFeedState() {
  const o = {};
  readAll("FeedState").forEach(function (r) { o[r.key] = r.value; });
  return o;
}

/** Light poll for the Live AI Monitoring page: newest rows only, plus what is needed to label them. */
function liveData() {
  const det = readTailRows("Detections", 400).map(function (x) { return x.rec; })
    .sort(function (a, b) { return ms_(b.timestamp) - ms_(a.timestamp); });
  return { detections: det, vehicles: listVehicles(), cameras: listCameras(), feed: readFeedState() };
}

/** "Clear Latest detections". Only records a cutoff per camera; no detection, violation, vehicle or camera row is touched.
 *  The cutoff is the newest detection time already on file for that camera, so it uses the camera program's own clock
 *  (no clock-skew problem) and anything detected or updated after it shows up again. */
function clearFeed(b) {
  const only = b.camera_id && b.camera_id !== "all" ? String(b.camera_id) : "";
  const newest = {};
  readTailRows("Detections", 600).forEach(function (x) {
    const c = x.rec.camera_id, t = ms_(x.rec.timestamp);
    if (only && c !== only) return;
    if (!newest[c] || t > newest[c]) newest[c] = t;
  });
  const by = b.reviewer || "Admin", n = nowIso(), done = {};
  Object.keys(newest).forEach(function (c) {
    const iso = new Date(newest[c]).toISOString(), key = "cleared:" + c;
    if (!updateRow("FeedState", "key", key, { value: iso, updated_at: n, updated_by: by }))
      appendRow("FeedState", { key: key, value: iso, updated_at: n, updated_by: by });
    done[c] = iso;
  });
  appendRow("AuditLog", { timestamp: n, action: "Cleared live feed", record_id: only || "all cameras", reviewer: by,
    remarks: "Display only. Detections, violations, vehicles and camera logs were kept." });
  return out({ ok: true, cleared: done });
}