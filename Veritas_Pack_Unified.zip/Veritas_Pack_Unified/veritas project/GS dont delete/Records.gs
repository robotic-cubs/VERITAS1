/**
 * VERITAS AI record management (server side). Add as a NEW file in the SAME Apps Script project (+ > Script > "Records").
 * Lets the AI controller (Agent.gs) really find, edit, create, delete, de-duplicate, restore and undo records in
 * Detections, Violations and Vehicles. Reuses Code.gs: readAll, appendRow, updateRow, deleteRow, sheetFor, SCHEMA,
 * normalizePlate, nowIso, shortId, createViolation, registerVehicle, ms_, out, fail, httpError.
 *
 * How it stays safe:
 *  - The AI only proposes a SELECTOR (ids and/or filters). The server resolves it against the real sheet at plan time, shows the
 *    exact records, and signs the resulting id list. Execution can touch ONLY those ids.
 *  - Every change is first written to the "AgentJournal" tab (a full copy of what was there), so deleted records can be
 *    restored and edits undone. Permanent removal happens only through record.purge_trash, which always asks first.
 *  - After every write the sheet is read again and the result is checked; the answer says whether it verified.
 *  - Not reachable from here: users, passwords, tokens, driver-portal data (accounts, payments, disputes, fines), settings, files.
 */
const REC = {
  detections: { tab: "Detections", key: "detection_id", noun: "detection",
    fields: { status: ["open", "resolved", "dismissed"], note: "text:200", plate_number: "plate" } },
  violations: { tab: "Violations", key: "violation_id", noun: "violation",
    fields: { violation_type: "text:80", location: "text:100", remarks: "text:300", plate_number: "plate", evidence_url: "url" } },
  vehicles:   { tab: "Vehicles", key: "leanbot_id", noun: "vehicle",
    fields: { robot_name: "text:60", vehicle_type: "text:30", status: ["Active", "Inactive"] } }
};
const REC_MAX = 500, REC_CONFIRM_ABOVE = 5, REC_BULK_WRITE = 30, DUP_GAP_S = 120;
const REC_JCOLS = ["op_id", "batch_id", "ts", "actor", "tool", "table", "key", "action", "before", "after", "status"];
const REC_CAM = { "1": "CAM-PI", "2": "CAM-001" };
const REC_TOOLS_TABLES = { "record.find": ["detections", "violations", "vehicles"], "record.delete": ["detections", "violations", "vehicles"],
  "record.update": ["detections", "violations", "vehicles"], "record.restore": ["detections", "violations", "vehicles"],
  "record.create": ["violations", "vehicles"], "record.dedupe": ["detections", "violations"] };

/* ---------- validation: rebuild every argument from a strict schema; anything else is dropped or refused ---------- */
function recText_(v, max) { return String(v === undefined || v === null ? "" : v).replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, max); }
function recVal_(rule, v, label) {
  if (Array.isArray(rule)) { const s = String(v === undefined || v === null ? "" : v).toLowerCase(); const hit = rule.filter(function (x) { return String(x).toLowerCase() === s; })[0];
    if (hit === undefined) return { error: label + " must be one of: " + rule.join(", ") }; return { v: hit }; }
  if (rule === "plate") { const p = normalizePlate(v); if (!/^[A-Z0-9 ]{4,10}$/.test(p) || p.replace(/ /g, "").length < 4) return { error: "that is not a valid plate number" }; return { v: p }; }
  if (rule === "url") { const u = recText_(v, 300); if (u && !/^https?:\/\/[^\s"'<>]+$/i.test(u)) return { error: "the evidence link must start with http:// or https://" }; return { v: u }; }
  const m = /^text:(\d+)$/.exec(rule); return { v: recText_(v, Number(m[1])) };
}
function recFilterRules_(table) {
  const common = { date: "date", from: "ymd", to: "ymd", older_than_days: "days", all: "bool" };
  if (table === "detections") return Object.assign({ camera: ["1", "2"], plate: "plateq", status: ["open", "resolved", "dismissed"], max_conf: "unit", min_conf: "unit" }, common);
  if (table === "violations") return Object.assign({ camera: ["1", "2"], plate: "plateq", status: ["pending", "confirmed", "rejected"], type: "text:40" }, common);
  return { status: "text:30", plate: "plateq", type: "text:30", all: "bool" };
}
function recSel_(table, sel, allowEmpty) {
  sel = (sel && typeof sel === "object") ? sel : {};
  const out_ = { ids: [], filter: {} };
  if (sel.ids !== undefined) {
    if (!Array.isArray(sel.ids)) return { error: "ids must be a list" };
    if (sel.ids.length > REC_MAX) return { error: "too many ids (maximum " + REC_MAX + " at once)" };
    for (let i = 0; i < sel.ids.length; i++) { const id = String(sel.ids[i]); if (!/^[A-Za-z0-9_\-]{2,40}$/.test(id)) return { error: "bad id" }; if (out_.ids.indexOf(id) < 0) out_.ids.push(id); }
  }
  const f = (sel.filter && typeof sel.filter === "object") ? sel.filter : {}, rules = recFilterRules_(table);
  const keys = Object.keys(f);
  for (let i = 0; i < keys.length; i++) {
    const k = keys[i], rule = rules[k]; if (rule === undefined) return { error: "unknown filter '" + k + "' for " + table };
    const v = f[k];
    if (rule === "date") { const s = String(v).toLowerCase(); if (!/^(today|yesterday|\d{4}-\d{2}-\d{2})$/.test(s)) return { error: "date must be today, yesterday or YYYY-MM-DD" }; out_.filter[k] = s; }
    else if (rule === "ymd") { const s = String(v); if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return { error: k + " must be YYYY-MM-DD" }; out_.filter[k] = s; }
    else if (rule === "days") { const n = Math.floor(Number(v)); if (!(n >= 0 && n <= 3650)) return { error: "older_than_days must be 0-3650" }; out_.filter[k] = n; }
    else if (rule === "unit") { const n = Number(v); if (!(n >= 0 && n <= 1)) return { error: k + " must be between 0 and 1" }; out_.filter[k] = n; }
    else if (rule === "bool") { if (v === true || v === "true") out_.filter[k] = true; else return { error: "'all' must be true" }; }
    else if (rule === "plateq") { const s = recText_(v, 12); if (!s) return { error: "plate filter is empty" }; out_.filter[k] = ({ registered: 1, unregistered: 1, unread: 1 })[s.toLowerCase()] ? s.toLowerCase() : s.toUpperCase(); }
    else { const r = recVal_(rule, v, k); if (r.error) return { error: r.error }; out_.filter[k] = r.v; }
  }
  if (!allowEmpty && !out_.ids.length && !Object.keys(out_.filter).length) return { error: "no target given" };
  return out_;
}
function recSet_(table, set) {
  const rules = REC[table].fields, o = {}; set = (set && typeof set === "object") ? set : {};
  const keys = Object.keys(set); if (!keys.length) return { error: "nothing to change" };
  for (let i = 0; i < keys.length; i++) {
    const k = keys[i]; if (!Object.prototype.hasOwnProperty.call(rules, k)) return { error: "'" + k + "' cannot be edited on " + table + " (editable: " + Object.keys(rules).join(", ") + ")" };
    const r = recVal_(rules[k], set[k], k); if (r.error) return { error: r.error }; o[k] = r.v;
  }
  return { v: o };
}
function recFields_(table, f) {
  f = (f && typeof f === "object") ? f : {}; const o = {};
  if (table === "violations") {
    const t = recText_(f.violation_type, 80); if (!t) return { error: "a violation type is required" }; o.violation_type = t;
    if (f.plate_number) { const p = recVal_("plate", f.plate_number); if (p.error) return { error: p.error }; o.plate_number = p.v; }
    o.location = recText_(f.location, 100);
    const cam = f.camera !== undefined && f.camera !== "" ? f.camera : f.camera_id;      // accepts its own output too, so validating twice gives the same result (the signed ticket depends on that)
    if (cam !== undefined && cam !== "") { const c = String(cam); if (REC_CAM[c]) o.camera_id = REC_CAM[c]; else if (c === REC_CAM["1"] || c === REC_CAM["2"]) o.camera_id = c; else return { error: "camera must be 1 or 2" }; }
    const u = recVal_("url", f.evidence_url); if (u.error) return { error: u.error }; o.evidence_url = u.v;
  } else {
    const p = recVal_("plate", f.plate_number); if (p.error) return { error: "a valid plate number is required" }; o.plate_number = p.v;
    o.robot_name = recText_(f.robot_name, 60); o.vehicle_type = recText_(f.vehicle_type, 30) || "Leanbot";
  }
  return { v: o };
}
function recValidate_(tool, args) {
  args = (args && typeof args === "object") ? args : {}; const o = {};
  if (tool === "record.undo") { if (args.batch_id !== undefined && args.batch_id !== "") { if (!/^b_[a-z0-9]{6,30}$/.test(String(args.batch_id))) return { error: "bad batch id" }; o.batch_id = String(args.batch_id); } return { tool: tool, args: o }; }
  if (tool === "record.purge_trash") { if (args.older_than_days !== undefined && args.older_than_days !== "") { const n = Math.floor(Number(args.older_than_days)); if (!(n >= 0 && n <= 3650)) return { error: "older_than_days must be 0-3650" }; o.older_than_days = n; } return { tool: tool, args: o }; }
  const table = String(args.table || "").toLowerCase();
  if ((REC_TOOLS_TABLES[tool] || []).indexOf(table) < 0) return { error: "table must be one of " + (REC_TOOLS_TABLES[tool] || []).join(", ") };
  o.table = table;
  if (tool === "record.create") { const r = recFields_(table, args.fields); if (r.error) return { error: r.error }; o.fields = r.v; return { tool: tool, args: o }; }
  const s = recSel_(table, args.selector, tool === "record.find" || tool === "record.dedupe"); if (s.error) return { error: s.error }; o.selector = s;
  if (tool === "record.update") { const r = recSet_(table, args.set); if (r.error) return { error: r.error }; o.set = r.v; }
  if (tool === "record.restore" && !s.ids.length) return { error: "restore needs the ids of the records to bring back" };
  if (tool === "record.delete" && !s.ids.length && !Object.keys(s.filter).length) return { error: "no target given" };
  return { tool: tool, args: o };
}

/* ---------- selecting records ---------- */
function recLocalDay_(spec, tz) {            // returns [startMs, endMs) of an admin-local day; tz = JS getTimezoneOffset() minutes
  const now = Date.now() - tz * 60000; let d;
  if (spec === "today") d = new Date(now).toISOString().slice(0, 10); else if (spec === "yesterday") d = new Date(now - 864e5).toISOString().slice(0, 10); else d = spec;
  const s = Date.parse(d + "T00:00:00Z"); return isNaN(s) ? null : [s + tz * 60000, s + tz * 60000 + 864e5];
}
function recTime_(table, r) { return table === "detections" ? ms_(r.timestamp) : table === "violations" ? Date.parse(r.date + "T" + r.time + "Z") : NaN; }
function recSelect_(table, sel, tz) {
  const T = REC[table], f = sel.filter || {}; let rows = readAll(T.tab), missing = [];
  if (sel.ids && sel.ids.length) { const set = {}; sel.ids.forEach(function (i) { set[i] = 1; }); const found = {};
    rows = rows.filter(function (r) { const k = String(r[T.key]); if (set[k]) { found[k] = 1; return true; } return false; });
    missing = sel.ids.filter(function (i) { return !found[i]; }); }
  const reg = {}; if (table === "detections" && f.plate) readAll("Vehicles").forEach(function (v) { reg[normalizePlate(v.plate_number)] = 1; });
  let from = null, to = null;
  if (f.date) { const r = recLocalDay_(f.date, tz); if (r) { from = r[0]; to = r[1]; } }
  if (f.from) { const r = recLocalDay_(f.from, tz); if (r) from = r[0]; }
  if (f.to) { const r = recLocalDay_(f.to, tz); if (r) to = r[1]; }
  if (f.older_than_days !== undefined) to = Math.min(to === null ? Infinity : to, Date.now() - f.older_than_days * 864e5);
  rows = rows.filter(function (r) {
    if (table !== "vehicles") {
      const t = recTime_(table, r);
      if ((from !== null || to !== null) && !isFinite(t)) return false;
      if (from !== null && t < from) return false; if (to !== null && t >= to) return false;
      if (f.camera && r.camera_id !== REC_CAM[f.camera]) return false;
    }
    if (f.status) {
      if (table === "detections") { const s = String(r.status || "open").toLowerCase() || "open"; if (s !== f.status) return false; }
      else if (table === "violations") { if (String(r.review_status).toLowerCase() !== f.status) return false; }
      else if (String(r.status).toLowerCase() !== String(f.status).toLowerCase()) return false;
    }
    if (f.plate) {
      const p = normalizePlate(r.plate_number);
      if (f.plate === "unread") { if (p) return false; } else if (f.plate === "registered") { if (!p || !reg[p]) return false; }
      else if (f.plate === "unregistered") { if (!p || reg[p]) return false; }
      else if (p.replace(/ /g, "").indexOf(String(f.plate).replace(/[^A-Z0-9]/g, "")) < 0) return false;
    }
    if (f.type && String(r.violation_type || r.vehicle_type || "").toLowerCase().indexOf(String(f.type).toLowerCase()) < 0) return false;
    if (f.max_conf !== undefined && !(Number(r.leanbot_confidence) <= f.max_conf)) return false;
    if (f.min_conf !== undefined && !(Number(r.leanbot_confidence) >= f.min_conf)) return false;
    return true;
  });
  rows.sort(function (a, b) { return table === "vehicles" ? 0 : (recTime_(table, b) || 0) - (recTime_(table, a) || 0); });
  return { rows: rows, missing: missing };
}
function recSummary_(table, r, tz) {
  const lt = function (ms) { return isFinite(ms) ? new Date(ms - tz * 60000).toISOString().slice(0, 16).replace("T", " ") : "–"; };
  if (table === "detections") return r.detection_id + " · " + lt(ms_(r.timestamp)) + " · " + r.camera_id + " · plate " + (normalizePlate(r.plate_number) || "unread") + (r.status ? " · " + r.status : "") + (Number(r.hits) > 1 ? " · seen " + r.hits + "×" : "");
  if (table === "violations") return r.violation_id + " · " + (r.violation_type || "–") + " · " + (normalizePlate(r.plate_number) || "unread") + " · " + r.review_status + " · " + lt(recTime_(table, r));
  return r.leanbot_id + " · " + (r.plate_number || "–") + " · " + (r.robot_name || "–") + " · " + (r.status || "–");
}

/* ---------- duplicates ---------- */
function recDupes_(table, sel, tz) {
  const rows = recSelect_(table, sel, tz).rows, groups = {};
  rows.forEach(function (r) {
    const p = normalizePlate(r.plate_number); if (p.replace(/ /g, "").length < MIN_PLATE_LEN) return;            // no readable plate = no safe way to call it a duplicate
    const k = table === "detections" ? r.camera_id + "|" + p : p + "|" + String(r.violation_type).toLowerCase() + "|" + r.camera_id;
    (groups[k] = groups[k] || []).push(r);
  });
  const del = [], keep = [];
  Object.keys(groups).forEach(function (k) {
    const g = groups[k].sort(function (a, b) { return recTime_(table, a) - recTime_(table, b); }); let cluster = [g[0]];
    const close = function () {
      if (cluster.length > 1) {
        const rank = function (r) { return table === "detections" ? (Number(r.hits) || 1) * 1000 + (Number(r.plate_confidence) || 0) * 100 : ({ confirmed: 3, pending: 2, rejected: 1 })[String(r.review_status).toLowerCase()] * 1e9 - recTime_(table, r) / 1e3; };
        const best = cluster.slice().sort(function (a, b) { return rank(b) - rank(a); })[0]; keep.push(best);
        cluster.forEach(function (r) { if (r !== best) del.push(r); });
      }
    };
    for (let i = 1; i < g.length; i++) { if ((recTime_(table, g[i]) - recTime_(table, g[i - 1])) / 1000 <= DUP_GAP_S) cluster.push(g[i]); else { close(); cluster = [g[i]]; } }
    close();
  });
  return { del: del, keep: keep };
}

/* ---------- plan: resolve the selector now, preview it, decide whether a confirmation is needed ---------- */
function recPlan_(tool, args, tz) {
  tz = Number(tz) || 0;
  if (tool === "record.undo") { const j = recJRead_(), b = args.batch_id || recLastBatch_(j); if (!b) return { error: "There is nothing to undo yet." };
    const ops = j.filter(function (r) { return r.batch_id === b && r.status === "applied"; }); if (!ops.length) return { error: "That change was already undone or can no longer be undone." };
    return { ids: [], count: ops.length, preview: { count: ops.length, sample: ops.slice(0, 5).map(function (o) { return o.action + " " + o.table + " " + o.key; }) }, confirm: null, tool_note: ops[0].tool }; }
  if (tool === "record.purge_trash") { const j = recJRead_(), cut = args.older_than_days !== undefined ? Date.now() - args.older_than_days * 864e5 : Infinity;
    const n = j.filter(function (r) { return r.action === "delete" && r.status === "applied" && Date.parse(r.ts) < cut; }).length; if (!n) return { error: "The recovery journal holds no deleted records" + (args.older_than_days !== undefined ? " older than " + args.older_than_days + " days" : "") + "." };
    return { ids: [], count: n, preview: { count: n, sample: [] }, confirm: { need: true, title: "Permanently erase " + n + " recoverable record" + (n === 1 ? "" : "s") + "?", body: "This empties the recovery journal of deleted records" + (args.older_than_days !== undefined ? " older than " + args.older_than_days + " days" : "") + ". After this they can no longer be restored or undone.", ok: "Erase permanently", cls: "dng" } }; }
  const T = REC[args.table], noun = T.noun;
  if (tool === "record.create") return { ids: [], count: 1, preview: { count: 1, sample: Object.keys(args.fields).map(function (k) { return k + ": " + (args.fields[k] || "–"); }) }, confirm: null };
  if (tool === "record.restore") { const j = recJRead_(), want = {}; args.selector.ids.forEach(function (i) { want[i] = 1; });
    const hit = j.filter(function (r) { return r.table === args.table && r.action === "delete" && r.status === "applied" && want[r.key]; }); const ids = hit.map(function (r) { return r.key; }).filter(function (v, i, a) { return a.indexOf(v) === i; });
    if (!ids.length) return { error: "None of those records are in the recovery journal." }; return { ids: ids, count: ids.length, preview: { count: ids.length, sample: ids.slice(0, 5) }, confirm: null }; }
  if (tool === "record.dedupe") {
    const d = recDupes_(args.table, args.selector, tz); const ids = d.del.map(function (r) { return r[T.key]; });
    if (!ids.length) return { ids: [], count: 0, preview: { count: 0, sample: [] }, find: true, rule: recDupeRule_(args.table) };
    if (ids.length > REC_MAX) return { error: "That would remove " + ids.length + " records (maximum " + REC_MAX + " at once). Narrow it with a date or camera." };
    return { ids: ids, count: ids.length, rule: recDupeRule_(args.table), preview: { count: ids.length, sample: d.del.slice(0, 5).map(function (r) { return recSummary_(args.table, r, tz); }) },
      confirm: { need: true, title: "Remove " + ids.length + " duplicate " + noun + (ids.length === 1 ? "" : "s") + "?", body: recDupeRule_(args.table) + " " + d.keep.length + " original" + (d.keep.length === 1 ? " is" : "s are") + " kept. Removed records go to the recovery journal and can be undone.", ok: "Remove duplicates", cls: "dng" } }; }
  const sel = recSelect_(args.table, args.selector, tz), rows = sel.rows;
  if (tool === "record.find") return { ids: rows.slice(0, 200).map(function (r) { return r[T.key]; }), count: rows.length, find: true, preview: { count: rows.length, sample: rows.slice(0, 15).map(function (r) { return recSummary_(args.table, r, tz); }) } };
  if (!rows.length) return { ids: [], count: 0, preview: { count: 0, sample: [], missing: sel.missing }, find: false };
  if (rows.length > REC_MAX) return { error: "That matches " + rows.length + " records (maximum " + REC_MAX + " at once). Narrow it down." };
  const ids = rows.map(function (r) { return r[T.key]; }), sample = rows.slice(0, 5).map(function (r) { return recSummary_(args.table, r, tz); });
  const confirmed = args.table === "violations" ? rows.filter(function (r) { return String(r.review_status).toLowerCase() === "confirmed"; }).length : 0;
  let why = [];
  if (tool === "record.delete") {
    const all = !!(args.selector.filter && args.selector.filter.all);
    if (ids.length > REC_CONFIRM_ABOVE) why.push(ids.length + " records at once"); if (confirmed) why.push(confirmed + " official confirmed violation" + (confirmed === 1 ? "" : "s")); if (args.table === "vehicles") why.push("registry entries"); if (all) why.push("everything in the table");
    return { ids: ids, count: ids.length, preview: { count: ids.length, sample: sample, missing: sel.missing },
      confirm: why.length ? { need: true, title: "Delete " + ids.length + " " + noun + (ids.length === 1 ? "" : "s") + "?", body: "Reason for asking: " + why.join(", ") + ". They move to the recovery journal and can be restored with “undo”.", ok: "Delete " + ids.length, cls: "dng" } : null };
  }
  const ch = Object.keys(args.set).map(function (k) { return k + " → " + (args.set[k] === "" ? "(empty)" : args.set[k]); }).join(", ");
  if (ids.length > REC_CONFIRM_ABOVE) why.push(ids.length + " records at once"); if (confirmed) why.push(confirmed + " official confirmed violation" + (confirmed === 1 ? "" : "s")); if (args.table === "vehicles" && ids.length > 1) why.push("several registry entries");
  return { ids: ids, count: ids.length, preview: { count: ids.length, sample: sample, missing: sel.missing, change: ch },
    confirm: why.length ? { need: true, title: "Change " + ids.length + " " + noun + (ids.length === 1 ? "" : "s") + "?", body: "Change: " + ch + ". Reason for asking: " + why.join(", ") + ". The old values are kept and the change can be undone.", ok: "Apply change", cls: "pri" } : null };
}
function recDupeRule_(table) {
  return table === "detections" ? "A duplicate is a detection on the same camera with the same readable plate seen within " + DUP_GAP_S / 60 + " minutes of another; the entry with the most sightings is kept. Detections without a readable plate are never touched."
    : "A duplicate is a violation with the same plate, type and camera recorded within " + DUP_GAP_S / 60 + " minutes of another; confirmed ones are kept over pending ones.";
}

/* ---------- the recovery journal ---------- */
function recJSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet(); let sh = ss.getSheetByName("AgentJournal");
  if (!sh) { sh = ss.insertSheet("AgentJournal"); sh.appendRow(REC_JCOLS); sh.setFrozenRows(1); sh.getRange(1, 1, 1, REC_JCOLS.length).setFontWeight("bold"); sh.getRange(2, 1, Math.max(1, sh.getMaxRows() - 1), REC_JCOLS.length).setNumberFormat("@"); }
  return sh;
}
function recJRead_() {
  const sh = recJSheet_(), last = sh.getLastRow(); if (last < 2) return [];
  return sh.getRange(2, 1, last - 1, REC_JCOLS.length).getValues().map(function (r, i) { const o = { _row: i + 2 }; REC_JCOLS.forEach(function (c, j) { o[c] = r[j] instanceof Date ? r[j].toISOString() : String(r[j]); }); return o; }).filter(function (o) { return o.op_id !== ""; });
}
function recJAdd_(entries) {
  if (!entries.length) return; const sh = recJSheet_(), rng = sh.getRange(sh.getLastRow() + 1, 1, entries.length, REC_JCOLS.length);
  rng.setNumberFormat("@"); rng.setValues(entries.map(function (e) { return REC_JCOLS.map(function (c) { return e[c] === undefined ? "" : (typeof e[c] === "object" ? JSON.stringify(e[c]) : String(e[c]).slice(0, 45000)); }); }));
}
function recJStatus_(opIds, status, clearBefore) {         // one read + one write of the journal's status (and, for a purge, "before") columns
  const sh = recJSheet_(), last = sh.getLastRow(); if (last < 2) return; const want = {}; opIds.forEach(function (i) { want[i] = 1; });
  const ids = sh.getRange(2, 1, last - 1, 1).getValues(), cur = sh.getRange(2, 9, last - 1, 3).getValues();      // columns 9..11 = before, after, status
  ids.forEach(function (r, i) { if (want[r[0]]) { cur[i][2] = status; if (clearBefore) cur[i][0] = ""; } });
  sh.getRange(2, 9, last - 1, 3).setValues(cur);
}
function recLastBatch_(j) { for (let i = j.length - 1; i >= 0; i--) if (j[i].status === "applied") return j[i].batch_id; return ""; }
function recBatchId_() { return "b_" + Date.now().toString(36) + Utilities.getUuid().replace(/-/g, "").slice(0, 6).toLowerCase(); }
function recOp_(batch, who, tool, table, key, action, before, after) { return { op_id: "o_" + Utilities.getUuid().replace(/-/g, "").slice(0, 12), batch_id: batch, ts: nowIso(), actor: who, tool: tool, table: table, key: key, action: action, before: before, after: after, status: "applied" }; }

/** Journal entries for the older single-record AI actions (approve / reject / unregister), so they can be undone too. */
function recJournalExisting_(tool, a, before, who) {
  try {
    const batch = recBatchId_();
    if (tool === "violation.approve" || tool === "violation.reject") {
      const now = readAll("Violations").filter(function (r) { return r.violation_id === a.id; })[0]; if (!before || !now) return null;
      const keys = ["review_status", "reviewer", "remarks"], b = {}, n = {}; keys.forEach(function (k) { b[k] = before[k]; n[k] = now[k]; });
      recJAdd_([recOp_(batch, who, tool, "violations", a.id, "update", b, n)]); return batch;
    }
    if (tool === "vehicle.unregister" && before) { recJAdd_([recOp_(batch, who, tool, "vehicles", a.id, "delete", before, "")]); return batch; }
  } catch (e) {}
  return null;
}

/* ---------- writing ---------- */
function recRows_(tab, key, idSet) { return readAll(tab).filter(function (r) { return idSet[String(r[key])]; }); }
function recRemove_(table, idSet) {
  const T = REC[table], cols = SCHEMA[T.tab], sh = sheetFor(T.tab), last = sh.getLastRow(); if (last < 2) return;
  const ids = Object.keys(idSet);
  if (ids.length <= 3) { ids.forEach(function (i) { deleteRow(T.tab, T.key, i); }); return; }
  const ki = cols.indexOf(T.key), vals = sh.getRange(2, 1, last - 1, cols.length).getValues(), kept = vals.filter(function (r) { return !idSet[String(r[ki])]; });
  sh.getRange(2, 1, last - 1, cols.length).clearContent();                           // one rewrite instead of one call per row
  if (kept.length) { const rng = sh.getRange(2, 1, kept.length, cols.length); rng.setNumberFormat("@"); rng.setValues(kept); }
}
function recApply_(table, changes) {                // changes: {id: {field: value}}
  const T = REC[table], ids = Object.keys(changes);
  if (ids.length <= REC_BULK_WRITE) { ids.forEach(function (i) { updateRow(T.tab, T.key, i, changes[i]); }); return; }
  const cols = SCHEMA[T.tab], sh = sheetFor(T.tab), last = sh.getLastRow(), ki = cols.indexOf(T.key), vals = sh.getRange(2, 1, last - 1, cols.length).getValues();
  vals.forEach(function (r) { const c = changes[String(r[ki])]; if (c) Object.keys(c).forEach(function (f) { const ci = cols.indexOf(f); if (ci >= 0) r[ci] = cell(c[f]); }); });
  const rng = sh.getRange(2, 1, vals.length, cols.length); rng.setNumberFormat("@"); rng.setValues(vals);
}
function recAudit_(tool, table, ids, who, batch, extra) {
  appendRow("AuditLog", { timestamp: nowIso(), action: "AI: " + tool, record_id: (ids.slice(0, 3).join(", ") + (ids.length > 3 ? " (+" + (ids.length - 3) + " more)" : "")).slice(0, 120), reviewer: "AI for " + who,
    remarks: (table ? table + ". " : "") + "Batch " + batch + (extra ? ". " + extra : "") + ". Recoverable from the AgentJournal tab." });
}
const recPlural_ = function (n, noun) { return n + " " + noun + (n === 1 ? "" : "s"); };
function recUndoOffer_(batch) { return { batch_id: batch, ticket: agentTicket_("record.undo", { batch_id: batch }, []), label: "Undo" }; }

function recExec_(v, ids, who, said) {
  const a = v.args, tool = v.tool, T = a.table ? REC[a.table] : null;
  if (tool === "record.undo") return recDoUndo_(a.batch_id, who);
  if (tool === "record.purge_trash") return recDoPurge_(a.older_than_days, who);
  if (tool === "record.create") return recDoCreate_(a, who);
  const idSet = {}; ids.forEach(function (i) { idSet[i] = 1; });
  if (!ids.length) return fail(422, "Nothing was selected.");
  if (tool === "record.restore") return recDoRestore_(a.table, ids, who);
  const rows = recRows_(T.tab, T.key, idSet);
  if (!rows.length) return fail(404, "Those records no longer exist. Nothing was changed.");
  const batch = recBatchId_();
  if (tool === "record.delete" || tool === "record.dedupe") {
    recJAdd_(rows.map(function (r) { return recOp_(batch, who, tool, a.table, r[T.key], "delete", r, ""); }));    // the full copy is saved BEFORE anything is removed
    recRemove_(a.table, idSet);
    const left = recRows_(T.tab, T.key, idSet).map(function (r) { return String(r[T.key]); });
    if (left.length) { recJStatus_(recJRead_().filter(function (o) { return o.batch_id === batch && left.indexOf(o.key) >= 0; }).map(function (o) { return o.op_id; }), "failed"); }
    const done = rows.length - left.length; recAudit_(tool, a.table, rows.map(function (r) { return String(r[T.key]); }), who, batch, said);
    return out({ ok: left.length === 0, partial: left.length > 0, agent: { tool: tool, table: a.table, count: done, requested: ids.length, batch_id: batch, ids: rows.map(function (r) { return String(r[T.key]); }).slice(0, 50),
      summary: (tool === "record.dedupe" ? "Removed " : "Deleted ") + recPlural_(done, T.noun) + (tool === "record.dedupe" ? " (duplicates)" : "") + (left.length ? "; " + left.length + " could not be removed" : "") + ".",
      verified: left.length === 0, verification: "Re-read the " + T.tab + " sheet: " + (left.length === 0 ? "none of the " + rows.length + " records is there any more" : left.length + " still present") + "; " + done + " saved in the recovery journal.", undo: done ? recUndoOffer_(batch) : null } });
  }
  // record.update
  const set = Object.assign({}, a.set); if (a.table === "detections" && set.plate_number) { set.plate_status = "confirmed"; set.plate_guess = ""; }
  const changes = {}, ops = []; let same = 0;
  rows.forEach(function (r) { const ch = {}, bf = {}; Object.keys(set).forEach(function (k) { if (String(r[k] === undefined ? "" : r[k]) !== String(set[k])) { ch[k] = set[k]; bf[k] = r[k] === undefined ? "" : r[k]; } });
    if (Object.keys(ch).length) { changes[String(r[T.key])] = ch; ops.push(recOp_(batch, who, tool, a.table, String(r[T.key]), "update", bf, ch)); } else same++; });
  if (!ops.length) return out({ ok: true, agent: { tool: tool, table: a.table, count: 0, requested: ids.length, batch_id: "", summary: "Nothing needed changing: all " + recPlural_(rows.length, T.noun) + " already had those values.", verified: true, verification: "Compared with the current sheet values.", undo: null } });
  recJAdd_(ops); recApply_(a.table, changes);
  const after = recRows_(T.tab, T.key, idSet), bad = [];
  after.forEach(function (r) { const ch = changes[String(r[T.key])]; if (ch) Object.keys(ch).forEach(function (k) { if (String(r[k]) !== String(ch[k])) bad.push(String(r[T.key]) + "." + k); }); });
  if (bad.length) recJStatus_(ops.map(function (o) { return o.op_id; }), "failed");
  recAudit_(tool, a.table, Object.keys(changes), who, batch, Object.keys(a.set).join(", ") + " changed" + (said ? ". " + said : ""));
  return out({ ok: bad.length === 0, partial: bad.length > 0, agent: { tool: tool, table: a.table, count: ops.length, requested: ids.length, batch_id: batch, ids: Object.keys(changes).slice(0, 50),
    summary: "Updated " + recPlural_(ops.length, T.noun) + " (" + Object.keys(a.set).map(function (k) { return k + " → " + (a.set[k] === "" ? "(empty)" : a.set[k]); }).join(", ") + ")" + (same ? "; " + same + " already had those values" : "") + ".",
    verified: bad.length === 0, verification: "Re-read the " + T.tab + " sheet: " + (bad.length === 0 ? "every changed value matches" : bad.length + " value(s) did not match") + "; old values saved in the recovery journal.", undo: ops.length ? recUndoOffer_(batch) : null } });
}

function recDoCreate_(a, who) {
  const batch = recBatchId_(); let res, row;
  try { res = a.table === "violations" ? createViolation(a.fields) : registerVehicle(a.fields); row = JSON.parse(res.getContent()); } catch (e) { return fail(500, "Could not create the record: " + e.message); }
  if (row.error) return fail(row.status || 422, row.error);
  const T = REC[a.table], id = String(row[T.key]);
  recJAdd_([recOp_(batch, who, "record.create", a.table, id, "create", "", row)]);
  const ok = readAll(T.tab).some(function (r) { return String(r[T.key]) === id; });
  recAudit_("record.create", a.table, [id], who, batch, "");
  return out({ ok: ok, agent: { tool: "record.create", table: a.table, count: 1, requested: 1, batch_id: batch, ids: [id], summary: "Created " + T.noun + " " + id + (a.table === "violations" ? " (status Pending, waiting for your review)" : "") + ".",
    verified: ok, verification: "Re-read the " + T.tab + " sheet: " + (ok ? "the new record is there" : "the new record was NOT found"), undo: ok ? recUndoOffer_(batch) : null } });
}

function recDoRestore_(table, ids, who) {
  const T = REC[table], j = recJRead_(), want = {}; ids.forEach(function (i) { want[i] = 1; });
  const hit = j.filter(function (r) { return r.table === table && r.action === "delete" && r.status === "applied" && want[r.key]; }), exist = {}, restored = [], skipped = [], opIds = [];
  readAll(T.tab).forEach(function (r) { exist[String(r[T.key])] = 1; });
  hit.slice().reverse().forEach(function (op) { if (exist[op.key] || restored.indexOf(op.key) >= 0) { skipped.push(op.key); return; } try { appendRow(T.tab, JSON.parse(op.before)); restored.push(op.key); opIds.push(op.op_id); } catch (e) { skipped.push(op.key); } });
  recJStatus_(opIds, "undone");
  const now = {}; readAll(T.tab).forEach(function (r) { now[String(r[T.key])] = 1; }); const ok = restored.every(function (k) { return now[k]; });
  recAudit_("record.restore", table, restored, who, "-", "");
  return out({ ok: ok && restored.length > 0, agent: { tool: "record.restore", table: table, count: restored.length, requested: ids.length, ids: restored.slice(0, 50),
    summary: "Restored " + recPlural_(restored.length, T.noun) + (skipped.length ? "; " + skipped.length + " skipped (already present)" : "") + ".", verified: ok, verification: "Re-read the " + T.tab + " sheet: " + (ok ? "all restored records are back" : "some were not found"), undo: null } });
}

function recDoUndo_(batchId, who) {
  const j = recJRead_(), batch = batchId || recLastBatch_(j); if (!batch) return fail(404, "There is nothing to undo.");
  const ops = j.filter(function (r) { return r.batch_id === batch && r.status === "applied"; }).reverse(); if (!ops.length) return fail(409, "That change was already undone.");
  const done = [], conflicts = [], tables = {};
  ops.forEach(function (op) {
    const T = REC[op.table]; if (!T) { conflicts.push(op.key + " (unknown table)"); return; }
    const cur = readAll(T.tab).filter(function (r) { return String(r[T.key]) === op.key; })[0];
    try {
      if (op.action === "delete") { if (cur) { conflicts.push(op.key + " (a record with this id exists again)"); return; } appendRow(T.tab, JSON.parse(op.before)); }
      else if (op.action === "create") { if (!cur) { conflicts.push(op.key + " (already gone)"); return; } const s = {}; s[op.key] = 1; recRemove_(op.table, s); }
      else if (op.action === "update") {
        if (!cur) { conflicts.push(op.key + " (record no longer exists)"); return; }
        const bf = JSON.parse(op.before), af = JSON.parse(op.after), back = {}; let clash = false;
        Object.keys(af).forEach(function (k) { if (String(cur[k] === undefined ? "" : cur[k]) === String(af[k])) back[k] = bf[k]; else clash = true; });
        if (clash && !Object.keys(back).length) { conflicts.push(op.key + " (changed again since)"); return; } if (clash) conflicts.push(op.key + " (partly changed again since)");
        updateRow(T.tab, T.key, op.key, back);
      }
      done.push(op); tables[op.table] = 1;
    } catch (e) { conflicts.push(op.key + " (" + e.message + ")"); }
  });
  recJStatus_(done.map(function (o) { return o.op_id; }), "undone");
  let ok = true;
  done.forEach(function (op) {                           // read-back check
    const T = REC[op.table], cur = readAll(T.tab).filter(function (r) { return String(r[T.key]) === op.key; })[0];
    if (op.action === "delete" && !cur) ok = false; if (op.action === "create" && cur) ok = false;
    if (op.action === "update" && cur) { const bf = JSON.parse(op.before); Object.keys(bf).forEach(function (k) { if (String(cur[k] === undefined ? "" : cur[k]) !== String(bf[k]) && conflicts.join().indexOf(op.key) < 0) ok = false; }); }
  });
  const what = done.length ? done[0].tool.replace("record.", "").replace("violation.", "").replace("vehicle.", "") : "";
  recAudit_("record.undo", Object.keys(tables).join(","), done.map(function (o) { return o.key; }), who, batch, what + " undone");
  return out({ ok: done.length > 0 && ok, partial: conflicts.length > 0, agent: { tool: "record.undo", count: done.length, requested: ops.length, batch_id: batch, conflicts: conflicts.slice(0, 10),
    summary: done.length ? "Undid the last change (" + recPlural_(done.length, "record") + " reverted: " + done.map(function (o) { return o.action; }).filter(function (v, i, a) { return a.indexOf(v) === i; }).join(", ") + ")" + (conflicts.length ? "; " + conflicts.length + " could not be reverted" : "") + "." : "Nothing could be reverted.",
    verified: ok, verification: "Re-read the affected sheet(s): " + (ok ? "the previous state is back" : "something did not match"), undo: null } });
}

function recDoPurge_(days, who) {
  const j = recJRead_(), cut = days !== undefined ? Date.now() - days * 864e5 : Infinity;
  const hit = j.filter(function (r) { return r.action === "delete" && r.status === "applied" && Date.parse(r.ts) < cut; });
  recJStatus_(hit.map(function (o) { return o.op_id; }), "purged", true);
  const left = recJRead_().filter(function (r) { return r.action === "delete" && r.status === "applied" && Date.parse(r.ts) < cut && r.before !== ""; }).length;
  recAudit_("record.purge_trash", "", hit.map(function (o) { return o.key; }), who, "-", "permanent");
  return out({ ok: left === 0, agent: { tool: "record.purge_trash", count: hit.length, requested: hit.length, summary: "Permanently erased " + recPlural_(hit.length, "recoverable record") + ".", verified: left === 0, verification: "Re-read the journal: " + left + " matching entries still hold data.", undo: null } });
}
