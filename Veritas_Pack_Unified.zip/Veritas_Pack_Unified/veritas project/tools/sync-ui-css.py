"""Re-create portal/assets/css/veritas-ui.css from the <style> block of admin.html (read-only on admin.html).
Run from the website folder:  python3 tools/sync-ui-css.py"""
import re, pathlib
root = pathlib.Path(__file__).resolve().parent.parent
a = (root / "admin.html").read_text(encoding="utf8")
css = re.search(r"<style>\n?(.*?)</style>", a, re.S).group(1).rstrip() + "\n"
hdr = """/* VERITAS UI: the COMPLETE stylesheet of admin.html, copied verbatim by tools/sync-ui-css.py (admin.html is the source of truth). */\n"""
(root / "portal/assets/css/veritas-ui.css").write_text(hdr + css, encoding="utf8")
print("veritas-ui.css rebuilt from admin.html:", len(css), "bytes")
