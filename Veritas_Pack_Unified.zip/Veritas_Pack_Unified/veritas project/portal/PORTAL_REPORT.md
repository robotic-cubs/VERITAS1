# Portal work report (admin.html NOT modified; SHA-256 d7bb7d93…287fc1, identical to the zip you sent)

## Audit findings
1. `admin.html` has no login. It embeds a shared ADMIN_TOKEN and `Code.gs` has `ALLOW_LEGACY_ADMIN_TOKEN = true`, so anyone who can open the file can use the admin API. It cannot be gated without editing it (forbidden). Rotate that token and consider hosting-level protection.
2. `admin.html` has no registration-verification screen. That workflow lives in `portal/portal-admin.html` (routes `admin/vehicles`, `admin/vehicles/decide`), which already worked.
3. `3-register.html` (quick register) posted to the legacy open `vehicles` route, bypassing verification entirely. Now it uses the signed-in `vehicles/add` route, so registrations land in the verification queue.
4. Rejected registrations disappeared from the applicant's list (`rVehicles` filtered on `ended_at`, which rejection sets). Fixed in `Portal.gs`.
5. Logout only cleared sessionStorage; the signed token stayed valid for 8 h. Added server-side single-session revocation.
6. `portal-admin.js` is a stale duplicate of `api.js` (left in place; patched, not merged).

## Changed / new (all under portal/)
New: `assets/css/site.css`, `assets/css/chatbot.css`, `assets/js/site.js`, `assets/img/*.webp`, `admin-login.html`, `track.html`, `privacy.html`, `terms.html`, this report.
Modified: `index.html`, `login.html`, `signup.html`, `forgot.html`, `3-register.html`, `app.html` (logout), `portal-admin.html` (logout, redirect), `assets/js/api.js`, `assets/js/portal-admin.js`, `Portal.gs`, `README.md`.

## Backend change (MANUAL STEP)
Paste the new `portal/Portal.gs` into Apps Script and deploy a NEW version of the web app. Adds route `portal/logout`, revocation check in `authUser`, `SESSION_HOURS` 8 -> 6, rejected claims returned by `vehicles`, `decided_at` in the vehicle view. No sheet/schema changes. Revocation uses CacheService (best effort, up to 6 h); "Sign out of all devices" remains the guaranteed option.

## Limits
- Admin login checks the role on the server (login reply + admin-only route), but `admin.html` itself performs no session check, so opening it directly still works (see finding 1).
- No document upload exists in the system; the site says so. Registration collects OR/CR numbers only.
- Tracking requires login (no public lookup, to avoid exposing owner data).
- Signed-in `app.html` and `portal-admin.html` keep the old dark look; only public pages were redesigned.
- No official contact details exist in the project, so none were invented.
