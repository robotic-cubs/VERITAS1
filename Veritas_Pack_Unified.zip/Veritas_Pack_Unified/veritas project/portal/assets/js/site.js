/* VERITAS public site shell: top bar, navigation, footer, sign-in state and logout. Needs api.js (global V) loaded first.
   SITE.mount({ active: "home" | "register" | "track" | "login" | ... }) */
const SITE = (() => {
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  const LINKS = [
    { k: "home", href: "index.html", label: "Home" },
    { k: "about", href: "index.html#about", label: "About" },
    { k: "services", href: "index.html#services", label: "Services" },
    { k: "register", href: "3-register.html", label: "Vehicle Registration" },
    { k: "track", href: "track.html", label: "Track Registration" },
    { k: "contact", href: "index.html#contact", label: "Contact Us" },
  ];
  function header(active) {
    const signed = !!V.store.get();
    const links = LINKS.map((l) => `<a href="${l.href}"${l.k === active ? ' aria-current="page"' : ""}>${esc(l.label)}</a>`).join("");
    const acct = signed
      ? `<a href="app.html" class="acct">My Account</a><button type="button" class="out" id="site-out">Log out</button>`
      : `<a href="login.html" class="acct"${active === "login" ? ' aria-current="page"' : ""}>Log in</a>`;
    return (
      `<a class="skip" href="#main">Skip to main content</a>` +
      `<div class="util"><div class="wrap"><span>VERITAS Traffic Management Platform</span><span><a href="admin-login.html">Administrator Login</a></span></div></div>` +
      `<header class="hdr"><div class="wrap"><a class="brand" href="index.html"><img src="assets/img/logo-200.webp" width="54" height="40" alt=""><span><b>VERITAS</b><small>Vehicle Registration &amp; Verification</small></span></a>` +
      `<button class="burger" id="site-burger" aria-label="Open menu" aria-expanded="false" aria-controls="site-nav"><svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>` +
      `<nav class="nav" id="site-nav" aria-label="Main navigation">${links}${acct}</nav></div></header>`
    );
  }
  function footer() {
    return (
      `<footer class="ftr"><div class="wrap">` +
      `<div><h3>VERITAS</h3><p>A traffic-management project by Robotic Cubs. Cameras detect vehicles and read plates; staff review and verify.</p></div>` +
      `<div><h3>Quick links</h3><a href="index.html">Home</a><a href="index.html#services">Services</a><a href="3-register.html">Vehicle Registration</a><a href="track.html">Track Registration</a><a href="index.html#faq">FAQ</a></div>` +
      `<div><h3>Accounts</h3><a href="login.html">Log in</a><a href="signup.html">Create an account</a><a href="forgot.html">Forgot password</a><a href="admin-login.html">Administrator Login</a></div>` +
      `<div><h3>Legal</h3><a href="privacy.html">Privacy Policy</a><a href="terms.html">Terms and Conditions</a><a href="index.html#contact">Contact Us</a></div>` +
      `</div><div class="legal"><div class="wrap">&copy; ${new Date().getFullYear()} VERITAS, Robotic Cubs. All rights reserved.</div></div></footer>`
    );
  }
  function confirmOut() {
    const bg = document.createElement("div");
    bg.className = "modal-bg";
    bg.innerHTML = `<div class="modal" role="dialog" aria-modal="true" aria-labelledby="lo-t"><h2 id="lo-t">Log out?</h2><p class="mut">You will be signed out of this device and will need to log in again to see your account.</p><div class="row"><button class="pri" id="lo-y" style="width:auto">Log out</button><button id="lo-n" class="ghost" style="width:auto">Stay signed in</button></div></div>`;
    document.body.appendChild(bg);
    const close = () => bg.remove();
    bg.querySelector("#lo-n").onclick = close;
    bg.addEventListener("click", (e) => e.target === bg && close());
    document.addEventListener("keydown", function k(e) { if (e.key === "Escape") { close(); document.removeEventListener("keydown", k); } });
    const y = bg.querySelector("#lo-y");
    y.onclick = () => { y.disabled = true; y.textContent = "Logging out…"; V.logout(); };
    y.focus();
  }
  function mount(opts) {
    opts = opts || {};
    document.body.insertAdjacentHTML("afterbegin", header(opts.active));
    document.body.insertAdjacentHTML("beforeend", footer());
    const nav = document.getElementById("site-nav"), bur = document.getElementById("site-burger");
    bur.addEventListener("click", () => { const o = nav.classList.toggle("open"); bur.setAttribute("aria-expanded", o); bur.setAttribute("aria-label", o ? "Close menu" : "Open menu"); });
    nav.addEventListener("click", (e) => { if (e.target.closest("a")) nav.classList.remove("open"); });
    const out = document.getElementById("site-out");
    if (out) out.addEventListener("click", confirmOut);
    V.guard();
    // A session whose token the server no longer accepts should not look signed in.
    if (V.store.get()) V.api("me", {}, { noRedirect: true }).catch((e) => { if (e.code === "auth") { V.store.clear(); location.reload(); } });
  }
  /* Small FAQ accordion shared by the home page */
  function accordion(box) {
    box.addEventListener("click", (e) => {
      const q = e.target.closest(".acc-q");
      if (!q) return;
      const open = q.getAttribute("aria-expanded") === "true";
      box.querySelectorAll(".acc-q").forEach((b) => { b.setAttribute("aria-expanded", "false"); b.nextElementSibling.classList.remove("open"); });
      if (!open) { q.setAttribute("aria-expanded", "true"); q.nextElementSibling.classList.add("open"); }
    });
  }
  const fmt = (t) => esc(t).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/\n/g, "<br>");
  return { mount, accordion, fmt, esc };
})();
