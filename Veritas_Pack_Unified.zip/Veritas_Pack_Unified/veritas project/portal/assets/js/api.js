/* VERITAS portal: shared client code (API calls, session, small helpers). Loaded after ../assets/js/veritas-config.js (project-level assets folder). */
const PORTAL_API = window.VERITAS_API_URL || ""; // set in ../assets/js/veritas-config.js
const LOGIN_URL =
  document.currentScript && document.currentScript.src
    ? new URL("../../login.html", document.currentScript.src).href
    : "login.html"; // correct from portal/ and from the site root
const INDEX_URL = LOGIN_URL.replace("login.html", "index.html");
const V = (() => {
  const KEY = "veritas.portal.token";
  const store = {
    get: () => {
      try {
        return sessionStorage.getItem(KEY) || "";
      } catch (e) {
        return "";
      }
    },
    set: (t) => {
      try {
        sessionStorage.setItem(KEY, t);
      } catch (e) {}
    },
    clear: () => {
      try {
        Object.keys(sessionStorage).filter((k) => k.indexOf("veritas.memo.") === 0).forEach((k) => sessionStorage.removeItem(k));
        sessionStorage.removeItem(KEY);
      } catch (e) {}
    },
  };
  const esc = (s) =>
    String(s ?? "").replace(
      /[&<>"']/g,
      (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
    );
  const money = (n, cur) =>
    n == null
      ? "Pending assessment"
      : new Intl.NumberFormat("en-PH", { style: "currency", currency: cur || "PHP" }).format(n);
  const dt = (iso, o) => {
    const d = new Date(iso);
    return isNaN(d) ? "-" : d.toLocaleString("en-PH", o || { dateStyle: "medium", timeStyle: "short" });
  };
  const date = (iso) => dt(iso, { dateStyle: "medium" }),
    time = (iso) => dt(iso, { timeStyle: "short" });
  const plate = (p, big) => `<span class="plate${big ? " lg" : ""}">${esc(p || "UNREAD")}</span>`;
  const BADGE = {
    Unpaid: "bad",
    "Pending Payment": "warn",
    Paid: "ok",
    Disputed: "info",
    Waived: "mute",
    Verified: "ok",
    Pending: "warn",
    Rejected: "bad",
    "Under Review": "warn",
    Failed: "bad",
    Cancelled: "mute",
    Expired: "mute",
    Open: "info",
    Upheld: "bad",
    Active: "ok",
    "Pending Verification": "warn",
  };
  const CLS = { ok: "g", warn: "o", bad: "r", mute: "n", info: "g" }; // admin.html badge colours: b-g green, b-o amber, b-r red, b-n neutral
  const badge = (s) => `<span class="b b-${CLS[BADGE[s] || "mute"]}">${esc(s)}</span>`;
  const METHOD = { gcash: "GCash", maya: "Maya", online_banking: "Online banking" };

    /* Speed: identical read-only calls made by several scripts on one page are sent once, and the answers that change rarely are
     remembered for a short time (sessionStorage, cleared on sign-out): "me" 30 s, "config" 5 min, "faq" 10 min. Any account change
     (login, profile, password, logout...) forgets them at once, so nothing the person just changed ever looks stale. */
  const TTL = { me: 30000, config: 300000, faq: 600000 };
  const WRITES = /^(login|signup|verify|resend|forgot|reset|profile|contact|password|logout|account|admin\/claim)/;
  const inflight = {};
  const mkey = (p) => "veritas.memo." + p;
  function forget() {
    Object.keys(inflight).forEach((k) => delete inflight[k]);
    Object.keys(TTL).forEach((p) => {
      try {
        sessionStorage.removeItem(mkey(p));
      } catch (e) {}
    });
  }
  function api(path, body, opts) {
    if (WRITES.test(path)) {
      const r = apiNet(path, body, opts);
      const done = () => forget();
      r.then(done, done);
      forget();
      return r;
    }
    if (!TTL[path] || (opts && opts.fresh)) return apiNet(path, body, opts);
    const tok = store.get();
    try {
      const c = JSON.parse(sessionStorage.getItem(mkey(path)) || "null");
      if (c && c.tok === tok && Date.now() - c.t < TTL[path]) return Promise.resolve(JSON.parse(c.j));
    } catch (e) {}
    const k = path + "|" + tok;
    if (inflight[k]) return inflight[k].then((j) => JSON.parse(j));
    const p = apiNet(path, body, opts).then((j) => {
      const s = JSON.stringify(j);
      try {
        sessionStorage.setItem(mkey(path), JSON.stringify({ tok, t: Date.now(), j: s }));
      } catch (e) {}
      return s;
    });
    inflight[k] = p;
    const clear = () => delete inflight[k];
    p.then(clear, clear);
    return p.then((s) => JSON.parse(s));
  }
  async function apiNet(path, body, opts) {
    const c = new AbortController(),
      to = setTimeout(() => c.abort(), 45000);
    try {
      const r = await fetch(PORTAL_API, {
        method: "POST",
        signal: c.signal,
        headers: { "Content-Type": "text/plain;charset=utf-8" },
        body: JSON.stringify({ ...(body || {}), path: "portal/" + path, token: store.get() }),
      });
      const j = await r.json();
      if (j && j.error) {
        const e = new Error(j.error);
        e.status = j.status;
        e.code = j.code;
        e.field = j.field;
        if (j.code === "auth" && !(opts && opts.noRedirect)) {
          store.clear();
          location.href =
            LOGIN_URL +
            "?expired=1&next=" +
            encodeURIComponent(location.pathname.split("/").pop() + location.hash);
        }
        throw e;
      }
      return j;
    } catch (e) {
      if (e.name === "AbortError") throw new Error("The system took too long to answer. Please try again.");
      if (e instanceof TypeError)
        throw new Error("Cannot reach the system. Check your connection and try again.");
      throw e;
    } finally {
      clearTimeout(to);
    }
  }
  /* Sign out for real: the server revokes THIS token first (route "logout"), then every trace of the session in the browser is removed.
     If the network is down the browser is still cleared, and the token expires on its own after the session length. */
  async function logout(dest) {
    if (store.get()) {
      try {
        await Promise.race([api("logout", {}, { noRedirect: true }), new Promise((r) => setTimeout(r, 6000))]);
      } catch (e) {}
    }
    store.clear();
    try {
      ["veritas.chat.sid", "veritas.chat.log"].forEach((k) => sessionStorage.removeItem(k));
    } catch (e) {}
    location.replace(dest || INDEX_URL + "?out=1");
  }
  /* Back/forward cache can show an authenticated page after logout. When a page is restored from it, re-check for a session. */
  function guard() {
    addEventListener("pageshow", (e) => {
      if (e.persisted && !store.get()) location.replace(LOGIN_URL);
    });
  }
  function toast(t, bad) {
    let e = document.getElementById("toast");
    if (!e) {
      e = document.createElement("div");
      e.id = "toast";
      e.className = "toast";
      e.setAttribute("role", "status");
      document.body.appendChild(e);
    }
    e.textContent = t;
    e.className = "toast show" + (bad ? " bad" : "");
    clearTimeout(e._t);
    e._t = setTimeout(() => e.classList.remove("show"), 3200);
  }
  function say(el, text, ok) {
    el.textContent = text || "";
    el.className = "msg" + (text ? " show" : "") + (ok ? " ok" : "");
  }
  async function busy(btn, label, fn) {
    const old = btn.textContent;
    btn.disabled = true;
    btn.textContent = label;
    try {
      return await fn();
    } finally {
      btn.disabled = false;
      btn.textContent = old;
    }
  }
  const qs = (k) => new URLSearchParams(location.search).get(k);
  const safeNext = (n) => (/^[a-z0-9\-]+\.html(#[\w\/\-]*)?$/i.test(n || "") ? n : "app.html");
  // Where a signed-in person belongs. The role comes from the server (login / me), never from anything the browser stored.
  const home = (u) => (u && u.role === "admin" ? "../admin.html" : "app.html");
  return {
    api,
    logout,
    guard,
    store,
    esc,
    money,
    dt,
    date,
    time,
    plate,
    badge,
    toast,
    say,
    busy,
    qs,
    safeNext,
    home,
    METHOD,
  };
})();
