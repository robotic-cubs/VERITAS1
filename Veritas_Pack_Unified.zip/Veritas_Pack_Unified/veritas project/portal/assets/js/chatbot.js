/* VERITAS Help Assistant: the PUBLIC chatbot. Same look as the assistant in admin.html (it reuses its CSS classes),
   but it only ever calls the public route "portal/chat". It never sends a login token, and the server decides what it may say. */
(function () {
  const API = window.VERITAS_API_URL || "";
  const CHIPS = [
    "How do I create an account?",
    "How do I register a vehicle?",
    "How do I pay a penalty?",
    "Why is my vehicle pending?",
    "I forgot my password",
    "How do I dispute a violation?",
  ];
  const WELCOME =
    "Hi! I'm the VERITAS Help Assistant. I can explain how to create an account, register vehicles, view and pay violations, dispute them, and reset your password.";
  const $ = (s, r) => (r || document).querySelector(s);
  const esc = (s) =>
    String(s ?? "").replace(
      /[&<>"']/g,
      (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
    );
  const fmt = (t) =>
    esc(t)
      .replace(/\*\*(.+?)\*\*/g, "<b>$1</b>")
      .replace(/`([^`\n]+)`/g, "<code>$1</code>")
      .replace(/\n/g, "<br>");
  const ss = {
    get: (k) => {
      try {
        return sessionStorage.getItem(k) || "";
      } catch (e) {
        return "";
      }
    },
    set: (k, v) => {
      try {
        sessionStorage.setItem(k, v);
      } catch (e) {}
    },
  };
  const reduce = matchMedia("(prefers-reduced-motion:reduce)").matches;
  const bot = (r, c) =>
    `<svg width="${r}" height="${r}" viewBox="0 0 24 24" fill="none" stroke="#4cc38a" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="8" width="14" height="11" rx="3"/><path d="M12 8V5M10 4h4M3 13v2M21 13v2"/><circle class="eye" cx="9.5" cy="13" r="${c}" fill="#4cc38a"/><circle class="eye" cx="14.5" cy="13" r="${c}" fill="#4cc38a"/><path d="M10 16.2h4"/></svg>`;

  let sid = ss.get("veritas.chat.sid");
  if (!sid) {
    const a = new Uint8Array(18);
    (crypto || window.msCrypto).getRandomValues(a);
    sid =
      "w" +
      [...a]
        .map((b) => b.toString(36).padStart(2, "0"))
        .join("")
        .slice(0, 28);
    ss.set("veritas.chat.sid", sid);
  }
  let log = [];
  try {
    log = JSON.parse(ss.get("veritas.chat.log") || "[]");
  } catch (e) {
    log = [];
  }
  let busy = false,
    typing = null;

  document.body.insertAdjacentHTML(
    "beforeend",
    `<button id="nbbtn" aria-label="Open VERITAS Help Assistant" title="VERITAS Help Assistant">${bot(22, ".6")}<i class="ndot" id="ndot"></i></button>` +
      `<div id="nb" role="dialog" aria-label="VERITAS Help Assistant"><div class="nh"><div class="bot">${bot(22, ".7")}</div><div style="flex:1;min-width:0"><b>VERITAS HELP ASSISTANT</b><small id="nbs">Answers about this website</small></div>` +
      `<button id="ncl" title="Clear chat" aria-label="Clear chat"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/></svg></button>` +
      `<button id="nmin" title="Minimize" aria-label="Minimize">&#8211;</button><button id="nx" title="Close" aria-label="Close">&#10005;</button></div>` +
      `<div id="msgs" aria-live="polite"></div><button type="button" id="chtg" aria-expanded="true"></button><div id="chips"></div>` +
      `<form id="cf"><input type="text" id="ci" placeholder="Ask about this website…" autocomplete="off" maxlength="600" aria-label="Message"><button class="pri" id="csend">Send</button></form></div>`,
  );
  const nb = $("#nb"),
    msgs = $("#msgs"),
    ci = $("#ci"),
    send = $("#csend");

  function save() {
    ss.set("veritas.chat.log", JSON.stringify(log.slice(-24)));
  }
  function msg(html, cls) {
    const d = document.createElement("div");
    d.className = "m " + cls;
    d.innerHTML = html;
    msgs.appendChild(d);
    msgs.scrollTop = msgs.scrollHeight;
    return d;
  }
  function open(v) {
    nb.classList.toggle("open", v);
    if (v) {
      nb.classList.remove("min");
      setTimeout(() => ci.focus(), 260);
    }
    $("#nbbtn").setAttribute("aria-expanded", String(v));
  }
  function chipsToggle(hide, saveIt) {
    nb.classList.toggle("nochips", hide);
    const t = $("#chtg");
    t.textContent = (hide ? "\u25B4 " : "\u25BE ") + (hide ? "Show suggestions" : "Hide suggestions");
    t.setAttribute("aria-expanded", String(!hide));
    if (saveIt) {
      try {
        localStorage.setItem("veritas_nochips", hide ? "1" : "0");
      } catch (e) {}
    }
  }
  function renderChips() {
    $("#chips").innerHTML = CHIPS.map(
      (c) => `<button type="button" data-q="${esc(c)}">${esc(c)}</button>`,
    ).join("");
  }
  function welcome() {
    msgs.innerHTML = "";
    msg(esc(WELCOME), "a");
  }
  function restore() {
    welcome();
    log.forEach((x) => msg(x.r === "u" ? esc(x.t) : fmt(x.t), x.r === "u" ? "u" : "a"));
  }

  /* while typing, hide a half-written **bold** or `code` marker so the visitor never sees stray symbols */
  function partial(t) {
    [
      ["**", 2],
      ["`", 1],
    ].forEach(([m, n]) => {
      const c = t.split(m).length - 1;
      if (c % 2) {
        const i = t.lastIndexOf(m);
        t = t.slice(0, i) + t.slice(i + n);
      }
    });
    return t;
  }
  /* typing effect: reveals the answer a few characters at a time with the same blinking cursor as admin.html; any new action skips it */
  function typeInto(el, text, done) {
    if (reduce || text.length < 2) {
      el.innerHTML = fmt(text);
      return done();
    }
    let i = 0;
    const step = Math.max(2, Math.ceil(text.length / 160));
    let stop = false;
    const tick = () => {
      if (stop) return;
      i = Math.min(text.length, i + step);
      el.innerHTML =
        fmt(i < text.length ? partial(text.slice(0, i)) : text) +
        (i < text.length ? '<span class="cur"></span>' : "");
      msgs.scrollTop = msgs.scrollHeight;
      if (i < text.length) setTimeout(tick, 16);
      else done();
    };
    typing = {
      skip() {
        stop = true;
        el.innerHTML = fmt(text);
        typing = null;
        done();
      },
    };
    tick();
  }

  async function ask(text) {
    text = String(text || "").trim();
    if (!text || busy) return;
    if (typing) typing.skip();
    if (text.length > 600) {
      msg("Please keep your question under 600 characters.", "a");
      return;
    }
    busy = true;
    send.disabled = true;
    msg(esc(text), "u");
    log.push({ r: "u", t: text });
    save();
    const wait = msg(
      '<span class="think"><i></i><i></i><i></i><span class="tl">Thinking…</span></span>',
      "a t",
    );
    const slow = setTimeout(() => {
      const l = wait.querySelector(".tl");
      if (l) l.textContent = "Still working on it…";
    }, 8000);
    const ctl = new AbortController(),
      to = setTimeout(() => ctl.abort(), 45000);
    let reply = "",
      ok = true;
    try {
      const r = await fetch(API, {
        method: "POST",
        signal: ctl.signal,
        headers: { "Content-Type": "text/plain;charset=utf-8" },
        body: JSON.stringify({ path: "portal/chat", sid, message: text }),
      });
      const j = await r.json();
      if (j.error) {
        ok = false;
        reply =
          j.status === 429
            ? j.error
            : j.status === 422
              ? j.error
              : "Sorry, I could not answer that right now. Please try again in a moment.";
      } else reply = String(j.reply || "");
    } catch (e) {
      ok = false;
      reply =
        e.name === "AbortError"
          ? "That took too long. Please try again."
          : "I can't reach the system right now. Please check your connection and try again.";
    }
    clearTimeout(slow);
    clearTimeout(to);
    wait.className = "m a";
    wait.innerHTML = "";
    typeInto(wait, reply, () => {
      busy = false;
      send.disabled = false;
      if (ok) {
        log.push({ r: "a", t: reply });
        save();
      }
      ci.focus();
    });
  }

  $("#nbbtn").onclick = () => open(!nb.classList.contains("open"));
  $("#nx").onclick = () => open(false);
  $("#nmin").onclick = () => nb.classList.toggle("min");
  $("#ncl").onclick = () => {
    if (typing) typing.skip();
    log = [];
    save();
    welcome();
    busy = false;
    send.disabled = false;
    fetch(API, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify({ path: "portal/chat/reset", sid }),
    }).catch(() => {});
  };
  $("#cf").addEventListener("submit", (e) => {
    e.preventDefault();
    const v = ci.value;
    ci.value = "";
    ask(v);
  });
  $("#chips").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-q]");
    if (b) ask(b.dataset.q);
  });
  $("#chtg").onclick = () => chipsToggle(!nb.classList.contains("nochips"), true);
  addEventListener("keydown", (e) => {
    if (e.key === "Escape" && nb.classList.contains("open")) open(false);
  });
  document.addEventListener("click", (e) => {
    if (e.target.closest('[data-k="help"]')) {
      e.preventDefault();
      open(true);
    }
  });

  renderChips();
  let hide = false;
  try {
    hide = localStorage.getItem("veritas_nochips") === "1";
  } catch (e) {}
  chipsToggle(hide, false);
  restore();
  window.VeritasChat = {
    open: () => open(true),
    ask: (t) => {
      open(true);
      ask(t);
    },
  };
})();
