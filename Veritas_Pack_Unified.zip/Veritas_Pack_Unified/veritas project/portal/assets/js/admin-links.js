/* Administrator navigation entries. app.html loads this file ONLY after the server has confirmed the signed-in user is an administrator,
   so a driver's page never contains these destinations. (The links are not secrets; access is enforced by the server.) */
window.ADMIN_LINKS = [
  { h: "ADMINISTRATION" },
  { k: "admindash", href: "../admin.html", label: "Admin dashboard", icon: "dash" },
  { k: "padmin", href: "portal-admin.html", label: "Portal administration", icon: "check" },
];
