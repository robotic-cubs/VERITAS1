/* VERITAS shared settings. Change the Apps Script web-app URL HERE ONLY.
   It must end in /exec. After you redeploy the Apps Script as a new deployment, paste the new URL below.
   Loaded by admin.html, 3-REGISTER.html and every page in portal/. */
window.VERITAS_API_URL = "https://script.google.com/macros/s/AKfycbzbr05pOPVRG36n5lCZ0BdMJFsy7NdHGvP04FY0MCkIvLT8-grnL4lCKuU4AjNRuJDI/exec";

/* AI service (FastAPI, veritas-backend). Live engine health and AI events on the admin pages come from here.
   Same PC: leave as is. If the backend runs on another machine, put that address here. */
window.VERITAS_AI_URL = "http://127.0.0.1:8000";
/* Set to true only if you turned on PROTECT_AI_READS in veritas-backend/.env. */
window.VERITAS_AI_PROTECTED = false;
