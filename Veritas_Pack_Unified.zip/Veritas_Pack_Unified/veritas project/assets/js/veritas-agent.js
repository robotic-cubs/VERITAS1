/* VERITAS AI action controller (browser side). Load AFTER the main script in admin.html:  <script src="assets/js/veritas-agent.js"></script>
   It only calls functions that already exist in admin.html (render, load, call, ask, toast ...) and the 3 server paths in Agent.gs.
   The AI never runs code: it returns tool names; this file runs ONLY the executors listed in EXEC below. */
(function () {
  "use strict";
  const MON = { active: false, paused: false, timer: 0 };
  const LASTL = { table: "", ids: [] };                       // the last list of records shown, so "delete these" knows what "these" is
  window.AGSEL = window.AGSEL || { det: "" };                 // the detection row you clicked, so "delete this" knows what "this" is
  let AH = [];                                   // command conversation memory (last 8 turns) so "it" / "the other camera" resolve
  const PAGE_NAME = { overview: "Dashboard Overview", map: "Traffic Map", live: "Live AI Monitoring", vmon: "Vehicle Monitoring", vehicles: "Vehicle Database", violations: "Violation Management", peds: "Pedestrian Safety", opt: "Traffic Optimization", signals: "Smart Traffic Signals", calendar: "Calendar", reports: "Reports & Analytics", health: "System Health", settings: "Settings" };
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const camName = s => (CAMERAS.find(c => String(c.slot) === String(s)) || {}).name || "Camera " + s;
  const backendOk = () => MODE === "live";

  async function go(page) {
    if (location.hash === "#" + page) render(); else { location.hash = "#" + page; await wait(80); }
    if (location.hash !== "#" + page) throw new Error("The page did not open.");
  }
  const localDay = ms => { const d = new Date(ms); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); };
  const vioMs = v => Date.parse(v.date + "T" + v.time + "Z");
  const inPeriod = (ms, p) => isFinite(ms) && (p === "all" || (p === "today" ? localDay(ms) === localDay(Date.now()) : ms >= Date.now() - 7 * 864e5));
  async function fresh() { if (!READY) throw new Error("No backend URL is set."); await load(); if (MODE !== "live") throw new Error("The Google Sheet is unreachable right now" + (ERR ? " (" + ERR + ")" : "") + ", so I can't read real data."); }
  const camStatus = c => { const hb = DB.cameras.find(x => x.camera_id === c.id); return hb ? hb.status + " (last heartbeat " + when(hb.last_seen) + ")" : "never connected"; };
  const audit = (action, detail) => call("agent/audit", { action: action, detail: detail, reviewer: ADMIN }).catch(() => {});

  /* ---------- risk-aware progress lines: shown BEFORE each step runs ---------- */
  const PROGRESS = {
    "nav.open": a => "Right away. Opening " + (PAGE_NAME[a.page] || a.page) + "…", "cam.select": a => "Right away. Switching to " + (a.camera === "both" ? "both cameras" : camName(a.camera)) + "…",
    "filter.violations": a => "Understood. Filtering violations: " + a.status + "…", "filter.detections": a => "Understood. Filtering detected vehicles: " + a.registration + "…",
    "search.vehicles": a => "Understood. Searching vehicles for “" + a.query + "”…", "search.violations": a => "Understood. Searching violations for “" + a.query + "”…",
    "violation.open": a => "Right away. Opening violation " + a.id + "…", "data.camera_status": () => "Certainly. Checking camera status…", "data.system_status": () => "Certainly. Checking the current system status…",
    "data.summary": () => "Understood. Retrieving the records from the Google Sheet…", "data.latest": a => "Understood. Retrieving the latest " + a.what + "…",
    "report.generate": () => "Understood. Generating your traffic report from saved records…", "monitoring.start": () => "Right away. Starting live monitoring…", "monitoring.stop": () => "Right away. Stopping live monitoring…",
    "feed.clear": () => "Understood. Clearing the Latest detections feed…", "violation.approve": a => "Understood. Confirming violation " + a.id + "…", "violation.reject": a => "Understood. Rejecting violation " + a.id + "…", "vehicle.unregister": a => "Understood. Unregistering vehicle " + a.id + "…"
  };

  Object.assign(PROGRESS, {
    "record.find": a => "Understood. Searching the " + a.table + " records…", "record.delete": a => "Understood. Preparing to delete from " + a.table + "…",
    "record.update": a => "Understood. Preparing to change " + a.table + "…", "record.create": a => "Understood. Creating the " + (a.table === "vehicles" ? "vehicle" : "violation") + " record…",
    "record.dedupe": a => "Certainly. Looking for duplicate " + a.table + "…", "record.restore": () => "Understood. Restoring from the recovery journal…",
    "record.undo": () => "Understood. Undoing the last change…", "record.purge_trash": () => "Understood. Preparing to erase the recovery journal…", "data.attention": () => "Certainly. Checking what needs attention…"
  });

  /* ---------- executors. Each returns {ok, text}. text is built from what actually happened. ---------- */
  const EXEC = {
    async "nav.open"(a) { await go(a.page); return { ok: true, text: "Opened **" + PAGE_NAME[a.page] + "**." }; },

    async "cam.select"(a) {
      await go("live"); camSel = a.camera === "both" ? "" : a.camera; render();
      const shown = document.querySelectorAll('[id^="cs"]').length;
      if (!shown) return { ok: false, text: "The Live AI Monitoring page opened but no camera panels appeared." };
      const cams = a.camera === "both" ? CAMERAS : CAMERAS.filter(c => String(c.slot) === a.camera);
      return { ok: true, text: "Showing **" + (a.camera === "both" ? "both cameras" : camName(a.camera)) + "**.\n" + cams.map(c => "• " + c.name + " (" + c.hw + "): " + camStatus(c)).join("\n") };
    },

    async "filter.violations"(a) {
      vF = a.status; selV = null; await go("violations"); render();
      const n = DB.violations.filter(v => a.status === "all" || st(v.review_status) === a.status).length;
      return { ok: true, text: "Showing **" + a.status + "** violations: " + n + " record" + (n === 1 ? "" : "s") + "." };
    },
    async "filter.detections"(a) {
      dF = a.registration; await go("vmon"); render();
      return { ok: true, text: "Vehicle Monitoring is now filtered to **" + a.registration + "** detections." };
    },
    async "search.vehicles"(a) {
      q = a.query; await go("vehicles"); render();
      const k = norm(a.query), n = DB.vehicles.filter(v => norm(v.plate_number).includes(k) || st(v.robot_name).includes(st(a.query)) || st(v.leanbot_id).includes(st(a.query))).length;
      return { ok: true, text: "Searched the Vehicle Database for **" + a.query + "**: " + n + " match" + (n === 1 ? "" : "es") + "." };
    },
    async "search.violations"(a) {
      vq = a.query; vF = "all"; selV = null; await go("violations"); render();
      const k = norm(a.query), n = DB.violations.filter(v => norm(v.plate_number).includes(k) || st(v.violation_type).includes(st(a.query))).length;
      return { ok: true, text: "Searched violations for **" + a.query + "**: " + n + " match" + (n === 1 ? "" : "es") + "." };
    },
    async "violation.open"(a) {
      await fresh(); const v = DB.violations.find(x => x.violation_id === a.id);
      if (!v) return { ok: false, text: "I couldn't find violation **" + a.id + "** in the records." };
      selV = v.violation_id; vF = "all"; vq = ""; await go("violations"); render();
      return { ok: true, text: "Opened **" + v.violation_id + "**: " + (v.violation_type || "violation") + ", plate " + (v.plate_number || "unread") + ", status " + v.review_status + "." };
    },

    async "data.camera_status"() {
      await fresh();
      return { ok: true, text: "**Camera status** (from the backend heartbeat):\n" + CAMERAS.map(c => "• " + c.name + " (" + c.hw + "): " + camStatus(c)).join("\n") };
    },
    async "data.system_status"() {
      await fresh(); let sync = ""; try { if (typeof SYNC !== "undefined" && SYNC) sync = ", last synced " + ago(SYNC); } catch (e) {}
      const pend = DB.violations.filter(x => st(x.review_status) === "pending").length;
      const ai = AIOK === true ? "online (" + ((AIST && AIST.model) || "language model") + ")" : "unavailable" + (AIWHY ? ": " + AIWHY : "");
      return { ok: true, text: "**System status**\n• Google Sheet: connected" + sync + "\n• AI service: " + ai + "\n" + CAMERAS.map(c => "• " + c.name + ": " + camStatus(c)).join("\n") +
        "\n• Records: " + DB.detections.length + " detections loaded, " + DB.violations.length + " violations (" + pend + " pending review)\n• Live monitoring (this dashboard): " + (MON.active ? "on" : "off") +
        "\n• Pedestrian, signal and traffic-optimization modules: not integrated yet" };
    },
    async "data.attention"() {
      await fresh();
      const reg = new Set(DB.vehicles.map(v => norm(v.plate_number))), open = d => !d.status || d.status === "open";
      const pend = DB.violations.filter(v => st(v.review_status) === "pending"), det = DB.detections.filter(open);
      const unreg = det.filter(d => norm(d.plate_number) && !reg.has(norm(d.plate_number))), unread = det.filter(d => !norm(d.plate_number));
      const off = CAMERAS.filter(c => { const hb = DB.cameras.find(x => x.camera_id === c.id); return !hb || hb.status !== "Connected"; });
      const L = [], s_ = n => n === 1 ? "" : "s";
      if (pend.length) L.push("• **" + pend.length + " violation" + s_(pend.length) + " waiting for your review** (" + pend.slice(0, 3).map(v => v.violation_id).join(", ") + (pend.length > 3 ? ", …" : "") + ")");
      if (unreg.length) L.push("• **" + unreg.length + " open detection" + s_(unreg.length) + " with an unregistered plate**");
      if (unread.length) L.push("• " + unread.length + " open detection" + s_(unread.length) + " with an unread plate");
      if (off.length) L.push("• " + off.map(c => c.name).join(" and ") + (off.length > 1 ? " are" : " is") + " not connected");
      return { ok: true, text: L.length ? "**Needs attention**\n" + L.join("\n") + "\nTell me what to do with any of these, for example “show unresolved detections” or “remove duplicates”." : "Nothing needs attention right now: no pending violations, no open detections, and every camera is connected." };
    },
    async "data.summary"(a) {
      await fresh(); const P = a.scope === "today" ? "today" : "all";
      const d = DB.detections.filter(x => inPeriod(Date.parse(x.timestamp), P)), v = DB.violations.filter(x => inPeriod(vioMs(x), P));
      const s = k => v.filter(x => st(x.review_status) === k).length;
      return { ok: true, text: "**" + (P === "today" ? "Today" : "All saved records") + "**: " + d.length + " detection" + (d.length === 1 ? "" : "s") + " (latest 500 loaded), " + v.length + " violation" + (v.length === 1 ? "" : "s") + " — pending " + s("pending") + ", confirmed " + s("confirmed") + ", rejected " + s("rejected") + "." };
    },
    async "data.latest"(a) {
      await fresh(); const n = a.count || 5;
      if (a.what === "detections") {
        const cid = a.camera === "any" ? "" : (CAMERAS.find(c => String(c.slot) === a.camera) || {}).id;
        const l = DB.detections.filter(d => !cid || d.camera_id === cid).slice(0, n);
        return { ok: true, text: l.length ? "**Latest detections:**\n" + l.map(d => "• " + when(d.timestamp) + " · " + d.camera_id + " · plate " + (d.plate_number || "unread") + " · confidence " + pct(d.leanbot_confidence)).join("\n") : "No detections are saved yet." };
      }
      const l = DB.violations.slice(0, n);
      return { ok: true, text: l.length ? "**Latest violations:**\n" + l.map(v => "• " + v.violation_id + " · " + (v.violation_type || "–") + " · " + (v.plate_number || "unread") + " · " + v.review_status).join("\n") : "No violations are recorded yet." };
    },

    async "report.generate"(a) {
      await fresh(); const P = a.period;
      const d = DB.detections.filter(x => inPeriod(Date.parse(x.timestamp), P)), v = DB.violations.filter(x => inPeriod(vioMs(x), P));
      const csv = r => r.map(c => '"' + String(c == null ? "" : c).replace(/"/g, '""') + '"').join(",");
      const rows = [["VERITAS traffic report", P, new Date().toISOString()], [], ["VIOLATIONS"], ["violation_id", "plate", "type", "date", "time(UTC)", "location", "camera", "status", "reviewer", "remarks"]]
        .concat(v.map(x => [x.violation_id, x.plate_number, x.violation_type, x.date, x.time, x.location, x.camera_id, x.review_status, x.reviewer, x.remarks]))
        .concat([[], ["DETECTIONS"], ["detection_id", "time", "camera", "plate", "vehicle_conf", "plate_conf"]])
        .concat(d.map(x => [x.detection_id, x.timestamp, x.camera_id, x.plate_number, x.leanbot_confidence, x.plate_confidence]));
      const url = URL.createObjectURL(new Blob([rows.map(csv).join("\n")], { type: "text/csv" })), l = document.createElement("a");
      l.href = url; l.download = "veritas-report-" + P + "-" + localDay(Date.now()) + ".csv"; document.body.appendChild(l); l.click(); l.remove(); setTimeout(() => URL.revokeObjectURL(url), 4000);
      audit("report.generate", P);
      return { ok: true, text: "Report downloaded (**" + l.download + "**): " + v.length + " violation(s) and " + d.length + " detection(s) from the Google Sheet." };
    },

    async "monitoring.start"() {
      MON.paused = false; MON.active = true; await go("live"); render(); await load().catch(() => {});
      clearInterval(MON.timer); MON.timer = setInterval(() => { if (MON.active && location.hash === "#live" && !document.hidden && !$("#dlg").open) load(); }, 4000);
      const want = CAMERAS.filter(c => (camSel || "both") === "both" || String(c.slot) === camSel);
      for (let i = 0; i < 8 && want.some(c => camInfo(c).stream && !streamOK[c.slot]); i++) await wait(500);
      audit("monitoring.start", "live");
      return { ok: true, text: "Live monitoring is **on** (refreshing every 4 s).\n" + want.map(c => { const hasUrl = !!camInfo(c).stream; return "• " + c.name + ": " + (!hasUrl ? "no video address configured yet" : streamOK[c.slot] ? "video receiving" : "no video yet") + "; backend says " + camStatus(c); }).join("\n") };
    },
    async "monitoring.stop"() {
      if (!MON.active && !MON.paused) return { ok: true, text: "Live monitoring was already off." };
      MON.active = false; MON.paused = true; clearInterval(MON.timer); MON.timer = 0;
      Object.keys(streamEls).forEach(k => { try { streamEls[k].removeAttribute("src"); } catch (e) {} delete streamEls[k]; });
      if (location.hash === "#live") render();
      audit("monitoring.stop", "live");
      return { ok: true, text: "Live monitoring is **off** in this dashboard: video disconnected, auto-refresh stopped. The camera program itself keeps running and saving detections." };
    }
  };
  const _mount = window.mountStreams;                      // while paused, don't re-attach the video
  window.mountStreams = function () {
    if (!MON.paused) return _mount.apply(this, arguments);
    CAMERAS.forEach(c => { const b = $("#cs" + c.slot); if (b) b.innerHTML = '<div class="mut" style="padding:24px;text-align:center">Monitoring is off. Say “start live monitoring” to reconnect.</div>'; });
  };

  /* ---------- server-side (confirmed) actions ---------- */
  const NOUN = { detections: "detection", violations: "violation", vehicles: "vehicle" };
  const sampleList = items => items && items.length ? '<ul style="margin:8px 0 0 18px;padding:0">' + items.map(x => "<li>" + esc(x) + "</li>").join("") + "</ul>" : "";
  const reload = async () => { for (let i = 0; i < 12 && typeof loading !== "undefined" && loading; i++) await wait(200); await load().catch(() => {}); };   // a poll in flight would make load() return early
  function recordDisplay(item) {                          // read-only answers, and "nothing matched"
    const a = item.args, p = item.preview || {}, t = a.table;
    if (item.tool === "record.find") {
      LASTL.table = t; LASTL.ids = (item.ids || []).slice(0, 200);
      if (!item.count) return { ok: true, text: "No " + t + " match that." };
      const shown = (p.sample || []).length;
      return { ok: true, text: "**" + item.count + " matching " + NOUN[t] + (item.count === 1 ? "" : "s") + "**" + (item.count > shown ? " (newest " + shown + " shown)" : "") + "\n" + (p.sample || []).map(x => "• " + x).join("\n") + "\nTell me what to do with " + (item.count === 1 ? "it" : "them") + ", for example “delete these” or “mark these as resolved”." };
    }
    if (item.tool === "record.dedupe") return { ok: true, text: "No duplicates found. " + (item.rule || "") };
    return { ok: true, text: "No " + t + " matched, so nothing was changed." + (p.missing && p.missing.length ? " Not found: " + p.missing.slice(0, 5).join(", ") + "." : "") };
  }
  function agentResult(res) {
    const g = res && res.agent; if (!g) return { ok: true, text: "Done." };
    let t = (g.verified ? "" : "⚠ ") + "**" + g.summary + "**" + (g.verification ? "\n" + (g.verified ? "✓ " : "✗ ") + g.verification : "");
    if (g.conflicts && g.conflicts.length) t += "\nCould not revert: " + g.conflicts.join("; ") + ".";
    if (g.undo) t += "\nSay “undo” or press Undo to reverse it.";
    return { ok: res.ok !== false || !!res.partial, text: t, undo: g.undo || null };
  }
  async function recordAction(item, said) {
    if (!backendOk()) return { ok: false, text: "The Google Sheet is unreachable, so nothing was changed." };
    let conf = { reviewer: ADMIN, remarks: "" };
    if (item.confirm && item.confirm.need) {              // only large, official or permanent changes stop to ask
      conf = await ask({ title: item.confirm.title, body: esc(item.confirm.body) + sampleList(item.preview && item.preview.sample) + ((item.count || 0) > ((item.preview && item.preview.sample || []).length) ? '<div class="mut" style="margin-top:6px">…and ' + (item.count - item.preview.sample.length) + " more.</div>" : ""), ok: item.confirm.ok, cls: item.confirm.cls || "pri" });
      if (!conf) return { ok: false, cancelled: true, text: "Cancelled. Nothing was changed." };
      ADMIN = conf.reviewer || ADMIN;
    }
    let res;
    try { res = await call("agent/exec", { tool: item.tool, args: item.args, ids: item.ids || [], ticket: item.ticket, confirmed: true, reviewer: conf.reviewer || ADMIN, remarks: conf.remarks, said: said }, 90000); }
    catch (e) { await reload(); return { ok: false, text: "The server refused it: " + e.message }; }
    await reload(); LASTL.ids = []; if (window.AGSEL.det && !DB.detections.some(d => d.detection_id === window.AGSEL.det)) window.AGSEL.det = "";
    return agentResult(res);
  }
  async function undoNow(u) {                              // the Undo button: same server path, same checks
    try { const res = await call("agent/exec", { tool: "record.undo", args: { batch_id: u.batch_id }, ids: [], ticket: u.ticket, confirmed: true, reviewer: ADMIN, said: "Undo button" }, 90000); await reload(); return agentResult(res); }
    catch (e) { return { ok: false, text: "I'm unable to undo that: " + e.message }; }
  }

  async function serverAction(item, said) {
    if (item.tool.indexOf("record.") === 0) return recordAction(item, said);
    if (!backendOk()) return { ok: false, text: "The Google Sheet is unreachable, so nothing was changed." };
    const a = item.args; let conf;
    if (item.tool === "feed.clear") {
      const cid = a.camera === "all" ? "" : (CAMERAS.find(c => String(c.slot) === a.camera) || {}).id, n = DB.detections.filter(d => !cid || d.camera_id === cid).length;
      conf = await ask({ title: "Clear Latest detections" + (cid ? " (" + camName(a.camera) + ")" : " (all cameras)") + "?", body: "This hides " + n + " saved detection row" + (n === 1 ? "" : "s") + " from the Latest detections list. <b>Nothing is deleted</b>: detections, violations, vehicles and camera logs stay in the sheet. It is recorded in the audit log.", ok: "Clear feed", cls: "pri" });
    } else if (item.tool === "vehicle.unregister") {
      const v = DB.vehicles.find(x => x.leanbot_id === a.id);
      if (!v) return { ok: false, text: "I couldn't find vehicle **" + a.id + "** in the registry." };
      conf = await ask({ title: "Unregister " + esc(v.plate_number) + "?", body: "Removes " + esc(v.plate_number) + " (" + esc(v.robot_name || v.leanbot_id) + ") from the registry. Past detections and violations stay on record.", ok: "Unregister", cls: "dng" });
    } else {
      const v = DB.violations.find(x => x.violation_id === a.id), ap = item.tool === "violation.approve";
      if (!v) return { ok: false, text: "I couldn't find violation **" + a.id + "** in the records." };
      if (v.review_status !== "Pending") return { ok: false, text: "**" + v.violation_id + "** is already " + v.review_status + ". Reviewed records can't be reviewed again." };
      conf = await ask({ title: (ap ? "Confirm" : "Reject") + " violation " + esc(v.violation_id) + "?", body: (ap ? "This records " + esc(v.violation_type) + " for " + esc(v.plate_number || "an unread plate") + " as officially confirmed." : "This dismisses the AI's detection. A remark explaining why is required."), ok: ap ? "Confirm violation" : "Reject violation", cls: ap ? "dng" : "pri", need: !ap });
    }
    if (!conf) return { ok: false, cancelled: true, text: "Cancelled. Nothing was changed." };
    ADMIN = conf.reviewer || ADMIN;
    let res;
    try {
      res = await call("agent/exec", { tool: item.tool, args: a, ticket: item.ticket, confirmed: true, reviewer: conf.reviewer, remarks: conf.remarks, said: said });
    } catch (e) { await reload(); return { ok: false, text: e.status === 409 ? "Someone already handled this: " + e.message : "The server refused it: " + e.message }; }
    await reload();
    const base = ({ "feed.clear": "Latest detections cleared. Records were kept.", "vehicle.unregister": "Vehicle **" + a.id + "** unregistered.", "violation.approve": "Violation **" + a.id + "** confirmed.", "violation.reject": "Violation **" + a.id + "** rejected." })[item.tool];
    const g = res && res.agent;
    if (g) return { ok: true, text: base + "\n" + (g.verified ? "✓ " : "✗ ") + g.verification + " Logged in the audit trail." + (g.undo ? "\nSay “undo” or press Undo to reverse it." : ""), undo: g.undo || null };
    return { ok: true, text: base + " Logged in the audit trail." };
  }

  const NAVT = ["nav.open", "cam.select", "filter.violations", "filter.detections", "search.vehicles", "search.violations", "violation.open", "monitoring.start"];
  async function runCall(item, said, cid, gen) {
    const w = sys(PROGRESS[item.tool] ? PROGRESS[item.tool](item.args) : item.tool);
    let r;
    try {
      if (item.tool.indexOf("record.") === 0 && !item.server) r = recordDisplay(item);
      else if (item.server) r = await serverAction(item, said);
      else if (item.risk === "moderate") {
        const c = await ask({ title: item.tool === "monitoring.start" ? "Start live monitoring?" : "Stop live monitoring?", body: item.tool === "monitoring.start" ? "Opens Live AI Monitoring, connects the camera video and refreshes every 4 seconds." : "Disconnects the camera video and stops auto-refresh in this dashboard. The camera program keeps running and saving detections.", ok: item.tool === "monitoring.start" ? "Start" : "Stop", cls: "pri" });
        r = c ? await EXEC[item.tool](item.args) : { ok: false, cancelled: true, text: "Cancelled. Nothing was changed." };
      } else r = await EXEC[item.tool](item.args);
    } catch (e) { r = { ok: false, text: "The system returned an error: " + (e && e.message || e) }; }
    const shown = r.ok || r.cancelled ? r.text : "I'm unable to complete that operation. " + r.text;
    w.remove();
    if (gen === CGEN) {                                    // still the same conversation on screen
      const b = msg(shown, "a");
      if (r.undo) {                                       // reversible: offer the one-click undo right where the result is shown
        const x = document.createElement("div"), bt = document.createElement("button"); bt.type = "button"; bt.className = "cbtn"; bt.textContent = "↶ Undo";
        bt.onclick = async () => { bt.disabled = true; bt.textContent = "Undoing…"; const u = await undoNow(r.undo); bt.remove(); const t = u.ok ? u.text : "I'm unable to complete that operation. " + u.text; if (gen === CGEN) msg(t, "a"); if (window.CS) CS.assistant(t, cid, "cmd"); };
        x.appendChild(bt); b.appendChild(x);
      }
      if (r.ok && NAVT.indexOf(item.tool) >= 0 && window.CS && CS.isXL()) {   // the page changed behind the large chat: offer a way to see it
        const x = document.createElement("div"), bt = document.createElement("button"); bt.type = "button"; bt.className = "cbtn"; bt.textContent = "Minimize to see the page";
        bt.onclick = () => CS.setMode("small"); x.appendChild(bt); b.appendChild(x);
      }
    }
    if (window.CS) CS.assistant(shown, cid, "cmd");
    return r;
  }

  /* ---------- entry: same path for typed and spoken text ---------- */
  const CMD = /^\s*(please\s+|can you\s+|could you\s+)?(veritas[ ,:!]*)?(open|show|go|take me|navigate|switch|change|select|run|start|stop|pause|resume|clear|generate|create|make|download|export|find|search|filter|check|confirm|approve|reject|unregister|remove|delete|view|display|list|bring|only|turn|connect|disconnect|refresh|reload|pull up|give me|mark|start it|stop it|undo|restore|dismiss|edit|rename|update|correct|erase|purge|organi[sz]e|empty|resolve|set|add|register|flag|put back)\b/i;
  const wantsAgent = t => CMD.test(t) || (t.length <= 70 && !/\?/.test(t) && !/^\s*(what|why|how|who|when|where|which|is|are|do|does|did|can|could|would|explain|tell|thanks|thank|hi|hello)\b/i.test(t)) || /[^\x00-\x7F]/.test(t) || (typeof LANG !== "undefined" && LANG !== "auto" && LANG !== "en");

  async function route(text, fallback) {
    if (!wantsAgent(text) || !READY) return fallback(text);
    if (!document.querySelector("#nb") ) return fallback(text);
    const gen = CGEN; let cid = null;
    const um = msg(text, "u"), tb = msg('<span class="think"><i></i><i></i><i></i><span class="tl">Understanding your command…</span></span>', "a t");
    let plan;
    try {
      plan = await call("agent", { messages: AH.concat([{ role: "user", content: text }]), lang: LANG, tzOffsetMin: new Date().getTimezoneOffset(),
        state: { page: curPage, camera: camSel || "both", vfilter: vF, monitoring: MON.active, selected: selV || "",
          selDet: (window.AGSEL && DB.detections.some(d => d.detection_id === window.AGSEL.det)) ? window.AGSEL.det : "", last_list: LASTL.ids.length ? { table: LASTL.table, ids: LASTL.ids } : null } }, 60000);
    } catch (e) {
      tb.remove(); const why = typeof whyAi === "function" ? whyAi(e) : (e && e.message || "the command service did not answer.");
      if (e && (e.status === 401 || e.status === 403)) { AIOK = false; AIWHY = why; if (typeof aiLabel === "function") aiLabel(); }
      if (CMD.test(text)) { const t = "I'm unable to complete that operation. Nothing was executed: " + why; if (window.CS) { cid = CS.user(text, "cmd"); CS.assistant(t, cid, "cmd"); } if (gen === CGEN) msg(t, "a"); return; }   // a clear command must not silently turn into a chat answer
      um.remove(); return fallback(text);
    }
    tb.remove();
    if (plan.intent !== "command") { um.remove(); return fallback(text); }          // a question: the existing assistant answers it
    if (window.CS) cid = CS.user(text, "cmd");
    AH.push({ role: "user", content: text });
    if (!plan.calls || !plan.calls.length) { const s = plan.say || "I can't do that from here."; if (gen === CGEN) msg(s, "a"); if (window.CS) CS.assistant(s, cid, "cmd"); AH.push({ role: "assistant", content: s }); AH = AH.slice(-8); return; }
    if (plan.notes && plan.notes.length) { const nt = plan.notes.join(" "); if (gen === CGEN) msg(nt, "a"); if (window.CS) CS.assistant(nt, cid, "cmd"); }
    const done = [];
    for (const item of plan.calls) {
      const r = await runCall(item, text, cid, gen); done.push((r.ok ? "Done: " : "Failed: ") + item.tool + " " + JSON.stringify(item.args));
      if (!r.ok) break;                                                                // stop the chain at the first failure
    }
    const summary = done.join("; "); AH.push({ role: "assistant", content: summary }); AH = AH.slice(-8);
    try { HIST.push({ role: "user", content: text }, { role: "assistant", content: summary }); HIST = HIST.slice(-10); } catch (e) {}
  }

  /* ---------- voice: push-to-talk. The transcript goes through the SAME form submit, so the same routing, permissions and confirmations apply.
     A spoken command can never confirm anything: confirmation dialogs need a click. ---------- */
  function initVoice() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition, form = $("#cf");
    if (!SR || !form || $("#mic")) return;
    const b = document.createElement("button"); b.type = "button"; b.id = "mic"; b.title = "Speak a command (say “VERITAS, …”)"; b.setAttribute("aria-label", "Voice command"); b.textContent = "🎤";
    form.insertBefore(b, form.querySelector("button")); let rec = null;
    const LM = { en: "en-US", fil: "fil-PH", vi: "vi-VN", es: "es-ES", fr: "fr-FR", de: "de-DE", ja: "ja-JP", ko: "ko-KR", zh: "zh-CN", pt: "pt-PT", ar: "ar-SA" };
    b.onclick = () => {
      if (rec) { rec.stop(); return; }
      rec = new SR(); rec.lang = LM[LANG] || navigator.language || "en-US"; rec.interimResults = false; rec.maxAlternatives = 1;
      b.classList.add("on"); b.textContent = "⏺";
      rec.onresult = e => { let t = (e.results[0] && e.results[0][0] && e.results[0][0].transcript || "").trim().replace(/^(hey\s+)?veritas[\s,.:!]*/i, ""); if (!t) return; $("#ci").value = t; form.requestSubmit ? form.requestSubmit() : form.dispatchEvent(new Event("submit", { cancelable: true })); };
      rec.onerror = e => { toast(e.error === "not-allowed" ? "Microphone permission was denied." : "Voice input failed: " + e.error); };
      rec.onend = () => { rec = null; b.classList.remove("on"); b.textContent = "🎤"; };
      try { rec.start(); } catch (e) { rec = null; }
    };
  }
  initVoice();
  /* Take over the chat form's submit (capture phase, so admin.html needs no edit besides loading this file).
     Anything that is not a command goes straight to the original chatAsk, exactly as before. */
  document.addEventListener("submit", function (e) {
    if (!e.target || e.target.id !== "cf") return;
    const inp = $("#ci"), v = inp && inp.value.trim(); if (!v) return;
    e.preventDefault(); e.stopImmediatePropagation(); inp.value = "";
    route(v, chatAsk);
  }, true);
  const selCss = document.createElement("style");
  selCss.textContent = 'tr[data-det]{cursor:pointer}tr[data-det]:hover{background:#ffffff08}tr[data-det].sel{background:#4cc38a1c;box-shadow:inset 3px 0 0 #4cc38a}';
  document.head.appendChild(selCss);
  document.addEventListener("click", function (e) {
    const tr = e.target.closest && e.target.closest("tr[data-det]"); if (!tr || e.target.closest("a,button,input,select,textarea")) return;
    const id = tr.dataset.det, on = window.AGSEL.det !== id; window.AGSEL.det = on ? id : "";
    document.querySelectorAll("tr[data-det].sel").forEach(r => r.classList.remove("sel"));
    document.querySelectorAll('tr[data-det="' + CSS.escape(id) + '"]').forEach(r => { if (on) r.classList.add("sel"); });
    if (on && typeof toast === "function") toast("Selected " + id + ". Tell VERITAS what to do with it.");
  });
  window.VeritasAgent = { reset: function () { AH = []; }, setHistory: function (a) { AH = (a || []).map(function (m) { return { role: m.role, content: String(m.content).slice(0, 1500) }; }).slice(-8); }, route: route, state: MON, tools: EXEC };
})();
