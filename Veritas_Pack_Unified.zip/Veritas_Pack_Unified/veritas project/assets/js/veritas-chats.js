/* VERITAS AI: expandable chat + saved conversations. Load AFTER veritas-agent.js in admin.html.
   There is ONE chat window (#nb). "Expand" only adds the class .xl to that same element, so the small and the large view
   are literally the same conversation: nothing is copied, nothing resets. Messages are saved in the Google Sheet through
   Chats.gs (ids made here, so retries never duplicate). */
(function () {
  "use strict";
  const nb = document.getElementById("nb");
  if (!nb || typeof call !== "function") return;
  const LS = { get: k => { try { return localStorage.getItem(k); } catch (e) { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} }, del: k => { try { localStorage.removeItem(k); } catch (e) {} } };
  const rnd = n => Math.random().toString(36).slice(2, 2 + n).padEnd(n, "0");
  const newChatId = () => "c_" + Date.now().toString(36) + rnd(6), newMsgId = () => "m_" + Date.now().toString(36) + "_" + rnd(8);
  const title_ = t => { t = String(t || "").replace(/```[\s\S]*?```/g, " ").replace(/[*_`#>]/g, "").replace(/\s+/g, " ").trim(); return !t ? "New chat" : (t.length > 48 ? t.slice(0, 47) + "\u2026" : t); };   // same rule as Chats.gs
  const whyShort = e => (e && e.status === 401) ? "the admin token does not match Apps Script" : (e && e.status === 404) ? "the backend has no chat history yet (add Chats.gs and redeploy)" : (e && e.message) || "the backend could not be reached";

  const S = { id: LS.get("veritas_chat_id") || null, msgs: [], list: [], q: "", err: "", xl: false };
  try { S.list = JSON.parse(LS.get("veritas_chat_list") || "[]"); } catch (e) { S.list = []; }

  /* ---------------- save queue: survives refresh, retries until the server accepts ---------------- */
  let queue = []; try { queue = JSON.parse(LS.get("veritas_chat_q") || "[]"); } catch (e) { queue = []; }
  const saveQ = () => LS.set("veritas_chat_q", JSON.stringify(queue.slice(-200)));
  let flushing = null;
  function flush() {
    if (flushing) return flushing;
    flushing = (async () => {
      while (queue.length) {
        const op = queue[0];
        try { const r = await call(op.path, Object.assign({ owner: typeof ADMIN === "string" ? ADMIN : "" }, op.body), 30000); queue.shift(); saveQ(); if (r && r.title) setTitle(op.body.chat_id, r.title); }
        catch (e) { if (e && e.status && e.status >= 400 && e.status < 500 && ![401, 403, 404, 408, 429].includes(e.status)) { queue.shift(); saveQ(); continue; } break; }   // bad data: drop it. Network/auth trouble: keep and retry
      }
    })().finally(() => { flushing = null; });
    return flushing;
  }
  const enqueue = (path, body) => { queue.push({ path, body }); saveQ(); flush(); };
  setInterval(() => { if (queue.length) flush(); }, 8000); window.addEventListener("online", flush);

  /* ---------------- conversation state ---------------- */
  function setTitle(id, t) { const c = S.list.find(x => x.chat_id === id); if (c && c.title !== t) { c.title = t; renderList(); } }
  function ensure() {
    if (S.id) return;
    S.id = newChatId(); LS.set("veritas_chat_id", S.id);
    S.list.unshift({ chat_id: S.id, title: "New chat", updated_at: new Date().toISOString(), msg_count: 0 }); renderList();
  }
  function record(role, text, cid, kind) {
    const m = { id: newMsgId(), role: role, kind: kind || "chat", content: String(text == null ? "" : text).slice(0, 20000), ts: new Date().toISOString() };
    if (!m.content.trim() || !cid) return;
    if (cid === S.id) S.msgs.push(m);
    const c = S.list.find(x => x.chat_id === cid);
    if (c) { c.updated_at = m.ts; c.msg_count = (c.msg_count || 0) + 1; if (role === "user" && (!c.title || c.title === "New chat")) c.title = title_(m.content); S.list.sort((a, b) => String(b.updated_at).localeCompare(String(a.updated_at))); renderList(); }
    enqueue("chats/append", { chat_id: cid, messages: [m] });
  }
  const CS = {
    user(text, kind) { ensure(); record("user", text, S.id, kind); return S.id; },
    assistant(text, cid, kind) { record("assistant", text, cid || S.id, kind); },
    isXL: () => S.xl, flush: flush, state: S,
    async newChat() {
      CGEN++; if (TYPING) TYPING.skip(); HIST = []; if (window.VeritasAgent && VeritasAgent.reset) VeritasAgent.reset();
      S.id = null; S.msgs = []; LS.del("veritas_chat_id"); $("#msgs").innerHTML = ""; start(); chipsCmd(); renderList(); $("#ci").focus();
    },
    async restore() {                     // first open after a refresh: continue the last conversation
      if (!S.id) return false;
      try { const r = await call("chats/get", { chat_id: S.id }, 20000); if (!r.messages || !r.messages.length) { S.id = null; return false; } S.msgs = r.messages; started = true; draw(S.msgs); chipsCtx(); refreshList(); return true; }
      catch (e) { S.id = null; return false; }
    },
    setMode: m => setMode(m)
  };
  window.CS = CS;

  function draw(arr) {
    if (TYPING) TYPING.skip(); const box = $("#msgs"); box.innerHTML = "";
    if (!arr.length) start();
    else arr.forEach(m => { if (m.role === "user") msg(m.content, "u"); else { const b = msg("", "a"); b.innerHTML = fmt(esc(m.content)); b.dataset.raw = m.content; addTr(b); } });
    HIST = arr.slice(-10).map(m => ({ role: m.role, content: m.content }));
    if (window.VeritasAgent && VeritasAgent.setHistory) VeritasAgent.setHistory(HIST.slice(-8));
    box.scrollTop = box.scrollHeight;
  }
  async function open(id) {
    if (id === S.id && S.msgs.length) { if (innerWidth < 760) nb.classList.remove("sbo"); return; }
    CGEN++;                                                  // an answer still on its way belongs to the chat it was asked in
    box_loading(true);
    try { await Promise.race([flush(), new Promise(r => setTimeout(r, 4000))]); const r = await call("chats/get", { chat_id: id }, 20000);
      S.id = id; LS.set("veritas_chat_id", id); S.msgs = r.messages || []; draw(S.msgs); chipsCtx(); markActive(); nb.classList.remove("sbo"); $("#ci").focus();
    } catch (e) { toast("Couldn't open that conversation: " + whyShort(e)); }
    box_loading(false);
  }
  const box_loading = on => { $("#msgs").style.opacity = on ? ".45" : ""; };

  /* ---------------- expand / restore ---------------- */
  const IC_EXP = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4h6v6M10 20H4v-6M20 4l-7 7M4 20l7-7"/></svg>';
  const IC_RES = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 14l-6 6M4 15v5h5M14 10l6-6M15 4h5v5"/></svg>';
  function setMode(m) {
    const xl = m === "xl"; S.xl = xl;
    if (xl) { nb.classList.add("open"); nb.classList.remove("min"); }
    nb.classList.toggle("xl", xl); if (!xl) nb.classList.remove("sbo");
    const b = $("#nxl"); b.innerHTML = xl ? IC_RES : IC_EXP; b.title = xl ? "Back to small chat" : "Expand to full screen"; b.setAttribute("aria-label", b.title);
    nb.setAttribute("aria-label", xl ? "VERITAS AI Workspace" : "VERITAS AI Assistant");
    if (xl) refreshList();
    setTimeout(() => { const m_ = $("#msgs"); m_.scrollTop = m_.scrollHeight; }, 340);
  }

  /* ---------------- markup: expand button, mobile menu button, sidebar ---------------- */
  const hd = nb.querySelector(".nh"), ncl = $("#ncl");
  const xb = document.createElement("button"); xb.id = "nxl"; xb.type = "button"; xb.innerHTML = IC_EXP; xb.title = "Expand to full screen"; xb.setAttribute("aria-label", xb.title); hd.insertBefore(xb, ncl);
  const sbb = document.createElement("button"); sbb.id = "nsb"; sbb.type = "button"; sbb.title = "Conversations"; sbb.setAttribute("aria-label", "Show conversations"); sbb.textContent = "☰"; hd.insertBefore(sbb, hd.firstChild);
  const side = document.createElement("aside"); side.id = "hsb"; side.setAttribute("aria-label", "Saved conversations");
  side.innerHTML = '<div class="csh"><button type="button" id="hsnew"><span>＋</span> New chat</button></div><div class="csq"><input type="search" id="hsq" placeholder="Search conversations…" aria-label="Search conversations" autocomplete="off"></div><div id="hsl" role="list"></div><div class="csf">Saved in your Google Sheet</div>';
  nb.appendChild(side);

  const css = document.createElement("style"); css.textContent = `
#nb{transition:transform .28s ease,opacity .2s,height .32s ease,width .32s ease,right .32s ease,bottom .32s ease,border-radius .32s ease}
#nb #hsb,#nb #nsb{display:none}
#nb.xl{right:12px;bottom:12px;width:calc(100% - 24px);height:calc(100% - 24px);border-radius:16px;z-index:40}
#nb.xl #hsb{display:flex}
#hsb{position:absolute;left:0;top:0;bottom:0;width:280px;flex-direction:column;background:#10161a;border-right:1px solid var(--line);z-index:2}
.csh{padding:12px 12px 6px}#hsnew{width:100%;display:flex;align-items:center;gap:8px;justify-content:flex-start;padding:9px 12px;border-radius:10px;border:1px solid #4cc38a55;background:#4cc38a14;color:var(--ink);font-size:13.5px}#hsnew:hover{background:#4cc38a26}
.csq{padding:6px 12px 8px}#hsq{width:100%;box-sizing:border-box;padding:8px 10px;border-radius:9px;border:1px solid var(--line);background:var(--bg);color:var(--ink);font-size:13px}
#hsl{flex:1;overflow-y:auto;padding:0 8px 8px}.csg{font-size:10.5px;letter-spacing:.09em;color:var(--mut);text-transform:uppercase;padding:12px 8px 4px}
.csi{position:relative;display:flex;align-items:center;border-radius:9px;margin:1px 0}.csi:hover{background:#ffffff0a}.csi.on{background:#4cc38a1c}
.cst{flex:1;min-width:0;text-align:left;border:0;background:none;color:var(--ink);padding:8px 10px;font-size:13px;cursor:pointer;display:block}.cst b{display:block;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.cst small{display:block;color:var(--mut);font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:1px}
.csa{display:none;gap:2px;padding-right:6px}.csi:hover .csa,.csi.on .csa,.csi:focus-within .csa{display:flex}.csa button{border:0;background:none;color:var(--mut);padding:3px 5px;border-radius:6px;font-size:13px;cursor:pointer}.csa button:hover{color:var(--ink);background:#ffffff14}
.csi input.csr{flex:1;margin:4px 6px;padding:5px 8px;border-radius:7px;border:1px solid #4cc38a88;background:var(--bg);color:var(--ink);font-size:13px;min-width:0}
.csc{flex:1;padding:8px 10px;font-size:12.5px;color:var(--ink);display:flex;gap:6px;align-items:center;flex-wrap:wrap}.csc button{border:1px solid var(--line);background:none;color:var(--ink);padding:3px 9px;border-radius:7px;font-size:12px;cursor:pointer}.csc .dng{border-color:var(--r);color:var(--r)}
.cse{color:var(--mut);font-size:12.5px;padding:14px 10px;line-height:1.5}.cse button{border:1px solid var(--line);background:none;color:var(--ink);border-radius:7px;padding:3px 9px;margin-top:6px;cursor:pointer}
.csf{padding:8px 14px;border-top:1px solid var(--line);font-size:11px;color:var(--mut)}
#nb.xl .nh,#nb.xl #msgs,#nb.xl #chtg,#nb.xl #chips,#nb.xl #cf{margin-left:280px}
#nb.xl #msgs{padding:22px max(20px,calc((100% - 860px)/2))}
#nb.xl #chips,#nb.xl #cf{padding-left:max(20px,calc((100% - 860px)/2));padding-right:max(20px,calc((100% - 860px)/2))}
#nb.xl #cf{padding-top:10px;padding-bottom:14px}#nb.xl #ci{padding:12px 14px;font-size:14.5px}
#nb.xl .m{max-width:min(780px,100%);font-size:14.5px;line-height:1.6}#nb.xl .m.hello{max-width:min(780px,100%)}
#nb.xl .m pre{position:relative;background:#0a0e10;border:1px solid var(--line);border-radius:10px;padding:12px 14px;overflow-x:auto;font-size:13px;line-height:1.5;margin:8px 0}
#nb.xl .m pre code{background:none;padding:0;white-space:pre}
.cpb{position:absolute;top:6px;right:6px;border:1px solid var(--line);background:#161c1f;color:var(--mut);border-radius:6px;font-size:11px;padding:2px 8px;cursor:pointer}.cpb:hover{color:var(--ink)}
.m pre{position:relative}
.m .cbtn{display:inline-block;margin-top:8px;border:1px solid #4cc38a55;background:#4cc38a12;color:#cfe9dd;border-radius:99px;padding:3px 11px;font-size:12px;cursor:pointer}
@media (max-width:760px){
 #nb.xl{right:0;bottom:0;width:100%;height:100%;border-radius:0}
 #nb.xl .nh,#nb.xl #msgs,#nb.xl #chtg,#nb.xl #chips,#nb.xl #cf{margin-left:0}
 #nb.xl #nsb{display:inline-block}
 #nb.xl #hsb{transform:translateX(-104%);transition:transform .25s ease;width:min(300px,86%);box-shadow:8px 0 30px #0009;z-index:5}
 #nb.xl.sbo #hsb{transform:none}
}
@media (prefers-reduced-motion:reduce){#nb{transition:none}}`;
  document.head.appendChild(css);

  /* ---------------- sidebar list ---------------- */
  const grp = iso => { const d = new Date(iso), n = new Date(), day = x => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime(), diff = Math.round((day(n) - day(d)) / 864e5);
    return isNaN(d) ? "Older" : diff <= 0 ? "Today" : diff === 1 ? "Yesterday" : diff < 8 ? "Previous 7 days" : "Older"; };
  const rel = iso => { const d = new Date(iso); return isNaN(d) ? "" : d.toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }); };
  function renderList() {
    const box = $("#hsl"); if (!box) return; let h = "";
    if (S.err) h += `<div class="cse">Couldn't load saved conversations: ${esc(S.err)}<br><button type="button" id="hsretry">Retry</button></div>`;
    if (!S.list.length && !S.err) h += `<div class="cse">${S.q ? "No conversations match “" + esc(S.q) + "”." : "No saved conversations yet. Start chatting and they will appear here."}</div>`;
    let last = ""; S.list.forEach(c => {
      const g = S.q ? "Results" : grp(c.updated_at); if (g !== last) { h += `<div class="csg">${g}</div>`; last = g; }
      h += `<div class="csi${c.chat_id === S.id ? " on" : ""}" role="listitem" data-id="${esc(c.chat_id)}"><button type="button" class="cst" title="${esc(c.title)}"><b>${esc(c.title)}</b><small>${c.snippet ? esc(c.snippet) : esc(rel(c.updated_at))}</small></button><span class="csa"><button type="button" class="rn" title="Rename" aria-label="Rename conversation">✎</button><button type="button" class="dl" title="Delete" aria-label="Delete conversation">🗑</button></span></div>`;
    });
    box.innerHTML = h; if (!S.q) LS.set("veritas_chat_list", JSON.stringify(S.list.slice(0, 60)));
  }
  const markActive = () => document.querySelectorAll("#hsl .csi").forEach(e => e.classList.toggle("on", e.dataset.id === S.id));
  let listSeq = 0;
  async function refreshList() {
    const q = S.q, seq = ++listSeq;
    try { const r = await call("chats/list", { q: q }, 20000); if (seq !== listSeq) return;
      S.err = ""; S.list = r.chats || [];
      if (!q && S.id && S.msgs.length && !S.list.some(c => c.chat_id === S.id)) S.list.unshift({ chat_id: S.id, title: title_((S.msgs.find(m => m.role === "user") || {}).content), updated_at: new Date().toISOString(), msg_count: S.msgs.length });   // saved but not on the server yet
    } catch (e) { if (seq !== listSeq) return; S.err = whyShort(e); }
    renderList();
  }
  let qt = 0; $("#hsq").addEventListener("input", e => { S.q = e.target.value.trim(); clearTimeout(qt); qt = setTimeout(refreshList, 250); });
  $("#hsnew").onclick = () => { CS.newChat(); nb.classList.remove("sbo"); };

  $("#hsl").addEventListener("click", e => {
    if (e.target.id === "hsretry") return refreshList();
    const it = e.target.closest(".csi"); if (!it) return; const id = it.dataset.id, c = S.list.find(x => x.chat_id === id);
    if (e.target.closest(".rn")) return renameUI(it, c);
    if (e.target.closest(".dl")) return deleteUI(it, c);
    if (e.target.closest(".cst")) open(id);
    if (e.target.closest(".cbtn")) return;
  });
  function renameUI(it, c) {
    const t = it.querySelector(".cst"), a = it.querySelector(".csa"), inp = document.createElement("input"); inp.className = "csr"; inp.value = c.title; inp.maxLength = 80; inp.setAttribute("aria-label", "Conversation name");
    it.replaceChild(inp, t); a.style.display = "none"; inp.focus(); inp.select(); let done = false;
    const finish = async save => { if (done) return; done = true; const v = inp.value.replace(/\s+/g, " ").trim();
      if (save && v && v !== c.title) { const old = c.title; c.title = v; renderList(); try { await flush(); await call("chats/rename", { chat_id: c.chat_id, title: v }, 20000); } catch (e) { c.title = old; renderList(); toast("Couldn't rename: " + whyShort(e)); } } else renderList(); };
    inp.addEventListener("keydown", e => { if (e.key === "Enter") finish(true); else if (e.key === "Escape") { e.stopPropagation(); finish(false); } });
    inp.addEventListener("blur", () => finish(true));
  }
  function deleteUI(it, c) {
    it.innerHTML = `<div class="csc"><span>Delete this conversation?</span><button type="button" class="dng" id="hsdy">Delete</button><button type="button" id="hsdn">Cancel</button></div>`;
    it.querySelector("#hsdn").onclick = renderList;
    it.querySelector("#hsdy").onclick = async () => {
      try { await flush(); await call("chats/delete", { chat_id: c.chat_id }, 30000); } catch (e) { if (!(e && e.status === 404)) { toast("Couldn't delete: " + whyShort(e)); return renderList(); } }
      S.list = S.list.filter(x => x.chat_id !== c.chat_id); queue = queue.filter(o => !(o.body && o.body.chat_id === c.chat_id)); saveQ();
      if (c.chat_id === S.id) CS.newChat(); else renderList();
    };
  }

  /* ---------------- wiring ---------------- */
  xb.onclick = () => setMode(S.xl ? "small" : "xl");
  sbb.onclick = () => nb.classList.toggle("sbo");
  document.addEventListener("click", e => {                            // in the large view "–" means "back to the small chat"
    if (S.xl && e.target.closest("#nbm")) { e.stopImmediatePropagation(); e.preventDefault(); setMode("small"); return; }
    if (S.xl && nb.classList.contains("sbo") && innerWidth < 760 && e.target.closest("#msgs")) nb.classList.remove("sbo");
  }, true);
  window.addEventListener("keydown", e => {            // capture phase: in the large view Esc means "back to small", and must not reach the old handler that closes the whole chat
    if (e.key !== "Escape" || !S.xl || $("#dlg").open) return;
    if (e.target && e.target.classList && e.target.classList.contains("csr")) return;   // renaming: Esc cancels the rename only
    e.stopImmediatePropagation(); e.preventDefault(); setMode("small");
  }, true);
  new MutationObserver(() => { if (!nb.classList.contains("open") && S.xl) setMode("small"); }).observe(nb, { attributes: true, attributeFilter: ["class"] });   // closing the chat always returns to small
  window.addEventListener("focus", () => { if (S.xl) refreshList(); });
  new MutationObserver(() => document.querySelectorAll("#msgs pre:not([data-cp])").forEach(p => {
    p.dataset.cp = 1; const b = document.createElement("button"); b.type = "button"; b.className = "cpb"; b.textContent = "Copy";
    b.onclick = () => { const c = p.querySelector("code"); (navigator.clipboard ? navigator.clipboard.writeText(c ? c.textContent : p.textContent) : Promise.reject()).then(() => { b.textContent = "Copied"; setTimeout(() => b.textContent = "Copy", 1400); }, () => toast("Couldn't copy.")); };
    p.appendChild(b);
  })).observe($("#msgs"), { childList: true, subtree: true });
  renderList(); if (queue.length) flush();
})();
