"""Event hub: everything the AI-integration layer does with events, with no web-framework dependency
(main.py only wraps these methods in HTTP routes, so the logic is testable on its own).

Owns: validated engine events (Events tab), engine health (Engines tab), and the live-update fan-out.
Does NOT own website records (registration, accounts, payments): those stay in Apps Script + Google Sheets.
"""
import json
import os
import queue
import sys
import threading
import time
from collections import deque

_SHARED = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "shared", "contracts")
if os.path.isdir(_SHARED) and _SHARED not in sys.path:
    sys.path.insert(0, _SHARED)

import veritas_contracts as vc  # noqa: E402


class ContractError(ValueError):
    """The posted message violates the contract. .errors is a list of readable problems."""

    def __init__(self, errors):
        super().__init__("; ".join(errors))
        self.errors = errors


class EventHub:
    def __init__(self, store, engine_timeout=30, recent_size=200, clock=time.time, persist_every=10):
        self.store, self.timeout, self.clock = store, engine_timeout, clock
        self.persist_every = persist_every     # heartbeats are kept live in memory; storage is written at most this often
        self._mem: dict = {}                    # engine_key -> newest heartbeat row
        self._persisted: dict = {}              # engine_key -> (epoch, status) of the last storage write
        self._lock = threading.RLock()
        self._ids = None                      # event_ids already stored (loaded lazily, once)
        self._recent = deque(maxlen=recent_size)
        self._subs: list = []
        self.dropped_live = 0                 # live messages dropped because a client was too slow

    # ---------------------------------------------------------------- events
    def _known_ids(self):
        if self._ids is None:
            self._ids = {str(r.get("event_id")) for r in self.store.list("Events")}
        return self._ids

    @staticmethod
    def _row(ev, received_at):
        return {
            "event_id": ev["event_id"], "engine": ev["engine"], "event_type": ev["event_type"],
            "camera_id": ev["camera_id"], "timestamp": ev["timestamp"], "status": ev["status"],
            "confidence": "" if ev["confidence"] is None else ev["confidence"], "zone_id": ev["zone_id"],
            "track_id": "" if ev["track_id"] is None else ev["track_id"],
            "payload": json.dumps(ev["payload"], default=str), "evidence_refs": json.dumps(ev["evidence_refs"]),
            "received_at": received_at,
        }

    @staticmethod
    def _decode(row):
        out = dict(row)
        for k in ("payload", "evidence_refs"):
            try:
                out[k] = json.loads(out.get(k) or ("{}" if k == "payload" else "[]"))
            except (TypeError, ValueError):
                out[k] = {} if k == "payload" else []
        for k in ("confidence", "track_id"):
            if out.get(k) in ("", None):
                out[k] = None
        return out

    def ingest_event(self, raw, *, from_engine=True):
        """Validate and store one event. Returns {"status": "saved"|"updated", "event_id": ...}.
        Re-sending an existing event_id updates it (e.g. evidence attached later); it never creates a duplicate row."""
        ev, errors = vc.validate_event(raw, from_engine=from_engine)
        if errors:
            raise ContractError(errors)
        received = vc.utc_now_iso()
        with self._lock:
            ids = self._known_ids()
            if ev["event_id"] in ids:
                r = self._row(ev, received)
                changed = {k: r[k] for k in ("status", "confidence", "zone_id", "payload", "evidence_refs")}
                self.store.update("Events", "event_id", ev["event_id"], changed)
                status = "updated"
            else:
                self.store.append("Events", self._row(ev, received))
                ids.add(ev["event_id"])
                status = "saved"
            ev["received_at"] = received
            self._recent.appendleft(ev)
        self._publish({"type": "event", "status": status, "event": ev})
        return {"status": status, "event_id": ev["event_id"]}

    def list_events(self, engine=None, camera_id=None, status=None, since=None, limit=100):
        rows = [self._decode(r) for r in self.store.list("Events")]
        if engine:
            rows = [r for r in rows if r.get("engine") == engine]
        if camera_id:
            rows = [r for r in rows if r.get("camera_id") == camera_id]
        if status:
            s = vc.normalize_status(status)
            rows = [r for r in rows if r.get("status") == s]
        if since:
            cut = vc.parse_ts(since)
            rows = [r for r in rows if r.get("timestamp") and vc.parse_ts(r["timestamp"]) >= cut]
        rows.sort(key=lambda r: str(r.get("timestamp")), reverse=True)
        return rows[: max(1, min(int(limit), 1000))]

    def counts(self):
        out = {e: {"total": 0, "by_status": {}} for e in vc.ENGINES}
        for r in self.store.list("Events"):
            e = out.get(r.get("engine"))
            if e is None:
                continue
            e["total"] += 1
            e["by_status"][r.get("status")] = e["by_status"].get(r.get("status"), 0) + 1
        return out

    # ---------------------------------------------------------------- engine health
    def heartbeat(self, raw):
        hb, errors = vc.validate_heartbeat(raw)
        if errors:
            raise ContractError(errors)
        now_iso = vc.utc_now_iso()
        key = f"{hb['engine']}:{hb['instance_id']}"
        row = {"engine_key": key, "engine": hb["engine"], "instance_id": hb["instance_id"], "status": hb["status"],
               "version": hb["version"], "model": hb["model"], "fps": "" if hb["fps"] is None else hb["fps"],
               "camera_ids": json.dumps(hb["camera_ids"]), "last_frame_at": hb["last_frame_at"], "error": hb["error"],
               "details": json.dumps(hb["details"], default=str), "last_seen": now_iso, "last_seen_epoch": self.clock()}
        with self._lock:
            self._mem[key] = row
            last = self._persisted.get(key)
            if last is None or last[1] != row["status"] or self.clock() - last[0] >= self.persist_every:
                if not self.store.update("Engines", "engine_key", key, row):
                    self.store.append("Engines", row)
                self._persisted[key] = (self.clock(), row["status"])
        self._publish({"type": "engine", "engine": self.engine_status(hb["engine"])})
        return {"ok": True}

    def engine_status(self, engine):
        """Health of one engine, from the newest heartbeat of any of its instances.
        'never_connected' = no heartbeat was ever received. 'offline' = heartbeats stopped (older than the timeout)."""
        merged = {r.get("engine_key"): r for r in self.store.list("Engines") if r.get("engine") == engine}
        with self._lock:
            merged.update({k: r for k, r in self._mem.items() if r.get("engine") == engine})   # newest in-memory heartbeat wins
        rows = list(merged.values())
        base = {"engine": engine, "label": vc.ENGINE_LABELS[engine], "instances": []}
        if not rows:
            return {**base, "status": "never_connected", "last_seen": None, "age_seconds": None}
        now = self.clock()
        inst = []
        for r in rows:
            try:
                age = max(0.0, now - float(r.get("last_seen_epoch")))
            except (TypeError, ValueError):
                age = float("inf")
            reported = r.get("status")
            state = "offline" if age > self.timeout else reported
            try:
                cams = json.loads(r.get("camera_ids") or "[]")
            except ValueError:
                cams = []
            inst.append({"instance_id": r.get("instance_id"), "status": state, "reported_status": reported,
                         "version": r.get("version"), "model": r.get("model"),
                         "fps": r.get("fps") if r.get("fps") != "" else None, "camera_ids": cams,
                         "last_frame_at": r.get("last_frame_at") or None, "error": r.get("error") or None,
                         "last_seen": r.get("last_seen"), "age_seconds": None if age == float("inf") else round(age, 1)})
        inst.sort(key=lambda i: (i["age_seconds"] is None, i["age_seconds"] or 0))
        order = ["ok", "degraded", "error", "stopped", "offline"]
        live = [i for i in inst if i["status"] != "offline"]
        # the worst state among live instances is shown, so an erroring instance is never hidden by a healthy one
        overall = max(live, key=lambda i: order.index(i["status"]))["status"] if live else "offline"
        return {**base, "status": overall, "last_seen": inst[0]["last_seen"], "age_seconds": inst[0]["age_seconds"],
                "instances": inst}

    def all_engine_status(self):
        return [self.engine_status(e) for e in vc.ENGINES]

    # ---------------------------------------------------------------- live updates
    def subscribe(self, maxsize=200):
        q = queue.Queue(maxsize=maxsize)
        with self._lock:
            self._subs.append(q)
        return q

    def unsubscribe(self, q):
        with self._lock:
            if q in self._subs:
                self._subs.remove(q)

    def _publish(self, message):
        with self._lock:
            subs = list(self._subs)
        for q in subs:
            try:
                q.put_nowait(message)
            except queue.Full:
                self.dropped_live += 1
