"""Storage layer. main.py only talks to this, so switching local <-> Google Sheets
changes nothing else. Tabs/columns below are the Google Sheets structure."""
import json, os, threading, time

SCHEMA = {
    "Vehicles": ["leanbot_id", "plate_number", "robot_name", "vehicle_type", "status", "last_location", "last_detection"],
    "Detections": ["detection_id", "timestamp", "camera_id", "leanbot_label", "leanbot_confidence", "plate_number",
                   "plate_confidence", "plate_text_source", "track_id", "leanbot_box", "plate_box"],
    "Violations": ["violation_id", "plate_number", "violation_type", "date", "time", "location", "camera_id",
                   "ai_confidence", "evidence_url", "review_status", "reviewer", "remarks"],
    "Cameras": ["camera_id", "location", "stream_url", "last_seen"],
    "AuditLog": ["timestamp", "action", "record_id", "reviewer", "remarks"],
    # --- AI integration layer (added for the unified platform; additive, existing tabs are unchanged) ---
    "Events": ["event_id", "engine", "event_type", "camera_id", "timestamp", "status", "confidence", "zone_id",
               "track_id", "payload", "evidence_refs", "received_at"],
    "Engines": ["engine_key", "engine", "instance_id", "status", "version", "model", "fps", "camera_ids",
                "last_frame_at", "error", "details", "last_seen", "last_seen_epoch"],
}


class LocalStore:
    """Keeps everything in data.json. Good for testing without Google."""

    def __init__(self, path="data.json"):
        self.path, self.lock = path, threading.Lock()
        if not os.path.exists(path):
            self._save({t: [] for t in SCHEMA})

    def _load(self):
        with open(self.path, encoding="utf-8") as f:
            d = json.load(f)
        for t in SCHEMA:
            d.setdefault(t, [])
        return d

    def _save(self, d):
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f, indent=1)
        os.replace(tmp, self.path)

    def list(self, tab):
        with self.lock:
            return self._load()[tab]

    def append(self, tab, row):
        with self.lock:
            d = self._load()
            d[tab].append({k: row.get(k, "") for k in SCHEMA[tab]})
            self._save(d)

    def update(self, tab, key_field, key, updates):
        with self.lock:
            d = self._load()
            for r in d[tab]:
                if str(r.get(key_field)) == str(key):
                    r.update(updates)
                    self._save(d)
                    return r
        return None

    def delete(self, tab, key_field, key):
        with self.lock:
            d = self._load()
            keep = [r for r in d[tab] if str(r.get(key_field)) != str(key)]
            if len(keep) == len(d[tab]):
                return False
            d[tab] = keep
            self._save(d)
            return True


class SheetsStore:
    """Google Sheets. Needs a service-account JSON key and the sheet shared with that account's email.
    Reads are cached for a few seconds because Google limits requests per minute."""

    def __init__(self, sheet_id, creds_file, ttl=8):
        import gspread
        self.sh = gspread.service_account(filename=creds_file).open_by_key(sheet_id)
        self.ttl, self.cache, self.lock = ttl, {}, threading.Lock()
        existing = {w.title for w in self.sh.worksheets()}
        for tab, cols in SCHEMA.items():
            if tab not in existing:
                ws = self.sh.add_worksheet(title=tab, rows=1000, cols=len(cols))
                ws.append_row(cols)

    def _cell(self, v):
        return json.dumps(v) if isinstance(v, (list, dict)) else ("" if v is None else v)

    def list(self, tab):
        with self.lock:
            hit = self.cache.get(tab)
            if hit and time.time() - hit[0] < self.ttl:
                return hit[1]
            rows = self.sh.worksheet(tab).get_all_records(expected_headers=SCHEMA[tab])
            self.cache[tab] = (time.time(), rows)
            return rows

    def append(self, tab, row):
        with self.lock:
            self.sh.worksheet(tab).append_row([self._cell(row.get(k, "")) for k in SCHEMA[tab]],
                                              value_input_option="USER_ENTERED")
            self.cache.pop(tab, None)

    def update(self, tab, key_field, key, updates):
        with self.lock:
            ws, cols = self.sh.worksheet(tab), SCHEMA[tab]
            keys = ws.col_values(cols.index(key_field) + 1)
            if str(key) not in keys:
                return None
            r = keys.index(str(key)) + 1
            for f, v in updates.items():
                ws.update_cell(r, cols.index(f) + 1, self._cell(v))
            self.cache.pop(tab, None)
            return dict(zip(cols, ws.row_values(r)))

    def delete(self, tab, key_field, key):
        with self.lock:
            ws, cols = self.sh.worksheet(tab), SCHEMA[tab]
            keys = ws.col_values(cols.index(key_field) + 1)
            if str(key) not in keys[1:]:
                return False
            ws.delete_rows(keys.index(str(key)) + 1)
            self.cache.pop(tab, None)
            return True


def make_store():
    if os.getenv("STORAGE", "local").lower() == "sheets":
        return SheetsStore(os.environ["GOOGLE_SHEET_ID"], os.getenv("GOOGLE_CREDENTIALS_FILE", "service_account.json"))
    return LocalStore()
