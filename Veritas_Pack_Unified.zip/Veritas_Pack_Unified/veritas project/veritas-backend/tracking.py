"""Decides whether a new detection is a vehicle we are already tracking on that camera.
Pure functions (no web or storage code) so they can be tested on their own. Mirrors matchDetection_ in Code.gs.

Identity signals, strongest first:
  1. same camera + same tracker id from the same bridge run
  2. tracker id changed, but the same readable plate was seen on this camera within PLATE_TTL_S
  3. tracker id changed, no plate evidence: the box overlaps (IoU >= SPATIAL_IOU) exactly ONE record seen < SPATIAL_TTL_S ago
Otherwise: no match, so it is kept as a separate vehicle (never merge when unsure). Cameras are never merged."""
import json, re
from datetime import datetime
from typing import Optional

TRACK_TTL_S, PLATE_TTL_S, SPATIAL_TTL_S, SPATIAL_IOU, MIN_PLATE_LEN = 600, 60, 4, 0.6, 4


def to_ms(v) -> float:
    try:
        return datetime.fromisoformat(str(v).replace("Z", "+00:00")).timestamp() * 1000
    except Exception:
        return 0.0


def parse_box(v) -> Optional[list]:
    if isinstance(v, str):
        try:
            v = json.loads(v)
        except Exception:
            return None
    try:
        if isinstance(v, (list, tuple)) and len(v) >= 4:
            return [float(n) for n in v[:4]]
    except (TypeError, ValueError):
        pass
    return None


def iou(a, b) -> float:
    w, h = min(a[2], b[2]) - max(a[0], b[0]), min(a[3], b[3]) - max(a[1], b[1])
    if w <= 0 or h <= 0:
        return 0.0
    inter = w * h
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / union if union > 0 else 0.0


def usable_plate(p) -> bool:
    return len(re.sub(r"[^A-Za-z0-9]", "", str(p or ""))) >= MIN_PLATE_LEN


def find_match(cands: list, d: dict, norm) -> Optional[dict]:
    """cands: Detections rows on the SAME camera. d: {ts_ms, track_key, plate, box, label}. Returns the matching row or None."""
    age = lambda r: (d["ts_ms"] - to_ms(r.get("timestamp"))) / 1000
    newest = sorted(cands, key=lambda r: to_ms(r.get("timestamp")), reverse=True)
    if d["track_key"]:
        for r in newest:
            if r.get("track_key") == d["track_key"] and age(r) <= TRACK_TTL_S:
                return r
    if usable_plate(d["plate"]):
        for r in newest:
            if norm(str(r.get("plate_number", ""))) == d["plate"] and age(r) <= PLATE_TTL_S:
                return r
    if d["box"]:
        near = []
        for r in newest:
            if abs(age(r)) > SPATIAL_TTL_S or r.get("leanbot_label") != d["label"]:
                continue
            cp = norm(str(r.get("plate_number", "")))
            if usable_plate(cp) and usable_plate(d["plate"]) and cp != d["plate"]:
                continue                      # two different readable plates = two vehicles
            cb = parse_box(r.get("leanbot_box"))
            if cb and iou(cb, d["box"]) >= SPATIAL_IOU:
                near.append(r)
        if len(near) == 1:
            return near[0]
    return None
