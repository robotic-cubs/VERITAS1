"""Data shapes and helpers. Field names match what admin.html reads."""
import re
from typing import Optional
from pydantic import BaseModel, Field


def normalize_plate(text: str) -> str:
    """'pxr2418' / 'PXR-2418' -> 'PXR 2418'. Anything unusual is just upper-cased."""
    s = re.sub(r"[^A-Za-z0-9]", "", text or "").upper()
    m = re.match(r"^([A-Z]+)(\d+)$", s)
    return f"{m.group(1)} {m.group(2)}" if m else s


class DetectionIn(BaseModel):
    """What the AI bridge sends. Everything the AI itself produced is optional-safe;
    plate_number stays empty when no OCR ran."""
    camera_id: str = "CAM-001"
    leanbot_label: str = "Leanbot"
    leanbot_confidence: float = Field(ge=0, le=1)
    plate_confidence: Optional[float] = Field(default=None, ge=0, le=1)
    plate_number: str = ""
    plate_text_source: str = "none"          # "ocr" or "none"
    leanbot_box: Optional[list[float]] = None  # [x1, y1, x2, y2] pixels
    plate_box: Optional[list[float]] = None
    track_id: Optional[int] = None
    timestamp: Optional[str] = None          # ISO time; the backend adds one if missing


class CameraIn(BaseModel):
    camera_id: str
    location: str = ""
    stream_url: str = ""


class VehicleIn(BaseModel):
    leanbot_id: str
    plate_number: str
    robot_name: str = ""
    vehicle_type: str = "Leanbot"
    status: str = "Active"


class ViolationIn(BaseModel):
    """Violations are NOT produced by the AI. This is for an admin (or a future rule engine)."""
    plate_number: str
    violation_type: str
    location: str = ""
    camera_id: str = ""
    ai_confidence: Optional[float] = Field(default=None, ge=0, le=1)
    evidence_url: str = ""


class ReviewIn(BaseModel):
    reviewer: str = "Admin"
    remarks: str = ""
