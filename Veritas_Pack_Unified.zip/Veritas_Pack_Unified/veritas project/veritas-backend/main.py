"""VERITAS backend. Run:  uvicorn main:app --host 127.0.0.1 --port 8000
The dashboard (admin.html) reads the /api/* GET endpoints; the unified AI pipeline (veritas-bridge, model 723image.pt) posts to /api/ingest/*."""
import hmac, os, threading, time, uuid
from datetime import datetime, timezone

from dotenv import load_dotenv
from fastapi import Body, Depends, FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse

from models import CameraIn, DetectionIn, ReviewIn, VehicleIn, ViolationIn, normalize_plate
from store import make_store
from event_hub import ContractError, EventHub
import veritas_contracts as vc  # resolved by event_hub (adds ../../shared/contracts to sys.path)

load_dotenv()
store = make_store()
hub = EventHub(store, engine_timeout=int(os.getenv("ENGINE_TIMEOUT_SECONDS", "30")))
INGEST_KEY = os.getenv("INGEST_KEY", "")
ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "")
DEDUPE_SECONDS = int(os.getenv("DEDUPE_SECONDS", "30"))
# When true, the new AI read endpoints need the admin token (X-Admin-Token header, or ?token= for the live stream).
PROTECT_READS = os.getenv("PROTECT_AI_READS", "").lower() in ("1", "true", "yes")
CAMERA_TIMEOUT = 30  # seconds without a heartbeat -> "Disconnected"
# The unified AI pipeline (one process, one model: 723image.pt) pushes its live state about twice a second.
# No state for this many seconds -> the dashboard shows the AI service as OFFLINE.
AI_STATE_TIMEOUT = float(os.getenv("AI_STATE_TIMEOUT_SECONDS", "6"))

app = FastAPI(title="VERITAS API")
# "*" lets admin.html work when opened by double-click. Tighten this when you host it.
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

_seen: dict = {}
_seen_lock = threading.Lock()


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def require_ingest(x_api_key: str = Header(default="")):
    if not INGEST_KEY:
        raise HTTPException(503, "INGEST_KEY is not set on the server.")
    if not hmac.compare_digest(x_api_key, INGEST_KEY):
        raise HTTPException(401, "Bad API key.")


def require_admin(x_admin_token: str = Header(default="")):
    # If ADMIN_TOKEN is empty we allow it, which is only OK while bound to 127.0.0.1.
    if ADMIN_TOKEN and not hmac.compare_digest(x_admin_token, ADMIN_TOKEN):
        raise HTTPException(401, "Admin token required.")


def read_guard(x_admin_token: str = Header(default=""), token: str = Query(default="")):
    """Optional protection for the AI read endpoints (PROTECT_AI_READS=true). EventSource cannot set headers, hence ?token=."""
    if PROTECT_READS:
        given = x_admin_token or token
        if not ADMIN_TOKEN or not hmac.compare_digest(given, ADMIN_TOKEN):
            raise HTTPException(401, "Admin token required.")


# ---------------- read endpoints (used by the dashboard) ----------------
@app.get("/api/health")
def health():
    return {"ok": True, "storage": os.getenv("STORAGE", "local")}


@app.get("/api/vehicles")
def vehicles():
    return store.list("Vehicles")


@app.get("/api/detections")
def detections():
    return sorted(store.list("Detections"), key=lambda r: str(r.get("timestamp")), reverse=True)[:500]


@app.get("/api/violations")
def violations():
    return sorted(store.list("Violations"), key=lambda r: f"{r.get('date')} {r.get('time')}", reverse=True)


@app.get("/api/cameras")
def cameras():
    out = []
    for c in store.list("Cameras"):
        try:
            age = time.time() - datetime.fromisoformat(str(c["last_seen"])).timestamp()
        except Exception:
            age = 1e9
        out.append({**c, "status": "Connected" if age < CAMERA_TIMEOUT else "Disconnected"})
    return out


# ---------------- admin actions ----------------
@app.post("/api/vehicles", dependencies=[Depends(require_admin)])
def register_vehicle(v: VehicleIn):
    plate = normalize_plate(v.plate_number)
    if any(normalize_plate(str(r["plate_number"])) == plate for r in store.list("Vehicles")):
        raise HTTPException(409, "That plate is already registered.")
    row = {**v.model_dump(), "plate_number": plate, "last_location": "", "last_detection": ""}
    store.append("Vehicles", row)
    return row


@app.delete("/api/vehicles/{leanbot_id}", dependencies=[Depends(require_admin)])
def unregister_vehicle(leanbot_id: str):
    # Only removes the registration. Past detections and violations stay on record.
    if not store.delete("Vehicles", "leanbot_id", leanbot_id):
        raise HTTPException(404, "Vehicle not found.")
    store.append("AuditLog", {"timestamp": now_iso(), "action": "Unregistered", "record_id": leanbot_id,
                              "reviewer": "Admin", "remarks": ""})
    return {"ok": True}


@app.post("/api/violations", dependencies=[Depends(require_admin)])
def create_violation(v: ViolationIn):
    n = now_iso()
    row = {"violation_id": "VIO-" + uuid.uuid4().hex[:8].upper(), **v.model_dump(),
           "plate_number": normalize_plate(v.plate_number), "date": n[:10], "time": n[11:19],
           "review_status": "Pending", "reviewer": "", "remarks": ""}
    store.append("Violations", row)
    return row


def _review(vid: str, status: str, r: ReviewIn):
    rec = next((x for x in store.list("Violations") if x["violation_id"] == vid), None)
    if not rec:
        raise HTTPException(404, "Violation not found.")
    if rec["review_status"] != "Pending":
        raise HTTPException(409, f"Already {rec['review_status']}.")
    if status == "Rejected" and not r.remarks.strip():
        raise HTTPException(422, "A remark is required to reject.")
    upd = {"review_status": status, "reviewer": r.reviewer, "remarks": r.remarks}
    store.update("Violations", "violation_id", vid, upd)
    store.append("AuditLog", {"timestamp": now_iso(), "action": status, "record_id": vid,
                              "reviewer": r.reviewer, "remarks": r.remarks})
    return {**rec, **upd}


@app.post("/api/violations/{vid}/approve", dependencies=[Depends(require_admin)])
def approve(vid: str, r: ReviewIn):
    return _review(vid, "Confirmed", r)


@app.post("/api/violations/{vid}/reject", dependencies=[Depends(require_admin)])
def reject(vid: str, r: ReviewIn):
    return _review(vid, "Rejected", r)


# ---------------- ingest endpoints (used by the AI bridge) ----------------
@app.post("/api/ingest/camera", dependencies=[Depends(require_ingest)])
def camera_heartbeat(c: CameraIn):
    row = {**c.model_dump(), "last_seen": now_iso()}
    if not store.update("Cameras", "camera_id", c.camera_id, {k: v for k, v in row.items() if v != "" or k == "last_seen"}):
        store.append("Cameras", row)
    # The bridge runs the Leanbot model, so its camera heartbeat is the only Leanbot liveness signal available today.
    try:
        hub.heartbeat({"engine": "leanbot", "instance_id": ("bridge:" + c.camera_id)[:64], "status": "ok",
                       "camera_ids": [c.camera_id], "details": {"source": "bridge camera heartbeat"}})
    except Exception as e:  # noqa: BLE001  (never break the existing camera endpoint)
        print("VERITAS: could not record Leanbot engine heartbeat:", e)
    return {"ok": True}


@app.post("/api/ingest/detection", dependencies=[Depends(require_ingest)])
def ingest_detection(d: DetectionIn):
    # Skip repeats of the same tracked Leanbot on the same camera.
    if d.track_id is not None:
        k, t = (d.camera_id, d.track_id), time.time()
        with _seen_lock:
            if t - _seen.get(k, 0) < DEDUPE_SECONDS:
                return {"status": "duplicate"}
            _seen[k] = t
    ts = d.timestamp or now_iso()
    plate = normalize_plate(d.plate_number)
    row = {"detection_id": "DET-" + uuid.uuid4().hex[:8].upper(), "timestamp": ts, "camera_id": d.camera_id,
           "leanbot_label": d.leanbot_label, "leanbot_confidence": round(d.leanbot_confidence, 3),
           "plate_number": plate,
           "plate_confidence": "" if d.plate_confidence is None else round(d.plate_confidence, 3),
           "plate_text_source": d.plate_text_source, "track_id": d.track_id if d.track_id is not None else "",
           "leanbot_box": d.leanbot_box or "", "plate_box": d.plate_box or ""}
    store.append("Detections", row)
    if plate:
        veh = next((v for v in store.list("Vehicles") if normalize_plate(str(v["plate_number"])) == plate), None)
        if veh:
            loc = next((c["location"] for c in store.list("Cameras") if c["camera_id"] == d.camera_id), "")
            store.update("Vehicles", "leanbot_id", veh["leanbot_id"], {"last_detection": ts, "last_location": loc})
    # Mirror into the combined event feed. A failure here must never lose the detection that is already saved.
    try:
        hub.ingest_event(vc.from_leanbot_detection(row))
    except Exception as e:  # noqa: BLE001
        print("VERITAS: could not mirror detection into the event feed:", e)
    return {"status": "saved", "detection_id": row["detection_id"]}


# ---------------- unified AI pipeline: live state (one model -> Leanbot + Pedestrian) ----------------
AI_CATEGORIES = ("leanbot", "pedestrian", "plate")
_live: dict = {}                      # camera_id -> {"state": cleaned message, "recv": epoch seconds}
_live_lock = threading.Lock()
_hb_sent: dict = {}                   # engine -> epoch of the last heartbeat derived from a live state


def _num(v, lo=None, hi=None):
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return None
    if (lo is not None and v < lo) or (hi is not None and v > hi):
        return None
    return float(v)


def _clean_ai_state(raw: dict):
    """Validate one live-state message from the unified pipeline. Returns (clean, errors)."""
    errs = []
    cam = str(raw.get("camera_id") or "").strip()
    if not cam or len(cam) > 64:
        errs.append("camera_id is required (max 64 characters)")
    classes = raw.get("classes", [])
    if not isinstance(classes, list) or not all(isinstance(c, str) for c in classes):
        errs.append("classes must be a list of class names")
        classes = []
    dets_in = raw.get("detections", [])
    if not isinstance(dets_in, list) or len(dets_in) > 300:
        errs.append("detections must be a list (max 300)")
        dets_in = []
    dets = []
    for i, d in enumerate(dets_in):
        if not isinstance(d, dict):
            errs.append(f"detections[{i}] must be an object")
            continue
        cat, conf, box = str(d.get("category", "")).lower(), _num(d.get("confidence"), 0, 1), d.get("box")
        if cat not in AI_CATEGORIES:
            errs.append(f"detections[{i}].category must be one of {list(AI_CATEGORIES)}")
            continue
        if conf is None:
            errs.append(f"detections[{i}].confidence must be a number between 0 and 1")
            continue
        if not (isinstance(box, list) and len(box) == 4 and all(_num(v) is not None for v in box)):
            errs.append(f"detections[{i}].box must be [x1, y1, x2, y2]")
            continue
        tid = d.get("track_id")
        tid = tid if isinstance(tid, int) and not isinstance(tid, bool) else None
        dets.append({"category": cat, "label": str(d.get("label") or cat)[:60], "confidence": round(conf, 4),
                     "box": [round(float(v), 1) for v in box], "track_id": tid})
    clean = {
        "camera_id": cam, "model": str(raw.get("model") or "")[:120], "model_loaded": bool(raw.get("model_loaded")),
        "camera_connected": bool(raw.get("camera_connected")), "inference_running": bool(raw.get("inference_running")),
        "stopping": bool(raw.get("stopping")), "fps": _num(raw.get("fps"), 0), "inference_ms": _num(raw.get("inference_ms"), 0),
        "frame_size": [int(v) for v in (raw.get("frame_size") or [])[:2] if _num(v) is not None],
        "classes": classes[:50], "detections": dets, "timestamp": vc.utc_now_iso(),
    }
    return clean, errs


def _engine_heartbeats(st: dict):
    """The unified pipeline is ONE process, so both engine cards are fed from the same state message (at most every 5 s each)."""
    now = time.time()
    names = {c.lower() for c in st["classes"]}
    for engine, cls in (("leanbot", "leanbot"), ("pedestrian", "pedestrian")):
        if now - _hb_sent.get(engine, 0) < 5 and not st["stopping"]:
            continue
        _hb_sent[engine] = now
        if st["stopping"]:
            status, err = "stopped", ""
        elif not st["camera_connected"]:
            status, err = "degraded", "camera is not giving pictures"
        elif not st["inference_running"]:
            status, err = "degraded", "inference is not running"
        elif cls not in names:
            status, err = "degraded", f"the model has no {cls.capitalize()} class"
        else:
            status, err = "ok", ""
        try:
            hub.heartbeat({"engine": engine, "instance_id": ("unified:" + st["camera_id"])[:64], "status": status,
                           "version": "unified-ai/1", "model": st["model"], "fps": st["fps"], "camera_ids": [st["camera_id"]],
                           "last_frame_at": st["timestamp"] if st["camera_connected"] else "", "error": err,
                           "details": {"source": "unified AI pipeline", "classes": st["classes"]}})
        except Exception as e:  # noqa: BLE001  (a heartbeat problem must never reject the live state)
            print("VERITAS: could not record engine heartbeat:", e)


@app.post("/api/ingest/ai-state", dependencies=[Depends(require_ingest)])
def ingest_ai_state(payload: dict = Body(...)):
    """Live state of the unified AI pipeline: model/camera/inference status + the detections of the newest frame."""
    clean, errs = _clean_ai_state(payload)
    if errs:
        raise HTTPException(422, {"message": "AI state does not follow the expected format.", "errors": errs})
    with _live_lock:
        _live[clean["camera_id"]] = {"state": clean, "recv": 0.0 if clean["stopping"] else time.time()}   # a clean shutdown = offline at once
    _engine_heartbeats(clean)
    return {"ok": True}


@app.get("/api/ai/state", dependencies=[Depends(read_guard)])
def ai_state():
    """What the unified pipeline sees RIGHT NOW. Nothing is simulated: an AI that stopped is reported offline and shows no detections."""
    now = time.time()
    with _live_lock:
        items = list(_live.values())
    cams, dets = [], {"leanbot": [], "pedestrian": [], "plate": []}
    for it in sorted(items, key=lambda x: x["recv"], reverse=True):
        st, age = it["state"], now - it["recv"]
        on = age <= AI_STATE_TIMEOUT and not st["stopping"]
        cams.append({"camera_id": st["camera_id"], "online": on, "age_seconds": None if it["recv"] == 0 else round(age, 1),
                     "camera_connected": on and st["camera_connected"], "inference_running": on and st["inference_running"],
                     "fps": st["fps"], "inference_ms": st["inference_ms"], "frame_size": st["frame_size"], "timestamp": st["timestamp"]})
        if on and st["inference_running"]:
            for d in st["detections"]:
                dets[d["category"]].append({**d, "camera_id": st["camera_id"], "timestamp": st["timestamp"]})
    live = [c for c in cams if c["online"]]
    newest = max(items, key=lambda x: x["recv"])["state"] if items else None
    ref = next((it["state"] for it in sorted(items, key=lambda x: x["recv"], reverse=True) if it["recv"] and now - it["recv"] <= AI_STATE_TIMEOUT), newest)
    classes = [c.lower() for c in (ref["classes"] if ref else [])]
    return {
        "online": bool(live), "never_connected": not items, "server_time": vc.utc_now_iso(),
        "model": ref["model"] if ref else "", "model_loaded": bool(live and ref and ref["model_loaded"]),
        "camera_connected": any(c["camera_connected"] for c in live), "inference_running": any(c["inference_running"] for c in live),
        "fps": live[0]["fps"] if live else None, "inference_ms": live[0]["inference_ms"] if live else None,
        "classes": ref["classes"] if ref else [], "cameras": cams,
        "leanbot": {"supported": "leanbot" in classes, "count": len(dets["leanbot"]), "detections": dets["leanbot"]},
        "pedestrian": {"supported": "pedestrian" in classes, "count": len(dets["pedestrian"]), "detections": dets["pedestrian"]},
        "plate": {"supported": "plate" in classes, "count": len(dets["plate"])},
    }


# ---------------- AI integration layer (engines -> FastAPI -> dashboard) ----------------
def _contract(fn, payload):
    try:
        return fn(payload)
    except ContractError as e:
        raise HTTPException(422, {"message": "Message does not follow the VERITAS contract.", "errors": e.errors})


@app.post("/api/ingest/event", dependencies=[Depends(require_ingest)])
def ingest_event(payload: dict = Body(...)):
    """Canonical veritas-event/1 from ANY engine (Leanbot or Pedestrian). Engines cannot set CONFIRMED/REJECTED."""
    return _contract(hub.ingest_event, payload)


@app.post("/api/ingest/heartbeat", dependencies=[Depends(require_ingest)])
def ingest_heartbeat(payload: dict = Body(...)):
    """veritas-heartbeat/1: engine liveness and health (status, model, fps, cameras, last error)."""
    return _contract(hub.heartbeat, payload)


@app.get("/api/engines", dependencies=[Depends(read_guard)])
def engines():
    """Health of both engines. 'never_connected' means no heartbeat was ever received; 'offline' means they stopped."""
    return hub.all_engine_status()


@app.get("/api/events", dependencies=[Depends(read_guard)])
def events(engine: str = "", camera_id: str = "", status: str = "", since: str = "", limit: int = 100):
    """Combined, newest-first event feed of both engines, from stored records."""
    if engine and engine not in vc.ENGINES:
        raise HTTPException(422, f"engine must be one of {list(vc.ENGINES)}")
    try:
        return hub.list_events(engine or None, camera_id or None, status or None, since or None, limit)
    except ValueError as e:
        raise HTTPException(422, str(e))


@app.get("/api/system/health", dependencies=[Depends(read_guard)])
def system_health():
    """One call for the monitoring page: storage, engines, cameras, event counts."""
    return {"ok": True, "storage": os.getenv("STORAGE", "local"), "engines": hub.all_engine_status(),
            "cameras": cameras(), "event_counts": hub.counts(), "live_messages_dropped": hub.dropped_live,
            "server_time": vc.utc_now_iso()}


@app.get("/api/stream", dependencies=[Depends(read_guard)])
def stream():
    """Server-Sent Events: live 'event' and 'engine' messages. A ': keepalive' comment is sent every 15 s."""
    import json as _json
    import queue as _queue

    q = hub.subscribe()

    def gen():
        try:
            yield "retry: 3000\n\n"
            while True:
                try:
                    m = q.get(timeout=15)
                    yield f"event: {m['type']}\ndata: {_json.dumps(m, default=str)}\n\n"
                except _queue.Empty:
                    yield ": keepalive\n\n"
        finally:
            hub.unsubscribe(q)

    return StreamingResponse(gen(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
