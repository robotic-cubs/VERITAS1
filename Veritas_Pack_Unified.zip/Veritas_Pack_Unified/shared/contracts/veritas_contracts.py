"""VERITAS canonical contracts (stdlib only, no FastAPI / model imports).

Two message types travel from any AI engine to the FastAPI integration layer:

  veritas-event/1      one detection or behaviour event
  veritas-heartbeat/1  "I am alive" + engine health

Rules that every engine and the backend share:
  * Engines may report DETECTED / POTENTIAL_VIOLATION / UNVERIFIED / AWAITING_REVIEW.
  * CONFIRMED and REJECTED are set ONLY by a human administrator, never by an engine.
  * Engine-specific details go inside `payload`; the envelope fields stay identical for every engine,
    so the dashboard can show one combined feed.
  * Timestamps are UTC ISO-8601.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone

EVENT_SCHEMA = "veritas-event/1"
HEARTBEAT_SCHEMA = "veritas-heartbeat/1"

ENGINES = ("leanbot", "pedestrian")
ENGINE_LABELS = {"leanbot": "Leanbot AI", "pedestrian": "Pedestrian AI"}

ENGINE_STATUSES = ("ok", "degraded", "error", "stopped")
EVENT_STATUSES = ("DETECTED", "POTENTIAL_VIOLATION", "UNVERIFIED", "AWAITING_REVIEW", "CONFIRMED", "REJECTED")
HUMAN_ONLY_STATUSES = ("CONFIRMED", "REJECTED")

MAX_ID = 64
MAX_TEXT = 200
MAX_PAYLOAD_BYTES = 64 * 1024


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def parse_ts(value) -> datetime:
    """Parse an ISO-8601 string (accepts a trailing Z). Naive times are treated as UTC. Raises ValueError."""
    if not isinstance(value, str) or not value.strip():
        raise ValueError("timestamp must be a non-empty ISO-8601 string")
    s = value.strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    dt = datetime.fromisoformat(s)
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def normalize_status(value) -> str:
    """'POTENTIAL VIOLATION' / 'potential-violation' -> 'POTENTIAL_VIOLATION'."""
    return re.sub(r"[\s\-]+", "_", str(value or "DETECTED").strip()).upper()


def _text(d, key, errors, required=False, default="", limit=MAX_TEXT):
    v = d.get(key, default)
    if v is None:
        v = default
    if not isinstance(v, (str, int)) or isinstance(v, bool):
        errors.append(f"{key} must be text")
        return default
    v = str(v).strip()
    if required and not v:
        errors.append(f"{key} is required")
    if len(v) > limit:
        errors.append(f"{key} is longer than {limit} characters")
    return v


def _confidence(d, errors):
    v = d.get("confidence")
    if v is None or v == "":
        return None
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not (0 <= v <= 1):
        errors.append("confidence must be a number between 0 and 1")
        return None
    return round(float(v), 4)


def validate_event(raw, *, from_engine: bool = True):
    """Return (clean_event, errors). `errors` empty means the event is acceptable.

    from_engine=True enforces that an AI engine cannot set a human-only status."""
    errors: list = []
    if not isinstance(raw, dict):
        return {}, ["event must be a JSON object"]
    if raw.get("schema", EVENT_SCHEMA) != EVENT_SCHEMA:
        errors.append(f"unsupported schema {raw.get('schema')!r}; expected {EVENT_SCHEMA!r}")

    engine = _text(raw, "engine", errors, required=True).lower()
    if engine and engine not in ENGINES:
        errors.append(f"engine must be one of {list(ENGINES)}")
    event_id = _text(raw, "event_id", errors, required=True, limit=MAX_ID)
    event_type = _text(raw, "event_type", errors, required=True)
    camera_id = _text(raw, "camera_id", errors, required=True, limit=MAX_ID)

    ts = ""
    try:
        ts = parse_ts(raw.get("timestamp")).isoformat(timespec="milliseconds")
    except (ValueError, TypeError) as e:
        errors.append(f"timestamp invalid: {e}")

    status = normalize_status(raw.get("status", "DETECTED"))
    if status not in EVENT_STATUSES:
        errors.append(f"status must be one of {list(EVENT_STATUSES)}")
    elif from_engine and status in HUMAN_ONLY_STATUSES:
        errors.append(f"status {status} can only be set by a human administrator")

    track_id = raw.get("track_id")
    if track_id in ("", None):
        track_id = None
    elif isinstance(track_id, bool) or not isinstance(track_id, int):
        errors.append("track_id must be an integer or null")
        track_id = None

    payload = raw.get("payload", {})
    if payload is None:
        payload = {}
    if not isinstance(payload, dict):
        errors.append("payload must be an object")
        payload = {}
    evidence = raw.get("evidence_refs", [])
    if evidence is None:
        evidence = []
    if not isinstance(evidence, list) or not all(isinstance(x, str) for x in evidence):
        errors.append("evidence_refs must be a list of strings")
        evidence = []
    zone_id = _text(raw, "zone_id", errors, limit=MAX_ID)

    clean = {
        "schema": EVENT_SCHEMA, "event_id": event_id, "engine": engine, "event_type": event_type,
        "camera_id": camera_id, "timestamp": ts, "status": status, "confidence": _confidence(raw, errors),
        "zone_id": zone_id, "track_id": track_id, "payload": payload, "evidence_refs": evidence,
    }
    import json
    if len(json.dumps(payload, default=str)) > MAX_PAYLOAD_BYTES:
        errors.append(f"payload is larger than {MAX_PAYLOAD_BYTES} bytes")
    return clean, errors


def validate_heartbeat(raw):
    """Return (clean_heartbeat, errors)."""
    errors: list = []
    if not isinstance(raw, dict):
        return {}, ["heartbeat must be a JSON object"]
    if raw.get("schema", HEARTBEAT_SCHEMA) != HEARTBEAT_SCHEMA:
        errors.append(f"unsupported schema {raw.get('schema')!r}; expected {HEARTBEAT_SCHEMA!r}")
    engine = _text(raw, "engine", errors, required=True).lower()
    if engine and engine not in ENGINES:
        errors.append(f"engine must be one of {list(ENGINES)}")
    instance_id = _text(raw, "instance_id", errors, default="default", limit=MAX_ID) or "default"
    status = str(raw.get("status", "ok")).strip().lower()
    if status not in ENGINE_STATUSES:
        errors.append(f"status must be one of {list(ENGINE_STATUSES)}")
    cams = raw.get("camera_ids", [])
    if not isinstance(cams, list) or not all(isinstance(c, str) for c in cams):
        errors.append("camera_ids must be a list of strings")
        cams = []
    fps = raw.get("fps")
    if fps in ("", None):
        fps = None
    elif isinstance(fps, bool) or not isinstance(fps, (int, float)) or fps < 0:
        errors.append("fps must be a non-negative number or null")
        fps = None
    last_frame_at = raw.get("last_frame_at") or ""
    if last_frame_at:
        try:
            last_frame_at = parse_ts(last_frame_at).isoformat(timespec="milliseconds")
        except (ValueError, TypeError):
            errors.append("last_frame_at must be an ISO-8601 time")
            last_frame_at = ""
    clean = {
        "schema": HEARTBEAT_SCHEMA, "engine": engine, "instance_id": instance_id, "status": status,
        "version": _text(raw, "version", errors), "model": _text(raw, "model", errors),
        "fps": fps, "camera_ids": cams, "last_frame_at": last_frame_at,
        "error": _text(raw, "error", errors, limit=500),
        "details": raw.get("details") if isinstance(raw.get("details"), dict) else {},
    }
    return clean, errors


# ---------------------------------------------------------------- mappers (engine-native -> canonical)
def from_leanbot_detection(row: dict) -> dict:
    """Map a stored Leanbot detection row (backend Detections tab / bridge payload) to a veritas-event/1 envelope."""
    return {
        "schema": EVENT_SCHEMA, "engine": "leanbot", "event_id": row.get("detection_id"),
        "event_type": "LEANBOT_DETECTED", "camera_id": row.get("camera_id"), "timestamp": row.get("timestamp"),
        "status": "DETECTED", "confidence": row.get("leanbot_confidence"), "zone_id": "",
        "track_id": row.get("track_id") if row.get("track_id") not in ("", None) else None,
        "evidence_refs": [],
        "payload": {
            "leanbot_label": row.get("leanbot_label") or "Leanbot", "plate_number": row.get("plate_number") or "",
            "plate_confidence": row.get("plate_confidence") if row.get("plate_confidence") != "" else None,
            "plate_text_source": row.get("plate_text_source") or "none",
            "leanbot_box": row.get("leanbot_box") or None, "plate_box": row.get("plate_box") or None,
        },
    }
