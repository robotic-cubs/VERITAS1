# VERITAS event contracts (`veritas-event/1`, `veritas-heartbeat/1`)

One envelope for every AI engine, so the dashboard can show one combined feed. Code: `veritas_contracts.py` (standard library only).
Engine-specific detail goes in `payload`; the envelope never changes per engine.

## Event (`POST /api/ingest/event`, header `X-API-Key`)
| Field | Type | Notes |
|---|---|---|
| `schema` | `"veritas-event/1"` | optional, checked if present |
| `engine` | `leanbot` \| `pedestrian` | required |
| `event_id` | text ≤64 | required, **unique and stable**: re-sending the same id *updates* the event (e.g. evidence attached later), never duplicates |
| `event_type` | text | required, e.g. `LEANBOT_DETECTED`, `ZONE_ENTER`, `CROSSING_COMPLETED`, `PROHIBITED_PHASE_CROSSING` |
| `camera_id` | text ≤64 | required |
| `timestamp` | ISO-8601 | required, UTC (a trailing `Z` is accepted) |
| `status` | `DETECTED` `POTENTIAL_VIOLATION` `UNVERIFIED` `AWAITING_REVIEW` | `CONFIRMED`/`REJECTED` are **human-only** and are refused from engines (HTTP 422) |
| `confidence` | 0..1 or null | |
| `zone_id`, `track_id` | text, integer or null | track ids are only unique per camera/run |
| `payload` | object ≤64 KB | Leanbot: label, plate_number, plate_confidence, plate_text_source, boxes. Pedestrian: label, bbox, model, run_id, notes |
| `evidence_refs` | list of text | file paths / URLs of saved frames or clips |

## Heartbeat (`POST /api/ingest/heartbeat`)
`engine`, `instance_id` (default `default`), `status` = `ok` `degraded` `error` `stopped`, `version`, `model`, `fps`, `camera_ids`, `last_frame_at`, `error`, `details`.
The backend adds receive time. No heartbeat for `ENGINE_TIMEOUT_SECONDS` (default 30) -> shown as **offline**; never heard from -> **never_connected**.
A healthy instance never hides an erroring one (the worst live state is shown).

## Mappers
`from_leanbot_detection()` converts a Leanbot detection row. The unified AI pipeline (`veritas-bridge`, model `723image.pt`) builds its Leanbot and Pedestrian events directly in this envelope, so no mapper is needed for them.
