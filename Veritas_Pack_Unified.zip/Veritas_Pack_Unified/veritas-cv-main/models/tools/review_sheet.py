import cv2, numpy as np, json, sys, random
def tile(fr,box,plates,size=230,label=""):
    x1,y1,x2,y2=box; cx,cy=(x1+x2)//2,(y1+y2)//2; r=max(x2-x1,y2-y1)//2+30
    X1,Y1=cx-r,cy-r; pad=cv2.copyMakeBorder(fr,r,r,r,r,cv2.BORDER_CONSTANT,value=(60,60,60))
    crop=pad[Y1+r:Y1+r+2*r,X1+r:X1+r+2*r].copy()
    cv2.rectangle(crop,(x1-X1,y1-Y1),(x2-X1,y2-Y1),(0,255,0),1)
    for k,p in enumerate(plates):
        b=p["box"] if isinstance(p,dict) else p
        cv2.rectangle(crop,(b[0]-X1,b[1]-Y1),(b[2]-X1,b[3]-Y1),(0,255,255),1)
    t=cv2.resize(crop,(size,size),interpolation=cv2.INTER_CUBIC); cv2.putText(t,label,(3,13),0,0.42,(255,255,0),1); return t
def sheet(items,out,cols=5):
    rows=[np.hstack(items[i:i+cols]+[np.zeros_like(items[0])]*(cols-len(items[i:i+cols]))) for i in range(0,len(items),cols)]
    cv2.imwrite(out,np.vstack(rows))
