"""Build the YOLO datasets from work/labels.json (made by build_labels.py) and the frames in work/f14.
Run from the folder that contains work/:  python3 build_dataset.py --out <models>/dataset
 leanbot/ : full frames, class 0 = Leanbot (all labelled frames, near-duplicate frames thinned in train)
 plate/   : crops around the robot, class 0 = Plate (ONLY eye-verified / propagated plate frames, several jittered crops each)
Split is BY VIDEO so validation never sees frames of a training video:  train = video1,2,3   val = video4."""
import argparse, json, os, random, shutil, cv2, numpy as np
ap=argparse.ArgumentParser(); ap.add_argument("--out",required=True); ap.add_argument("--work",default="work"); a=ap.parse_args()
random.seed(42); lab=json.load(open(f"{a.work}/labels.json"))
VAL={"video4"}
for d in ("leanbot","plate"):
    shutil.rmtree(f"{a.out}/{d}",ignore_errors=True)
    for s in ("train","val"):
        os.makedirs(f"{a.out}/{d}/images/{s}"); os.makedirs(f"{a.out}/{d}/labels/{s}")
def iou(p,q):
    ix=max(0,min(p[2],q[2])-max(p[0],q[0])); iy=max(0,min(p[3],q[3])-max(p[1],q[1])); i=ix*iy
    u=(p[2]-p[0])*(p[3]-p[1])+(q[2]-q[0])*(q[3]-q[1])-i; return i/u if u else 0
def yolo(b,W,H):
    x1,y1,x2,y2=[min(max(v,0),m) for v,m in zip(b,(W,H,W,H))]
    return f"0 {(x1+x2)/2/W:.6f} {(y1+y2)/2/H:.6f} {(x2-x1)/W:.6f} {(y2-y1)/H:.6f}\n"
stats={}
last={}
for n in sorted(lab):
    vid=n.split("_")[0]; split="val" if vid in VAL else "train"; l=lab[n]
    fr=cv2.imread(f"{a.work}/f14/{n}"); H,W=fr.shape[:2]
    # ---- leanbot (full frame)
    if split=="train" and vid in last and iou(last[vid],l["leanbot"])>0.97: pass   # robot has not moved: skip near-duplicate
    else:
        last[vid]=l["leanbot"]; stem=n[:-4]
        cv2.imwrite(f"{a.out}/leanbot/images/{split}/{stem}.jpg",fr,[cv2.IMWRITE_JPEG_QUALITY,92])
        open(f"{a.out}/leanbot/labels/{split}/{stem}.txt","w").write(yolo(l["leanbot"],W,H))
        stats[("leanbot",split)]=stats.get(("leanbot",split),0)+1
    # ---- plate crops (positives only)
    if l["plate"]:
        x1,y1,x2,y2=l["leanbot"]; S=max(x2-x1,y2-y1)
        cfgs=[(0.20,0,0),(0.35,0,0)] if split=="val" else [(0.15,0,0),(0.25,0,0),(0.40,0,0)]+[(random.uniform(0.15,0.45),random.uniform(-.08,.08),random.uniform(-.08,.08)) for _ in range(3)]
        for k,(m,dx,dy) in enumerate(cfgs):
            cx,cy=(x1+x2)/2+dx*S,(y1+y2)/2+dy*S; r=S*(0.5+m)
            cx1,cy1,cx2,cy2=int(cx-r),int(cy-r),int(cx+r),int(cy+r)
            pad=cv2.copyMakeBorder(fr,300,300,300,300,cv2.BORDER_REPLICATE)
            crop=pad[cy1+300:cy2+300,cx1+300:cx2+300]; ch,cw=crop.shape[:2]
            pb=[l["plate"][0]-cx1,l["plate"][1]-cy1,l["plate"][2]-cx1,l["plate"][3]-cy1]
            stem=f"{n[:-4]}_c{k}"
            cv2.imwrite(f"{a.out}/plate/images/{split}/{stem}.jpg",crop,[cv2.IMWRITE_JPEG_QUALITY,92])
            open(f"{a.out}/plate/labels/{split}/{stem}.txt","w").write(yolo(pb,cw,ch))
            stats[("plate",split)]=stats.get(("plate",split),0)+1
print(stats)
json.dump({f"{k[0]}_{k[1]}":v for k,v in stats.items()},open(f"{a.out}/dataset_stats.json","w"),indent=1)
