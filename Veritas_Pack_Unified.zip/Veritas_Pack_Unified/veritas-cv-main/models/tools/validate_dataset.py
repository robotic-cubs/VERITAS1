"""Checks every image has exactly one valid label file; boxes inside the image, sane size. Usage: python3 validate_dataset.py <dataset_dir>"""
import sys, glob, os, cv2
root=sys.argv[1]; bad=0; tot=0
for ds in ("leanbot","plate"):
    for s in ("train","val"):
        imgs=sorted(glob.glob(f"{root}/{ds}/images/{s}/*.jpg")); n_box=0
        for p in imgs:
            tot+=1; lp=p.replace("/images/","/labels/")[:-4]+".txt"
            if not os.path.exists(lp): print("MISSING label",p); bad+=1; continue
            H,W=cv2.imread(p).shape[:2]
            for ln in open(lp).read().strip().splitlines():
                c,x,y,w,h=ln.split(); x,y,w,h=map(float,(x,y,w,h)); n_box+=1
                if c!="0" or not(0<w<=1 and 0<h<=1 and 0<=x-w/2+1e-4 and x+w/2<=1+1e-4 and 0<=y-h/2+1e-4 and y+h/2<=1+1e-4) or w*W<4 or h*H<4:
                    print("BAD box",lp,ln,W,H); bad+=1
        print(f"{ds}/{s}: {len(imgs)} images, {n_box} boxes")
print("problems:",bad,"of",tot,"images")
