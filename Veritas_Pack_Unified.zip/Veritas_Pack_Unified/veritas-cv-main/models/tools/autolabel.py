"""Phase 2 auto-labeller for videos 1-4 (top-down). Proposes a Leanbot box (red+blue body parts) and plate-card candidates.
Everything it proposes is REVIEWED by eye before it is used as a training label."""
import cv2, numpy as np
K=lambda n: np.ones((n,n),np.uint8)
def masks(fr):
    h=cv2.cvtColor(fr,cv2.COLOR_BGR2HSV); H,S,V=h[...,0],h[...,1],h[...,2]
    red=(((H<9)|(H>171))&(S>120)&(V>80)).astype(np.uint8)
    blue=((H>=100)&(H<=128)&(S>130)&(V>70)).astype(np.uint8)
    return red,blue,h
def leanbot(fr):
    red,blue,_=masks(fr)
    r=cv2.morphologyEx(red,cv2.MORPH_CLOSE,K(9))
    n,l,st,_=cv2.connectedComponentsWithStats(r)
    if n<=1: return None
    i=1+int(np.argmax(st[1:,4]))
    if st[i,4]<250: return None
    core=(l==i).astype(np.uint8)
    near=cv2.dilate(core,K(31))
    body=core|(blue&near)|(r&near)          # include blue servos and neighbouring red fragments
    ys,xs=np.where(body>0)
    return (int(xs.min()),int(ys.min()),int(xs.max()),int(ys.max())), core
def body_axis(fr):
    red,blue,_=masks(fr); r=cv2.morphologyEx(red,cv2.MORPH_CLOSE,K(9))
    n,l,st,_=cv2.connectedComponentsWithStats(r)
    i=1+int(np.argmax(st[1:,4])); core=(l==i).astype(np.uint8)
    body=core|(blue&cv2.dilate(core,K(31)))
    ys,xs=np.where(body>0); pts=np.column_stack([xs,ys]).astype(np.float32); pts-=pts.mean(0)
    w,v=np.linalg.eigh(np.cov(pts.T)); a=v[:,1]; return float(np.degrees(np.arctan2(a[1],a[0]))%180), float(w[1]/max(w[0],1e-6))
def plate_candidates(fr, box):
    """Cream/beige strip (plate card) behind/beside the robot: hue 3-30, sat 25-115, bright, elongated (L/s 2.6-8), touching the body."""
    x1,y1,x2,y2=box; H_,W_=fr.shape[:2]; pad=24
    X1,Y1,X2,Y2=max(x1-pad,0),max(y1-pad,0),min(x2+pad,W_),min(y2+pad,H_)
    roi=fr[Y1:Y2,X1:X2]; h=cv2.cvtColor(roi,cv2.COLOR_BGR2HSV)
    beige=(h[...,0]>=0)&(h[...,0]<=50)&(h[...,1]>=14)&(h[...,1]<=130)&(h[...,2]>=122)
    neutral=(h[...,1]<40)&(h[...,2]>=150)
    m=(beige|neutral).astype(np.uint8)
    m=cv2.morphologyEx(m,cv2.MORPH_CLOSE,K(3)); m=cv2.morphologyEx(m,cv2.MORPH_OPEN,K(2))
    red,blue,_=masks(roi); body=cv2.dilate(cv2.morphologyEx(red|blue,cv2.MORPH_CLOSE,K(5)),K(9))
    n,l,st,_=cv2.connectedComponentsWithStats(m); out=[]
    for i in range(1,n):
        x,y,w,hh,a=st[i]
        if a<110 or a>1500: continue
        cnt=np.column_stack(np.where(l==i))[:,::-1].astype(np.float32)
        (cx,cy),(rw,rh),ang=cv2.minAreaRect(cnt); L,sh=max(rw,rh),max(1.0,min(rw,rh))
        if not (2.6<=L/sh<=8 and 20<=L<=62 and 5<=sh<=17): continue
        if a/(L*sh)<0.6: continue
        bw,bh=x2-x1,y2-y1; cxm,cym=X1+x+w/2,Y1+y+hh/2
        if w>=hh:   # horizontal card: spans the robot's width, sits at its top/bottom end
            if not (0.72*bw<=w<=1.3*bw and bh>=0.95*bw): continue
            if y1+0.3*bh<cym<y2-0.3*bh: continue
        else:       # vertical card: spans the robot's height, sits at its left/right end
            if not (0.72*bh<=hh<=1.3*bh and bw>=0.95*bh): continue
            if x1+0.3*bw<cxm<x2-0.3*bw: continue
        touch=int((body[max(y-2,0):y+hh+2,max(x-2,0):x+w+2]>0).sum())
        pass  # adjacency not required: dark wheels/servos can separate the card from the red body
        out.append(dict(box=[int(X1+x),int(Y1+y),int(X1+x+w),int(Y1+y+hh)],area=int(a),ar=round(float(L/sh),2),touch=int(touch)))
    return sorted(out,key=lambda d:-d["touch"])
