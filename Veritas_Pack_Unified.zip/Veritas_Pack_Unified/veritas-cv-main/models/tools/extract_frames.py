"""Phase 1: sample frames from every video, tag them, split into clean/ (trainable) and overlay/ (old-model boxes burned in).
Usage: python3 -I tools/extract_frames.py"""
import cv2, numpy as np, os, csv, glob
OUT="work/frames"; os.makedirs(OUT+"/clean",exist_ok=True); os.makedirs(OUT+"/overlay",exist_ok=True)
TEAL_LIMIT=150      # >150 teal pixels => burned-in "Leanbot" boxes/labels from the old model
def teal_px(fr):
    h=cv2.cvtColor(fr,cv2.COLOR_BGR2HSV)
    return int(((h[...,0]>=78)&(h[...,0]<=92)&(h[...,1]>95)&(h[...,2]>80)).sum())   # tuned on video14 frames 378/309 (overlay) vs 165/840 (clean)
def red_blob(fr):
    h=cv2.cvtColor(fr,cv2.COLOR_BGR2HSV)
    m=(((h[...,0]<8)|(h[...,0]>172))&(h[...,1]>130)&(h[...,2]>90)).astype(np.uint8)
    m=cv2.morphologyEx(m,cv2.MORPH_CLOSE,np.ones((7,7),np.uint8))
    n,l,st,_=cv2.connectedComponentsWithStats(m)
    return int(st[1:,4].max()) if n>1 else 0
rows=[]
for p in sorted(glob.glob("videos/video*.mp4"), key=lambda s:int(os.path.basename(s)[5:-4])):
    vid=os.path.basename(p)[:-4]; num=int(vid[5:])
    step=15 if num<=4 else 3
    c=cv2.VideoCapture(p); fps=c.get(5) or 30; i=0; prev=None; last_kept=-999; kept=0
    while True:
        ok,fr=c.read()
        if not ok: break
        if i%step==0:
            small=cv2.resize(cv2.cvtColor(fr,cv2.COLOR_BGR2GRAY),(64,36)).astype(np.float32)
            diff=999 if prev is None else float(np.abs(small-prev).mean())
            if diff>3.0 or i-last_kept>=45:
                t=teal_px(fr); blur=float(cv2.Laplacian(cv2.cvtColor(fr,cv2.COLOR_BGR2GRAY),cv2.CV_64F).var())
                grp="overlay" if t>TEAL_LIMIT else "clean"
                name=f"{vid}_f{i:05d}.jpg"
                cv2.imwrite(f"{OUT}/{grp}/{name}",fr,[cv2.IMWRITE_JPEG_QUALITY,95])
                rows.append(dict(file=name,group=grp,video=vid,frame=i,time_s=round(i/fps,2),w=fr.shape[1],h=fr.shape[0],teal_px=t,red_blob=red_blob(fr),blur=round(blur,1)))
                prev=small; last_kept=i; kept+=1
        i+=1
    print(vid,"kept",kept)
with open("work/frames/manifest.csv","w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
import collections
cnt=collections.Counter((r["video"],r["group"]) for r in rows)
print("TOTAL",len(rows)); [print(k,v) for k,v in sorted(cnt.items(),key=lambda x:(int(x[0][0][5:]),x[0][1]))]
