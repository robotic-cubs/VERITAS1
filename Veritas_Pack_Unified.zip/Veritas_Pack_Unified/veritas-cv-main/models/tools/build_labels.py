"""Combine auto robot boxes + EYE-VERIFIED plate boxes (+ propagation while the robot is stationary) -> work/labels.json"""
import json, cv2, numpy as np
res=json.load(open("work/auto.json")); cand=json.load(open("work/cand_list.json"))
ACCEPT=[6,7,8,9,10,11,12,13,14,15,16,17,19,24,25,26,27,28,29,30,31,33,34,35,36]   # indices into cand_list.json, chosen from rev_cand_0.png
def pick_plate(n):
    b=res[n]["box"]; bw,bh=b[2]-b[0],b[3]-b[1]; best=None
    for p in res[n]["plates"]:
        x1,y1,x2,y2=p["box"]; w,h=x2-x1,y2-y1
        if (w>=h)==(bw<=bh*1.0+1): best=p["box"] if best is None else best
    return best or res[n]["plates"][0]["box"]
def iou(a,b):
    ix=max(0,min(a[2],b[2])-max(a[0],b[0])); iy=max(0,min(a[3],b[3])-max(a[1],b[1])); i=ix*iy
    u=(a[2]-a[0])*(a[3]-a[1])+(b[2]-b[0])*(b[3]-b[1])-i; return i/u if u else 0
ver={cand[i]:pick_plate(cand[i]) for i in ACCEPT}
lab={}
for n,v in res.items():
    lab[n]=dict(body=v["box"],plate=None,status="unknown")
for n,p in ver.items(): lab[n].update(plate=p,status="verified")
prop=[]
for n in lab:
    if lab[n]["status"]=="verified": continue
    vid=n.split("_")[0]
    for m,p in ver.items():
        if m.split("_")[0]!=vid: continue
        if iou(lab[n]["body"],lab[m]["body"])>0.88:
            fr=cv2.imread("work/f14/"+n); x1,y1,x2,y2=p; reg=fr[y1:y2,x1:x2]
            v=cv2.cvtColor(reg,cv2.COLOR_BGR2HSV)[...,2].mean()
            if v>115: lab[n].update(plate=p,status="propagated"); prop.append(n); break
def union(a,b,m=3):
    return [min(a[0],b[0])-m,min(a[1],b[1])-m,max(a[2],b[2])+m,max(a[3],b[3])+m]
for n,l in lab.items():
    l["leanbot"]=union(l["body"],l["plate"]) if l["plate"] else [l["body"][0]-3,l["body"][1]-3,l["body"][2]+3,l["body"][3]+3]
json.dump(lab,open("work/labels.json","w"))
json.dump(sorted(prop),open("work/propagated.json","w"))
import collections; print(collections.Counter(l["status"] for l in lab.values()))
