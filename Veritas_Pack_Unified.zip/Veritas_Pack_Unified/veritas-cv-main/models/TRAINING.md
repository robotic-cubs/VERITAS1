# VERITAS model training (two-stage)

| Stage | What it finds | Input | Data | Config |
|---|---|---|---|---|
| 1 `veritas_leanbot.pt` | the red Leanbot | full camera frame (imgsz 960) | `dataset/leanbot`: 235 train / 119 val frames | `leanbot.yaml` |
| 2 `veritas_plate.pt` | the plate card | crop of the Leanbot box (imgsz 320) | `dataset/plate`: 156 train / 24 val crops (26 / 12 source frames) | `plate.yaml` |

**Source video:** only `video1-4.mp4`. Split is by video: train = video 1, 2, 3, val = video 4 (never seen in training).
**Labels:** Leanbot box = automatic (red + blue body colour) and checked on sample sheets. Plate box = found automatically, then every box checked by eye; 13 more were carried over while the robot stood still (also checked).
Frames where the plate is hidden or blurred were **not** used as "no plate" examples in stage 2.

## Run
```
cd veritas-cv-main
pip install -r requirements.txt            # or just: pip install ultralytics
python train_veritas.py --stage both       # ~minutes on a GPU, slow on CPU. Add --device 0 for GPU.
python evaluate_veritas.py --stage leanbot
python evaluate_veritas.py --stage plate
```
Google Colab: upload the `veritas-cv-main` folder, `!pip install ultralytics`, then run the same commands.
Outputs land in this folder: `veritas_leanbot.pt`, `veritas_plate.pt`, `.onnx` exports, `train_*_metrics.json`, `eval_*.json`, `runs/`.

## Honest limits
* Plate stage has very little data (26 training frames, 12 validation frames, mostly video 2 and 4). Expect it to be fragile with new angles; add more labelled frames from new clips and re-run.
* The plate text is ~2 px tall in videos 1-4, so **OCR is not trained here**. It is handled separately (see the bridge) and results are only shown as confirmed when strictly validated.
* `tools/` holds the scripts that made the dataset (`extract_frames.py`, `autolabel.py`, `build_labels.py`, `build_dataset.py`, `validate_dataset.py`).
