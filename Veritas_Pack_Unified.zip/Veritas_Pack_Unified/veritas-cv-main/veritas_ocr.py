"""VERITAS plate reading with strict confirmation rules.

read_plate(crop)  -> one reading: {"text", "raw", "conf", "valid"}            (single image, never 'confirmed' on its own)
PlateVoter        -> per-vehicle voting over several frames:  status = "confirmed" | "unconfirmed" | "unread"

A plate is only 'confirmed' when ALL are true:
  1. the text matches the plate format (default 3 letters + 3-4 digits, env PLATE_REGEX),
  2. at least MIN_VOTES readings in the recent window agree on exactly the same text,
  3. those readings are confident (mean confidence >= MIN_CONF),
  4. the winning text has a clear majority of the valid readings (no near-tie with another plate).
Anything else is shown as 'unconfirmed' (best guess, marked with ?) or 'unread'. Never a bare guess.

OCR engine: EasyOCR if installed (best), otherwise Tesseract via pytesseract (needs the Tesseract program installed), otherwise none (-> 'unread')."""
import os, re, threading
from collections import Counter, deque
import cv2, numpy as np

PLATE_REGEX = re.compile(os.getenv("PLATE_REGEX", r"^[A-Z]{3} ?[0-9]{3,4}$"))
MIN_VOTES = int(os.getenv("OCR_MIN_VOTES", "3"))
MIN_CONF = float(os.getenv("OCR_MIN_CONF", "0.60"))
WINDOW = int(os.getenv("OCR_WINDOW", "10"))
_LET2DIG = {"O": "0", "Q": "0", "D": "0", "I": "1", "L": "1", "Z": "2", "S": "5", "G": "6", "B": "8"}
_DIG2LET = {"0": "O", "1": "I", "2": "Z", "5": "S", "6": "G", "8": "B"}
_engine = None
_loading = False
_lock = threading.Lock()


def engine():
    """'easyocr' | 'tesseract' | None  (cached). BLOCKS while EasyOCR loads (minutes the first time: it downloads its models),
    so a live program must call warm_up() instead and read engine_state() - never call this from the video loop."""
    global _engine
    if _engine is not None:
        return _engine or None
    with _lock:                                   # two threads must never build two EasyOCR readers
        if _engine is not None:
            return _engine or None
        try:
            import easyocr
            try:                                  # EasyOCR/PyTorch would otherwise grab EVERY core and starve the video
                import torch
                torch.set_num_threads(int(os.getenv("OCR_THREADS", "0") or 0) or max(1, (os.cpu_count() or 2) // 2))
            except Exception:
                pass
            globals()["_reader"] = easyocr.Reader(["en"], gpu=False, verbose=False); _engine = "easyocr"
        except Exception:
            try:
                import pytesseract; pytesseract.get_tesseract_version(); _engine = "tesseract"
            except Exception:
                _engine = ""
    return _engine or None


def engine_state():
    """Never blocks. 'idle' (not requested yet) | 'loading' | 'ready' | 'none' (no OCR engine installed)."""
    if _engine is None:
        return "loading" if _loading else "idle"
    return "ready" if _engine else "none"


def warm_up():
    """Start loading the OCR engine in a background thread and return immediately."""
    global _loading
    if _engine is not None or _loading:
        return
    _loading = True

    def run():
        global _loading
        try:
            engine()
        finally:
            _loading = False
    threading.Thread(target=run, daemon=True, name="ocr-warmup").start()


def _card(crop):
    """Trim to the bright plate card (drops dark borders / robot body that confuse OCR). Falls back to the whole crop."""
    g = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY); hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    thr = max(110, int(np.percentile(g, 60)))
    m = ((g >= thr) & (hsv[..., 1] < 90)).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    n, l, st, _ = cv2.connectedComponentsWithStats(m)
    if n <= 1: return crop
    i = 1 + int(np.argmax(st[1:, 4])); x, y, w, h, a = st[i]
    if a < 0.25 * crop.shape[0] * crop.shape[1]: return crop
    mx, my = max(2, int(0.05 * w)), max(2, int(0.12 * h))
    t = crop[y + my:y + h - my, x + mx:x + w - mx]
    return t if t.size and min(t.shape[:2]) >= 4 else crop


def _variants(crop):
    crop = _card(crop)
    g = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY) if crop.ndim == 3 else crop
    h = g.shape[0]; f = max(2.0, 80.0 / max(h, 1))                       # OCR works best with ~80px tall text lines
    g = cv2.resize(g, None, fx=f, fy=f, interpolation=cv2.INTER_CUBIC)
    g = cv2.copyMakeBorder(g, 16, 16, 16, 16, cv2.BORDER_REPLICATE)
    cl = cv2.createCLAHE(2.0, (4, 4)).apply(g)
    _, ot = cv2.threshold(cv2.GaussianBlur(cl, (3, 3), 0), 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return [g, cl, ot]


def _ocr_lines(img):
    """-> list of (text, conf 0..1) for one preprocessed image"""
    e = engine()
    if e == "easyocr":
        parts = _reader.readtext(img, allowlist="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", detail=1, paragraph=False)
        if not parts: return []
        parts = sorted(parts, key=lambda p: p[0][0][0])
        return [(" ".join(p[1] for p in parts), float(np.mean([p[2] for p in parts])))]
    if e == "tesseract":
        import pytesseract
        out = []
        for psm in (7, 8, 13):
            d = pytesseract.image_to_data(img, config=f"--psm {psm} -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", output_type=pytesseract.Output.DICT)
            words = [(w, float(c) / 100) for w, c in zip(d["text"], d["conf"]) if w.strip() and float(c) >= 0]
            if words: out.append((" ".join(w for w, _ in words), float(np.mean([c for _, c in words]))))
        return out
    return []


def normalise(raw):
    """'pxr2418' / 'PXR-2418' / 'PXR 24I8' -> 'PXR 2418' using the letter/digit layout (3 letters then digits). Returns (text, changed)."""
    s = re.sub(r"[^A-Z0-9]", "", raw.upper())
    if len(s) not in (6, 7): return raw.upper().strip(), False
    out = [(_DIG2LET.get(c, c) if c.isdigit() else c) for c in s[:3]] + [(_LET2DIG.get(c, c) if c.isalpha() else c) for c in s[3:]]
    t = "".join(out)
    return f"{t[:3]} {t[3:]}", t != s


def read_plate(crop):
    """One image of the plate card -> {"text", "raw", "conf", "valid", "engine"}.
    conf = how much the independent reads agree (several preprocessing variants / Tesseract modes), blended with the engine's own
    confidence when it gives one. valid=True only means 'right shape', NOT 'confirmed' (that needs PlateVoter)."""
    empty = dict(text="", raw="", conf=0.0, valid=False, engine=engine())
    if crop is None or crop.size == 0 or engine() is None: return empty
    reads = []
    for v in _variants(crop):
        for raw, conf in _ocr_lines(v):
            text, _ = normalise(raw)
            reads.append((text if PLATE_REGEX.match(text) else "", raw, conf))
    if not reads: return empty
    n = len(reads); votes = Counter(t for t, _, _ in reads if t)
    if not votes: return dict(empty, raw=reads[0][1])
    text, k = votes.most_common(1)[0]
    own = float(np.mean([c for t, _, c in reads if t == text]))
    agree = k / n
    conf = agree if own <= 0.01 else 0.5 * agree + 0.5 * own           # Tesseract often reports 0 -> rely on agreement alone
    if engine() == "tesseract": conf = min(conf, 0.95)                  # Tesseract is never fully trusted on tiny text
    return dict(text=text, raw=next(r for t, r, _ in reads if t == text), conf=round(conf, 3), valid=True, engine=engine())


class PlateVoter:
    """Collect readings for ONE vehicle (track) and decide confirmed / unconfirmed / unread."""
    def __init__(self, window=WINDOW, min_votes=MIN_VOTES, min_conf=MIN_CONF):
        self.r = deque(maxlen=window); self.min_votes, self.min_conf = min_votes, min_conf
        self._lk = threading.Lock()      # the OCR worker adds while the video thread reads

    def add(self, reading):
        with self._lk:
            self.r.append((reading["text"], reading["conf"]) if reading.get("valid") else ("", 0.0))
        return self.result()

    def result(self):
        with self._lk:
            snap = list(self.r)
        valid = [(t, c) for t, c in snap if t]
        if not valid: return dict(status="unread", text="", conf=0.0, votes=0)
        votes = Counter(t for t, _ in valid); (top, n), *rest = votes.most_common()
        conf = float(np.mean([c for t, c in valid if t == top]))
        clear = (not rest) or n >= 2 * rest[0][1]
        if n >= self.min_votes and conf >= self.min_conf and clear:
            return dict(status="confirmed", text=top, conf=round(conf, 3), votes=n)
        return dict(status="unconfirmed", text=top, conf=round(conf, 3), votes=n)
