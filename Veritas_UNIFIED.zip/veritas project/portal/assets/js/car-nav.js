/* VERITAS "car" navigation indicator.
   The green highlight behind the current menu item no longer jumps: it drives. A small car pulls out of the old item,
   accelerates, brakes and parks on the new one while the green box stretches behind it like a light trail.

   CarNav.nav(el)      top menu (boxes + car on the bottom edge; also works as a vertical mobile dropdown)
   CarNav.rail(el)     home page "on this page" menu (a road with stops on wide screens, chips on small screens)
   CarNav.sidebar(el)  dashboard side menu (car drives up and down the right edge)
   Each returns { to(el) -> Promise, place(el), hide(), refresh() }.
   Purely visual: if this file is missing, the old static highlight is used. Respects prefers-reduced-motion. */
const CarNav = (() => {
  "use strict";
  const reduce = () => !!(window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches);
  const E1 = "cubic-bezier(.45,0,.2,1)"; // pull away, then brake
  const E2 = "cubic-bezier(.3,0,.2,1)"; // the trail catches up

  const SVG =
    '<svg viewBox="0 0 28 14" aria-hidden="true">' +
    '<defs><linearGradient id="cn-beam" x1="0" x2="1"><stop offset="0" stop-color="#ffe27a" stop-opacity=".75"/><stop offset="1" stop-color="#ffe27a" stop-opacity="0"/></linearGradient></defs>' +
    '<polygon class="beam" points="26,3.2 42,-1 42,15 26,10.8" fill="url(#cn-beam)"/>' +
    '<rect x="5" y="0" width="5" height="2.6" rx="1" fill="#0b0f12"/><rect x="5" y="11.4" width="5" height="2.6" rx="1" fill="#0b0f12"/>' +
    '<rect x="18" y="0" width="5" height="2.6" rx="1" fill="#0b0f12"/><rect x="18" y="11.4" width="5" height="2.6" rx="1" fill="#0b0f12"/>' +
    '<rect x="1" y="1.8" width="26" height="10.4" rx="4.6" fill="#f4fff9" stroke="rgba(0,0,0,.4)" stroke-width=".6"/>' +
    '<path d="M17.4 3.4 21.4 4.6v4.8l-4 1.2z" fill="#16323b"/><path d="M6.6 4.6 9.6 3.8v6.4l-3-.8z" fill="#16323b"/>' +
    '<rect x="9.6" y="3.4" width="7.8" height="7.2" rx="1.4" fill="#d8f3e4"/>' +
    '<circle cx="26" cy="4" r="1.3" fill="#ffd23f"/><circle cx="26" cy="10" r="1.3" fill="#ffd23f"/>' +
    '<circle cx="1.8" cy="4" r="1" fill="#ff4757"/><circle cx="1.8" cy="10" r="1" fill="#ff4757"/></svg>';

  const CSS =
    ".car-ind,.car-car{position:absolute;left:0;top:0;pointer-events:none;opacity:0;transition:opacity .25s}" +
    ".car-ind.show,.car-car.show{opacity:1}" +
    ".car-ind{z-index:0;border-radius:11px}" +
    ".car-ind.box{background:linear-gradient(90deg,rgba(47,227,138,.28),rgba(47,227,138,.07));box-shadow:0 0 18px rgba(47,227,138,.16),inset 0 0 0 1px rgba(47,227,138,.42)}" +
    ".car-ind.full{left:3px;right:3px;border-radius:10px}" +
    ".car-ind.sb{background:rgba(76,195,138,.13);box-shadow:inset 3px 0 0 #2fe38a,0 0 14px rgba(47,227,138,.12)}" +
    ".car-ind.line{left:auto;right:19.5px;width:2px;border-radius:2px;background:linear-gradient(#2fe38a,#2fe38a);box-shadow:0 0 10px rgba(47,227,138,.8)}" +
    ".car-car{z-index:3;width:26px;height:13px}" +
    ".car-car svg{display:block;width:100%;height:100%;overflow:visible;filter:drop-shadow(0 2px 3px rgba(0,0,0,.6))}" +
    ".car-car .beam{opacity:0;transition:opacity .2s}.car-car.go .beam{opacity:1}" +
    /* the old static highlight steps aside once the car is running */
    ".nav.has-car a{z-index:1}.nav.has-car a[aria-current=\"page\"]:not(.acct){background:none;box-shadow:none}" +
    "aside nav.has-car{position:relative}aside nav.has-car a{z-index:1}" +
    "aside nav.has-car a.on{background:none;border-left-color:transparent}aside nav.has-car a.on::before{display:none}" +
    ".hm-jump.has-car a{position:relative;z-index:1}" +
    "@media (max-width:1379.98px){.hm-jump.has-car{position:relative}.hm-jump.has-car a[aria-current=\"true\"]{background:transparent;border-color:transparent}}" +
    "@media (min-width:1380px){.hm-jump.has-car a{flex-direction:row}.hm-jump.has-car a[aria-current=\"true\"]::after{background:transparent;box-shadow:none}" +
    ".hm-jump.has-car::before{content:\"\";position:absolute;right:19.5px;top:14px;bottom:14px;width:2px;background:repeating-linear-gradient(to bottom,rgba(255,255,255,.2) 0 4px,transparent 4px 9px);pointer-events:none}}";

  let injected = false;
  function inject() {
    if (injected) return;
    injected = true;
    const s = document.createElement("style");
    s.setAttribute("data-car-nav", "");
    s.textContent = CSS;
    document.head.appendChild(s);
  }

  const px = (n) => Math.round(n * 100) / 100 + "px";
  const num = (v) => parseFloat(v) || 0;
  const wrap = (d) => ((((d + 180) % 360) + 360) % 360) - 180;

  /* cfg.resolve(el) -> null (nothing to show) or
     { ax: "xy"|"y", cls, x, y, w, h, cx, cy, carRight } in the host's own coordinates */
  function create(host, cfg) {
    inject();
    host.classList.add("has-car");
    const ind = document.createElement("span");
    const car = document.createElement("span");
    ind.setAttribute("aria-hidden", "true");
    car.setAttribute("aria-hidden", "true");
    car.innerHTML = SVG;
    host.insertBefore(car, host.firstChild);
    host.insertBefore(ind, host.firstChild);

    let st = null, target = null, shown = false, going = false, anims = [], token = 0;

    function classes(t) {
      ind.className = "car-ind " + t.cls + (shown ? " show" : "");
      car.className = "car-car" + (shown ? " show" : "") + (going ? " go" : "");
      if (t.ax === "y") {
        car.style.left = "auto";
        car.style.right = t.carRight - 13 + "px";
      } else {
        car.style.left = "-13px";
        car.style.right = "auto";
      }
      car.style.marginTop = "-6.5px";
    }
    function paint(t, a) {
      if (t.ax === "y") {
        ind.style.translate = "0px " + px(t.y);
        ind.style.width = "";
        car.style.translate = "0px " + px(t.cy);
      } else {
        ind.style.translate = px(t.x) + " " + px(t.y);
        ind.style.width = px(t.w);
        car.style.translate = px(t.cx) + " " + px(t.cy);
      }
      ind.style.height = px(t.h);
      car.style.rotate = a + "deg";
      classes(t);
    }
    function tr(el) {
      const v = getComputedStyle(el).translate;
      if (!v || v === "none") return [0, 0];
      const p = v.split(/\s+/);
      return [num(p[0]), num(p[1])];
    }
    function snap() {
      const cs = getComputedStyle(ind), [x, y] = tr(ind), [cx, cy] = tr(car);
      return { ax: st.ax, x, y, w: num(cs.width), h: num(cs.height), cx, cy, a: num(getComputedStyle(car).rotate) };
    }
    function stop() {
      anims.forEach((a) => { try { a.cancel(); } catch (e) {} });
      anims = [];
      going = false;
    }
    function defaultAngle(t) { return t.ax === "y" ? 90 : 0; }

    function place(el) {
      const t = el && cfg.resolve(el);
      if (!t) return hide();
      target = el;
      stop();
      shown = true;
      const a = st ? st.a : defaultAngle(t);
      paint(t, a);
      st = Object.assign({}, t, { a });
    }
    function hide() {
      stop();
      shown = false;
      ind.classList.remove("show");
      car.classList.remove("show", "go");
    }
    function to(el) {
      const t = el && cfg.resolve(el);
      if (!t) { hide(); return Promise.resolve(); }
      target = el;
      if (!st || st.ax !== t.ax || reduce()) { place(el); return Promise.resolve(); }
      const s = anims.length ? snap() : st;
      stop();
      const fromHidden = !shown;
      shown = true;
      const dx = t.cx - s.cx, dy = t.cy - s.cy, dist = Math.hypot(dx, dy);
      let dir = s.a;
      if (t.ax === "y") dir = dy >= 0 ? 90 : -90;
      else dir = Math.abs(dx) >= Math.abs(dy) ? (dx >= 0 ? 0 : 180) : dy >= 0 ? 90 : -90;
      if (dist < 2) dir = s.a;
      const a1 = s.a + wrap(dir - s.a);
      if (dist < 2 && Math.abs(t.h - s.h) < 1 && Math.abs(t.w - s.w) < 1) {
        paint(t, a1);
        st = Object.assign({}, t, { a: a1 });
        return Promise.resolve();
      }
      const T = Math.max(480, Math.min(850, 420 + dist * 0.55));
      const carT = T * 0.62;
      going = true;
      paint(t, a1); // final state is set first; the animations below only describe the journey
      st = Object.assign({}, t, { a: a1 });
      const my = ++token;

      const y0 = Math.min(s.y, t.y), y1 = Math.max(s.y + s.h, t.y + t.h);
      let kf;
      if (t.ax === "y") {
        kf = [
          { translate: "0px " + px(s.y), height: px(s.h), easing: E1 },
          { translate: "0px " + px(y0), height: px(y1 - y0), offset: 0.62, easing: E2 },
          { translate: "0px " + px(t.y), height: px(t.h) },
        ];
      } else {
        const x0 = Math.min(s.x, t.x), x1 = Math.max(s.x + s.w, t.x + t.w);
        kf = [
          { translate: px(s.x) + " " + px(s.y), width: px(s.w), height: px(s.h), easing: E1 },
          { translate: px(x0) + " " + px(y0), width: px(x1 - x0), height: px(y1 - y0), offset: 0.62, easing: E2 },
          { translate: px(t.x) + " " + px(t.y), width: px(t.w), height: px(t.h) },
        ];
      }
      const cFrom = (t.ax === "y" ? "0px " : px(s.cx) + " ") + px(s.cy);
      const cTo = (t.ax === "y" ? "0px " : px(t.cx) + " ") + px(t.cy);
      anims = [
        ind.animate(kf, { duration: T }),
        car.animate([{ translate: cFrom }, { translate: cTo }], { duration: carT, easing: E1 }),
        car.animate([{ rotate: s.a + "deg" }, { rotate: a1 + "deg" }], { duration: Math.min(240, carT), easing: "ease-out" }),
      ];
      if (fromHidden) ind.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 200 });
      return Promise.all(anims.map((a) => a.finished)).then(
        () => { if (token === my) { anims = []; going = false; car.classList.remove("go"); } },
        () => {},
      );
    }
    function refresh(force) {
      if (!target || (anims.length && !force)) return;
      const t = cfg.resolve(target);
      if (!t) { hide(); return; }
      stop();
      shown = true;
      const a = st ? st.a : defaultAngle(t);
      paint(t, a);
      st = Object.assign({}, t, { a });
    }

    let rt = 0;
    addEventListener("resize", () => { clearTimeout(rt); rt = setTimeout(() => refresh(true), 120); });
    addEventListener("load", () => refresh());
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => refresh());
    return { to, place, hide, refresh };
  }

  const boxRect = (t, cls) => {
    const w = t.offsetWidth, h = t.offsetHeight;
    if (!w || !h) return null;
    return { ax: "xy", cls: cls || "box", x: t.offsetLeft, y: t.offsetTop, w, h, cx: t.offsetLeft + w / 2, cy: t.offsetTop + h };
  };

  /* top menu: green box + car on its bottom edge */
  function nav(el) {
    return create(el, { resolve: (t) => boxRect(t) });
  }

  /* home page "on this page" menu */
  function rail(el) {
    const wide = () => matchMedia("(min-width: 1380px)").matches;
    const api = create(el, {
      resolve(t) {
        if (!wide()) return boxRect(t);
        if (!t.offsetWidth) return null;
        const cy = t.offsetTop + t.offsetHeight / 2;
        return { ax: "y", cls: "line", y: cy - 1, h: 2, w: 0, cx: 0, cy, carRight: 20.5 };
      },
    });
    if (matchMedia("(min-width: 1380px)").addEventListener)
      matchMedia("(min-width: 1380px)").addEventListener("change", () => api.refresh(true));
    return api;
  }

  /* dashboard side menu: car drives up and down the right edge */
  function sidebar(el) {
    return create(el, {
      resolve(t) {
        const h = t.offsetHeight;
        if (!h || t.hidden) return null;
        return { ax: "y", cls: "box full sb", y: t.offsetTop, h, w: 0, cx: 0, cy: t.offsetTop + h / 2, carRight: 11 };
      },
    });
  }

  return { nav, rail, sidebar };
})();
