/* VERITAS UI shell for the public portal (and portal-admin.html). It reproduces admin.html's navigation exactly:
   glass icon rail that expands on hover/focus, "pin" toggle (same localStorage key as admin.html, so the choice follows
   the user between both sides), and the mobile top bar with slide-in drawer. Markup and class names are admin.html's. */
const VUI = (() => {
  const $ = (s, r) => (r || document).querySelector(s);
  const esc = (s) =>
    String(s ?? "").replace(
      /[&<>"']/g,
      (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
    );
  const S = (p) => `<svg viewBox="0 0 24 24">${p}</svg>`;
  const ICON = {
    home: S('<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>'),
    grid: S(
      '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    ),
    car: S(
      '<path d="M3 17v-4l2-5h14l2 5v4M3 17h18M7 17v2M17 17v2"/><circle cx="7.5" cy="13" r=".7"/><circle cx="16.5" cy="13" r=".7"/>',
    ),
    login: S('<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l5-5-5-5M15 12H3"/>'),
    userplus: S('<circle cx="9" cy="8" r="4"/><path d="M2 21c0-4 3-7 7-7s7 3 7 7M19 8v6M16 11h6"/>'),
    key: S('<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3"/>'),
    warn: S(
      '<path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
    ),
    card: S('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18"/>'),
    user: S('<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-7 8-7s8 3 8 7"/>'),
    check: S('<circle cx="12" cy="12" r="9"/><path d="M8.5 12.5l2.5 2.5 4.5-5"/>'),
    chat: S('<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>'),
    coin: S('<path d="M12 2v20M17 6H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>'),
    dash: S('<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>'),
    out: S('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>'),
    help: S(
      '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.2a2.6 2.6 0 1 1 3.6 2.4c-.7.4-1.1 1-1.1 1.7M12 17h.01"/>',
    ),
  };
  const PIN = '<svg viewBox="0 0 24 24"><path d="M9 4h6l-1 6 3 3v2H7v-2l3-3zM12 15v6"/></svg>';
  let NAV,
    PINNED = false,
    HOV = false,
    DRW = false,
    ht;
  const mob = () => matchMedia("(max-width:800px)").matches;

  function applyNav() {
    const m = mob();
    document.body.classList.toggle("pin", PINNED && !m);
    document.body.classList.toggle("dr", DRW && m);
    NAV.classList.toggle("ex", m ? DRW : PINNED || HOV);
    if (CAR) CAR.refresh();
    const t = PINNED ? "Unpin sidebar" : "Pin sidebar open",
      p = $("#pin");
    if (p) {
      p.title = t;
      $("span", p).textContent = t;
      p.classList.toggle("on", PINNED);
    }
  }

  /** opts.nav: [{h:"SECTION"} | {k,href,label,icon,onclick?}], opts.active: key, opts.foot: html for the bottom status row */
  function shell(opts) {
    const logoSrc = opts.logo || "../assets/logos/VERITAS_LOGO.png";
    const items = opts.nav
      .map((i) =>
        i.h
          ? `<h4>${esc(i.h)}</h4>`
          : `<a href="${esc(i.href || "#")}" data-k="${esc(i.k || "")}" title="${esc(i.label)}"${i.hidden ? " hidden" : ""}${i.id ? ` id="${esc(i.id)}"` : ""}>${ICON[i.icon] || ""}<span>${esc(i.label)}${i.badge ? ` <em class="nbg" id="${esc(i.badge)}"></em>` : ""}</span></a>`,
      )
      .join("");
    document.body.insertAdjacentHTML(
      "afterbegin",
      `<div id="tb"><button id="ham" aria-label="Open menu"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button><img src="${esc(logoSrc)}" alt="VERITAS"></div><div id="bd"></div>` +
        `<aside id="nav" aria-label="Main navigation"><div class="ah"><div class="logo"><img src="${esc(logoSrc)}" alt="VERITAS Robotic Cubs"></div></div><nav>${items}</nav>` +
        `<button class="nb2" id="pin" title="Pin sidebar open">${PIN}<span>Pin sidebar open</span></button>` +
        `<div class="conn" id="conn">${opts.foot || '<span class="dot"></span><span>VERITAS</span>'}</div></aside>`,
    );
    NAV = $("#nav");
    try {
      PINNED = !!localStorage.getItem("veritas_nav_pinned");
    } catch (e) {}
    NAV.addEventListener("mouseenter", () => {
      if (!matchMedia("(hover:hover)").matches) return;
      clearTimeout(ht);
      ht = setTimeout(() => {
        HOV = true;
        applyNav();
      }, 120);
    });
    NAV.addEventListener("mouseleave", () => {
      clearTimeout(ht);
      HOV = false;
      applyNav();
    });
    NAV.addEventListener("focusin", () => {
      HOV = true;
      applyNav();
    });
    NAV.addEventListener("focusout", () => {
      HOV = false;
      applyNav();
    });
    $("#pin").onclick = () => {
      PINNED = !PINNED;
      try {
        localStorage.setItem("veritas_nav_pinned", PINNED ? "1" : "");
      } catch (e) {}
      applyNav();
    };
    $("#ham").onclick = () => {
      DRW = !DRW;
      applyNav();
    };
    $("#bd").onclick = () => {
      DRW = false;
      applyNav();
    };
    NAV.addEventListener("click", (e) => {
      if (e.target.closest("a") && DRW) {
        DRW = false;
        applyNav();
      }
    });
    addEventListener("resize", applyNav);
    applyNav();
    if (opts.active) setActive(opts.active);
    if (!$("main")) document.body.insertAdjacentHTML("beforeend", '<main id="main"></main>');
  }
  /* add navigation entries after login (used for the administrator links, which are only added once the server confirms the role) */
  function addNav(items, beforeHeading) {
    const nav = $("#nav nav"),
      before = [...nav.querySelectorAll("h4")].find((h) => h.textContent === beforeHeading);
    items.forEach((i) => {
      const t = document.createElement("div");
      t.innerHTML = i.h
        ? `<h4>${esc(i.h)}</h4>`
        : `<a href="${esc(i.href)}" data-k="${esc(i.k)}" title="${esc(i.label)}">${ICON[i.icon] || ""}<span>${esc(i.label)}</span></a>`;
      nav.insertBefore(t.firstElementChild, before || null);
    });
  }
  let CAR = null;
  function setActive(k) {
    document.querySelectorAll("#nav a[data-k]").forEach((a) => a.classList.toggle("on", a.dataset.k === k));
    /* the highlight is a car: it drives from the old menu item to the new one */
    if (typeof CarNav === "undefined" || !document.body.animate) return;
    if (!CAR) CAR = CarNav.sidebar($("#nav nav"));
    const a = $('#nav a.on[data-k]');
    if (a) CAR.to(a);
    else CAR.hide();
  }
  function conn(state, text) {
    const c = $("#conn");
    if (c) c.innerHTML = `<span class="dot ${state === "ok" ? "g" : ""}"></span><span>${esc(text)}</span>`;
  }

  /* tabs: the same ".tabs" buttons as admin.html, switching panels in place (no reload) with a short fade */
  function tabs(root, onChange) {
    const btns = [...root.querySelectorAll(".tabs button[data-tab]")],
      panes = [...root.querySelectorAll("[data-pane]")];
    const show = (k, push) => {
      btns.forEach((b) => {
        const on = b.dataset.tab === k;
        b.classList.toggle("on", on);
        b.setAttribute("aria-selected", on);
      });
      panes.forEach((p) => {
        const on = p.dataset.pane === k;
        p.hidden = !on;
        if (on) {
          p.classList.remove("fade");
          void p.offsetWidth;
          p.classList.add("fade");
        }
      });
      if (push) history.replaceState(null, "", "#" + k);
      if (onChange) onChange(k);
    };
    btns.forEach((b) => b.addEventListener("click", () => show(b.dataset.tab, true)));
    const h = location.hash.slice(1);
    show(btns.some((b) => b.dataset.tab === h) ? h : btns[0].dataset.tab, false);
    addEventListener("hashchange", () => {
      const k = location.hash.slice(1);
      if (btns.some((b) => b.dataset.tab === k)) show(k, false);
    });
    return { show };
  }

  /* accordion: expand/collapse with the same arrow indicator as admin.html's collapsible toggle (aria-expanded, ▾ / ▴) */
  function accordion(root) {
    root.querySelectorAll(".acc-item").forEach((it) => {
      const b = it.querySelector(".acc-q"),
        set = (open) => {
          it.classList.toggle("open", open);
          b.setAttribute("aria-expanded", String(open));
        };
      b.addEventListener("click", () => {
        const open = !it.classList.contains("open");
        if (root.dataset.single !== "false")
          root.querySelectorAll(".acc-item.open").forEach((o) => {
            if (o !== it) {
              o.classList.remove("open");
              o.querySelector(".acc-q").setAttribute("aria-expanded", "false");
            }
          });
        set(open);
      });
    });
  }
  /* same light markdown as admin.html's assistant: **bold**, `code`, line breaks (input must already be escaped) */
  const fmt = (t) =>
    esc(t)
      .replace(/\*\*(.+?)\*\*/g, "<b>$1</b>")
      .replace(/`([^`\n]+)`/g, "<code>$1</code>")
      .replace(/\n/g, "<br>");
  /* the navigation every public page shares */
  const publicNav = [
    { h: "PORTAL" },
    { k: "home", href: "index.html", label: "Home", icon: "home" },
    { k: "quick", href: "3-register.html", label: "Quick vehicle registration", icon: "car" },
    { h: "ACCOUNT" },
    { k: "login", href: "login.html", label: "Log in", icon: "login" },
    { k: "signup", href: "signup.html", label: "Create account", icon: "userplus" },
    { h: "HELP" },
    { k: "help", href: "#help", label: "Help assistant", icon: "help" },
  ];
  /* "System online" indicator in the rail footer, from the same health check 3-register.html always used */
  async function health() {
    conn("", "Checking system…");
    try {
      const r = await (await fetch((window.VERITAS_API_URL || "") + "?path=health")).json();
      conn(r.ok ? "ok" : "", r.ok ? "System online" : "System offline");
      return !!r.ok;
    } catch (e) {
      conn("", "System offline");
      return false;
    }
  }
  return { $, esc, ICON, shell, setActive, addNav, conn, tabs, accordion, fmt, publicNav, health };
})();
