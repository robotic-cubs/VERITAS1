/* VERITAS home page behaviour: reveal on scroll, "you are here" highlight in the page menu, and the glass light that follows the pointer.
   Purely visual. If this file fails to load the page still works (content is visible; links are normal anchors). */
(function () {
  "use strict";
  var reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  var rv = [].slice.call(document.querySelectorAll(".rv"));

  /* reveal blocks as they scroll into view */
  if (!("IntersectionObserver" in window) || reduce) {
    rv.forEach(function (e) { e.classList.add("in"); });
  } else {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); } });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });
    rv.forEach(function (e) { io.observe(e); });
    setTimeout(function () { rv.forEach(function (e) { e.classList.add("in"); }); }, 6000); // safety net: never leave content hidden
  }

  /* highlight the section being read in the page menu */
  var links = [].slice.call(document.querySelectorAll("#hm-jump a"));
  var map = {};
  links.forEach(function (a) { var id = a.getAttribute("href").slice(1), s = document.getElementById(id); if (s) map[id] = { a: a, s: s }; });
  /* the highlight is a car that drives along the menu to the section being read */
  var rail = (typeof CarNav !== "undefined" && links.length && document.body.animate) ? CarNav.rail(document.getElementById("hm-jump")) : null;
  var lock = 0, lastId = null;
  function setActive(id) {
    lastId = id;
    var hit = null;
    links.forEach(function (a) { if (a.getAttribute("href") === "#" + id) { a.setAttribute("aria-current", "true"); hit = a; } else a.removeAttribute("aria-current"); });
    if (rail && !lock) { if (hit) rail.to(hit); else rail.hide(); }
  }
  if (rail) links.forEach(function (a) {
    a.addEventListener("click", function () {
      /* clicked: drive straight to that stop and ignore the sections scrolled past on the way */
      clearTimeout(lock); rail.to(a); lock = setTimeout(function () { lock = 0; setActive(lastId); }, 1100);
    });
  });
  if ("IntersectionObserver" in window && links.length) {
    var seen = {};
    var so = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { seen[en.target.id] = en.isIntersecting ? en.intersectionRatio : 0; });
      var best = null, bv = 0;
      Object.keys(seen).forEach(function (k) { if (seen[k] > bv) { bv = seen[k]; best = k; } });
      if (best) setActive(best); else { links.forEach(function (a) { a.removeAttribute("aria-current"); }); if (rail && !lock) rail.hide(); }
    }, { rootMargin: "-30% 0px -45% 0px", threshold: [0, 0.1, 0.25, 0.5, 0.75, 1] });
    Object.keys(map).forEach(function (k) { so.observe(map[k].s); });
  }

  /* soft light that follows the pointer across glass panels */
  if (!reduce && window.matchMedia && matchMedia("(hover: hover)").matches) {
    var raf = 0, el = null, px = 0, py = 0;
    document.addEventListener("pointermove", function (e) {
      var t = e.target && e.target.closest ? e.target.closest(".hm-gl") : null;
      if (!t) return;
      el = t; px = e.clientX; py = e.clientY;
      if (!raf) raf = requestAnimationFrame(function () {
        raf = 0; var r = el.getBoundingClientRect();
        el.style.setProperty("--mx", px - r.left + "px"); el.style.setProperty("--my", py - r.top + "px");
      });
    }, { passive: true });
  }
})();
