"""VERITAS Phase 0 check. Run it on the camera PC (4-PHASE0-CHECK.bat).

It tests the path  camera PC -> Apps Script (Code.gs) -> Google Sheet -> back to the dashboard.
It writes only two clearly labelled test rows (camera_id PHASE0-TEST): one in Cameras, one in Detections.
Use  --no-write  to skip even those. It never touches Vehicles or Violations.
"""
import argparse, json, os, random, sys, time, uuid

import requests
from dotenv import load_dotenv

load_dotenv()
ap = argparse.ArgumentParser()
ap.add_argument("--no-write", action="store_true", help="read-only checks only")
args = ap.parse_args()

URL = os.getenv("BACKEND_URL", "").strip()
KEY = os.getenv("INGEST_KEY", "")
DEFAULT_KEY = "veritas-change-me"
levels = []


def rec(level, msg):
    levels.append(level)
    print(f"[{level}] {msg}")


def _json(r):
    try:
        return r.json()
    except Exception:
        head = r.text[:120].replace("\n", " ")
        raise RuntimeError(f"Reply was not JSON (HTTP {r.status_code}): {head!r}. "
                           "If this looks like a Google sign-in page, the web app is not deployed as 'Anyone'.")


def get(path):
    r = requests.get(URL, params={"path": path}, timeout=30)
    return _json(r)


def post(body):
    r = requests.post(URL, data=json.dumps(body), headers={"Content-Type": "text/plain;charset=utf-8"}, timeout=30)
    return _json(r)


def main():
    # 1. configuration
    if not URL:
        rec("FAIL", "BACKEND_URL is empty. Put the Apps Script /exec URL in Camera Bridge\\.env")
        return
    if "script.google.com" not in URL or not URL.endswith("/exec"):
        rec("WARN", "BACKEND_URL does not look like an Apps Script URL ending in /exec")
    if not KEY:
        rec("FAIL", "INGEST_KEY is empty in Camera Bridge\\.env")
    elif KEY == DEFAULT_KEY:
        rec("WARN", f"INGEST_KEY is still the default '{DEFAULT_KEY}'. Anyone who guesses it can write fake detections. "
                    "Change it in Code.gs AND .env, then redeploy.")
    else:
        rec("PASS", "INGEST_KEY is set and is not the default")

    # 2. reachability + read path
    try:
        h = get("health")
    except Exception as e:
        rec("FAIL", f"Cannot reach the Apps Script URL: {e}")
        return
    if h.get("ok"):
        rec("PASS", "health endpoint answered ok")
    else:
        rec("FAIL", f"health returned {h}")
        return
    try:
        allr = get("all")
        counts = {k: len(allr.get(k, [])) for k in ("vehicles", "detections", "violations", "cameras")}
        rec("PASS", f"read path works. Rows: {counts}")
        if counts["vehicles"] == 0:
            rec("WARN", "Vehicles tab is empty, so plates cannot be matched to registered robots yet")
        for c in allr.get("cameras", []):
            print(f"        camera {c.get('camera_id')}: {c.get('status')} (last_seen {c.get('last_seen')})")
    except Exception as e:
        rec("FAIL", f"'all' read failed: {e}")
        return
    print("        (Row-1 column headers cannot be checked through the API. Compare them by eye with the Sheet.)")

    # 3. authentication
    try:
        bad = post({"path": "ingest/camera", "key": "wrong-" + uuid.uuid4().hex, "camera_id": "PHASE0-TEST"})
        if bad.get("status") == 401:
            rec("PASS", "a wrong ingest key is rejected")
        else:
            rec("FAIL", f"a WRONG key was not rejected: {bad}. Anyone can write to your Sheet.")
    except Exception as e:
        rec("FAIL", f"auth probe failed: {e}")
    try:
        probe = post({"path": "violations/approve", "id": "PHASE0-NONEXISTENT", "reviewer": "phase0"})
        if probe.get("status") == 401:
            rec("PASS", "admin actions require ADMIN_TOKEN")
        elif probe.get("status") == 404:
            rec("WARN", "admin actions (approve/reject, create violation, unregister vehicle) need NO password. "
                        "Anyone with the URL can use them. Planned for Phase 8; keep the URL private until then.")
        else:
            rec("WARN", f"unexpected admin probe reply: {probe}")
    except Exception as e:
        rec("FAIL", f"admin probe failed: {e}")

    if args.no_write:
        print("        --no-write: skipped the ingest round trip")
        return

    # 4. real ingest round trip
    hb = post({"path": "ingest/camera", "key": KEY, "camera_id": "PHASE0-TEST", "location": "Phase 0 check"})
    if hb.get("ok"):
        rec("PASS", "camera heartbeat accepted with your key")
    elif hb.get("status") == 401:
        rec("FAIL", "Code.gs rejected your INGEST_KEY. The key in .env must equal INGEST_KEY in the DEPLOYED Code.gs "
                    "(after editing Code.gs you must Deploy > Manage deployments > edit > New version).")
        return
    else:
        rec("FAIL", f"heartbeat failed: {hb}")
        return
    tid = 900000 + random.randint(0, 99999)
    det = post({"path": "ingest/detection", "key": KEY, "camera_id": "PHASE0-TEST", "leanbot_label": "PHASE0-TEST",
                "leanbot_confidence": 0.99, "track_id": tid, "plate_number": "", "plate_text_source": "none"})
    did = det.get("detection_id")
    if det.get("status") != "saved" or not did:
        rec("FAIL", f"detection not saved: {det}")
        return
    rec("PASS", f"detection saved as {did}")
    time.sleep(2)
    seen = any(d.get("detection_id") == did for d in get("detections"))
    rec("PASS" if seen else "FAIL", "the test detection is readable back through the dashboard's read path"
        if seen else "saved but not readable back from the detections list")
    cams = {c.get("camera_id"): c.get("status") for c in get("cameras")}
    rec("PASS" if cams.get("PHASE0-TEST") == "Connected" else "FAIL",
        f"camera status for PHASE0-TEST is {cams.get('PHASE0-TEST')}")

    print("\nCleanup: open the Sheet and delete the PHASE0-TEST row in Cameras and in Detections.")


try:
    main()
except Exception as e:
    rec("FAIL", f"unexpected error: {e}")
print(f"\nSummary: {levels.count('PASS')} pass, {levels.count('WARN')} warn, {levels.count('FAIL')} fail")
sys.exit(1 if "FAIL" in levels else 0)
