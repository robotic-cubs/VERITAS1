"""Shows every camera Windows can open, one at a time, so you can see which number is the USB camera.
Close VERITAS (and Zoom/Teams) first, because a camera that is in use cannot be previewed.
Keys in the preview window:  any key = next camera,  q = stop."""
import os
import sys

import cv2 as cv
from dotenv import load_dotenv

import camera_utils

load_dotenv()
backend = (os.getenv("CAMERA_BACKEND", "") or camera_utils.default_backend()).lower()
names = camera_utils.device_names() if backend == "dshow" else None
print(f"Backend: {backend}")
if names is None and backend == "dshow":
    print("(Camera names are not available, so use the preview picture to tell them apart.)")
elif names:
    print("Names Windows reports: " + ", ".join(f"{i} = {n}" for i, n in enumerate(names)))

found, misses = [], 0
for idx in range(0, 8):
    cap = cv.VideoCapture(idx, camera_utils._API.get(backend, cv.CAP_ANY))
    frame = None
    if cap.isOpened():
        for _ in range(30):
            ok, f = cap.read()
            if ok and f is not None:
                frame = f
                break
    if frame is None:
        cap.release()
        misses += 1
        if misses >= 2 and found:
            break  # numbers are consecutive, so two empty slots in a row means we are done
        continue
    misses = 0
    h, w = frame.shape[:2]
    label = names[idx] if names and idx < len(names) else "name unknown"
    found.append(idx)
    print(f"Camera {idx}: {w}x{h}  ({label})  - showing preview, press a key for the next one")
    title = f"Camera {idx} - any key = next, q = stop"
    quit_now = False
    while True:
        ok, f = cap.read()
        if not ok:
            break
        cv.putText(f, f"CAMERA {idx}", (20, 60), cv.FONT_HERSHEY_SIMPLEX, 1.6, (0, 255, 0), 4)
        cv.putText(f, label, (20, 105), cv.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        cv.imshow(title, f)
        k = cv.waitKey(30) & 0xFF
        if k != 255:
            quit_now = (k == ord("q"))
            break
    cap.release()
    cv.destroyAllWindows()
    if quit_now:
        break

print()
if found:
    print(f"Cameras that work: {found}")
    print("Pick the one whose preview showed the USB camera's view, then put this in Camera Bridge\\.env:")
    print("    CAMERA=<that number>")
else:
    print("No working camera was found. Check the USB cable/port and that no other program is using the camera.")
sys.exit(0)
