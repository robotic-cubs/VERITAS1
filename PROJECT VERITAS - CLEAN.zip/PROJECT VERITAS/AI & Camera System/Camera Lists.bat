@echo off
title VERITAS - list cameras
cd /d "%~dp0..\Server & Connections\Camera Bridge"
if not exist .venv python -m venv .venv
call .venv\Scripts\activate
pip install -q -r requirements.txt
pip install -q pygrabber >nul 2>&1
echo.
echo Close VERITAS, Zoom, Teams and the Camera app first.
echo A preview window opens for each camera. Press any key for the next one, q to stop.
echo.
python list_cameras.py
echo.
pause
