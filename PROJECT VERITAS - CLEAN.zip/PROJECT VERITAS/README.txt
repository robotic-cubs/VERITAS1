PROJECT VERITAS - WHAT IS IN EACH FOLDER
(Status: STEP 2 of 4 - folders reorganized. The website is still the ORIGINAL
 HTML/JS/CSS site, kept working in "Website\Old Website (works now)".
 Step 3 turns it into React. Step 4 is final cleanup, testing and packaging.)

PROJECT VERITAS\
|
|-- AI & Camera System\
|     Camera Start.bat ........ ONE-CLICK START: starts the Backend and the AI camera program
|     Camera Lists.bat ........ shows which camera number is which (use it to pick CAMERA= in Camera Bridge\.env)
|     Models and Electron App\  the trained model (models\723image.pt), the desktop Electron app,
|                               plate reader (veritas_ocr.py) and the command-line tool (veritascli.py)
|
|-- Server & Connections\
|     Backend\ ................ FastAPI server (port 8000): receives AI events, feeds the dashboard
|     Camera Bridge\ .......... the AI camera program (veritas_bridge.py): reads the camera, runs 723image.pt,
|                               tracks objects, reads plates, sends results to the Backend (video on port 8001)
|     Google Apps Script\ ..... the server code you paste into Google Apps Script (Code, Portal, Ai, Agent, Chats, Records)
|     Shared Contracts\ ....... the shared event format used by Backend and Camera Bridge. Do not move.
|
|-- Website\
|     Old Website (works now)\  the complete original website:
|          admin.html ......... admin dashboard
|          portal\index.html .. public home page
|          portal\login.html .. login        portal\signup.html .. create account
|          portal\3-register.html .. vehicle registration
|          portal\app.html .... signed-in driver portal
|          portal\portal-admin.html .. portal administration
|          assets\ ............ the dashboard's CSS, JS, logo and traffic map
|          assets\js\veritas-config.js .. the ONE place the Apps Script URL is set
|
|-- Backups\ ................... put backup ZIPs here
|-- HOW TO RUN.txt ............. step-by-step instructions
|-- README.txt ................. this file

WHAT CHANGED IN STEP 2 (and why a few code lines were touched)
Old folder name                -> New folder name
veritas-cv-main                -> AI & Camera System\Models and Electron App
veritas-backend                -> Server & Connections\Backend
veritas-bridge                 -> Server & Connections\Camera Bridge
shared\contracts               -> Server & Connections\Shared Contracts
GS dont delete\ + portal\Portal.gs -> Server & Connections\Google Apps Script
admin.html, assets, portal, tools -> Website\Old Website (works now)
Camera Start.bat / Camera Lists.bat -> AI & Camera System

Because the folders moved, ONLY these path lines were updated. No detection, tracking, OCR,
model, API, authentication or signal logic was changed:
  AI & Camera System\Camera Start.bat ... folder locations at the top of the file (+ message texts)
  AI & Camera System\Camera Lists.bat ... folder location
  Server & Connections\Camera Bridge\veritas_bridge.py ... default model path and Backend .env path (+ message texts)
  Server & Connections\Camera Bridge\Test_723image.py ... default model path
  Server & Connections\Backend\event_hub.py ... path to Shared Contracts
  Server & Connections\Camera Bridge\camera_utils.py, phase0_check.py, list_cameras.py ... text of messages only
Google Apps Script files were NOT edited (only moved).

REMOVED IN STEP 2 (not needed): __pycache__ folders (Python cache, rebuilt automatically) and
logs\leanbot.exit (a leftover marker file; Camera Start.bat deletes and recreates it on every start).
A full deletion report comes with the final delivery.

Never put secrets (.env files) on public hosting. Backend\.env and Camera Bridge\.env stay on your computer / the Pi.
