# VERITAS Driver Portal

Pages (open these in the browser):

| File | Purpose |
|---|---|
| `index.html` | Public home page (hero, about, services, how it works, tracking, FAQ, contact) |
| `3-register.html` | Vehicle registration (needs a login; submits to the verification queue) |
| `track.html` | Track Registration (needs a login) |
| `admin-login.html` | Administrator Login (server-checked; goes to `../admin.html` or portal administration) |
| `privacy.html` / `terms.html` | Draft policy pages for the VERITAS team to review |
| `signup.html` / `login.html` / `forgot.html` | Account creation, sign-in, password reset |
| `app.html` | Signed-in driver portal (dashboard, vehicles, violations, payments, profile) |
| `portal-admin.html` | Portal administration (vehicle verification, payments, fines, disputes) |
| (`Portal.gs`) | Moved to `Server & Connections/Google Apps Script/Portal.gs` (paste into Apps Script; not loaded by the browser) |

Portal-only files are in `assets/`:

- `assets/css/` : `site.css` (public site, restyled to admin.html's dark glass / traffic-signal design), `chatbot.css` (help widget),  `veritas-ui.css` (copy of the admin dashboard styles, rebuilt by `../tools/sync-ui-css.py`), `portal.css` (driver pages), `portal-admin.css` (portal-admin page)
- `assets/js/` : `site.js` (public header/footer, logout dialog),  `api.js` (backend calls, sign-in session), `ui.js` (shared layout), `chatbot.js` (help assistant), `admin-links.js` (admin menu entries), `portal-admin.js` (helpers for portal-admin page)

Shared with the admin dashboard, in the project-level `../assets/`: `logos/VERITAS_LOGO.png` and `js/veritas-config.js` (the Apps Script URL is set there only).

`portal-admin.html` now uses the same navigation shell and stylesheets as `app.html` (`veritas-ui.css` + `portal.css` + skin); `assets/css/portal-admin.css` is no longer loaded by any page.
