/* VERITAS driver dashboard "mission control" layer (app.html). Adds: command bar (section, clock, status, account chip, quick "Register vehicle"),
   a mobile bottom dock, number count-up on the stat cards, and labels so tables turn into cards on phones.
   Loaded after the page's own script; purely additive. */
(function () {
  "use strict";
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var TITLES = { dashboard: "Dashboard", vehicles: "My Vehicles", violations: "Violations", payments: "Payments", profile: "Profile & Settings" };
  var I = {
    dashboard: '<path d="M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z"/>',
    vehicles: '<path d="M3 17v-4l2-5h14l2 5v4M3 17h18M7 17v2M17 17v2"/><circle cx="7.5" cy="13" r=".7"/><circle cx="16.5" cy="13" r=".7"/>',
    violations: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0zM12 9v4M12 17h.01"/>',
    payments: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18"/>',
    profile: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-7 8-7s8 3 8 7"/>',
  };
  var sec = function () {
    var n = (location.hash || "#/dashboard").slice(2).split("/")[0] || "dashboard";
    return n === "pay-return" || n === "pay-cancel" ? "payments" : n;
  };

  /* backdrop beam */
  var beam = document.createElement("div");
  beam.className = "hud-beam";
  beam.setAttribute("aria-hidden", "true");
  document.body.appendChild(beam);

  /* command bar */
  var bar = document.createElement("div");
  bar.id = "hud-bar";
  bar.innerHTML =
    '<div class="hb-crumb">VERITAS<i>/</i><b id="hb-sec">Dashboard</b></div>' +
    '<div class="hb-r"><button type="button" class="hb-add" id="hb-add">+ Register vehicle</button>' +
    '<span class="hb-clock" id="hb-clock" aria-hidden="true">--:--:--</span><span class="hb-live"><i></i>ONLINE</span>' +
    '<a class="hb-user" href="#/profile" title="Profile &amp; Settings"><b id="hb-av">&middot;</b><span id="hb-un">Driver</span></a></div>';
  document.body.appendChild(bar);
  $("#hb-add").addEventListener("click", function () {
    if (sec() !== "vehicles") location.hash = "#/vehicles";
    var n = 0, t = setInterval(function () {
      var b = $('main [data-act="vadd"]');
      if (b) { clearInterval(t); b.click(); } else if (++n > 40) clearInterval(t);
    }, 100);
  });

  /* bottom dock (phones) */
  var dock = document.createElement("nav");
  dock.id = "hud-dock";
  dock.setAttribute("aria-label", "Quick navigation");
  dock.innerHTML = Object.keys(TITLES).map(function (k) {
    var label = k === "vehicles" ? "Vehicles" : k === "profile" ? "Profile" : TITLES[k];
    return '<a href="#/' + k + '" data-k="' + k + '"><svg viewBox="0 0 24 24" aria-hidden="true">' + I[k] + "</svg><span>" + label + "</span></a>";
  }).join("");
  document.body.appendChild(dock);
  var dockCar = typeof CarNav !== "undefined" && document.body.animate ? CarNav.nav(dock) : null;

  function sync() {
    var k = sec();
    $("#hb-sec").textContent = TITLES[k] || "Dashboard";
    var cur = null;
    [].forEach.call(dock.querySelectorAll("a"), function (a) { var on = a.dataset.k === k; a.classList.toggle("on", on); if (on) cur = a; });
    if (dockCar) dockCar.to(cur);
  }
  addEventListener("hashchange", sync);
  sync();

  /* clock + account chip */
  function tick() {
    $("#hb-clock").textContent = new Date().toLocaleTimeString("en-GB");
    var u = typeof S !== "undefined" && S.user;
    if (u && u.full_name && !tick.done) {
      tick.done = true;
      var parts = u.full_name.trim().split(/\s+/);
      $("#hb-un").textContent = parts[0];
      $("#hb-av").textContent = ((parts[0] || "?")[0] + (parts.length > 1 ? parts[parts.length - 1][0] : "")).toUpperCase();
    }
  }
  tick();
  setInterval(tick, 1000);

  /* open the side menu by default on wide screens (the person can still unpin it; the choice is remembered) */
  try { if (localStorage.getItem("veritas_nav_pinned") === null && innerWidth >= 1100 && $("#pin")) $("#pin").click(); } catch (e) {}

  /* tables -> labelled cells (phones show each row as a card); count-up on stat numbers */
  function enhance() {
    [].forEach.call(document.querySelectorAll("main table:not([data-hud])"), function (t) {
      t.setAttribute("data-hud", "1");
      var heads = null;
      [].forEach.call(t.querySelectorAll("tr"), function (tr) {
        var ths = tr.querySelectorAll("th");
        if (ths.length && !heads) { heads = [].map.call(ths, function (h) { return h.textContent.trim(); }); tr.classList.add("hh"); return; }
        if (!heads) return;
        [].forEach.call(tr.children, function (td, i) { if (td.tagName === "TD") td.setAttribute("data-l", heads[i] || ""); });
      });
    });
    [].forEach.call(document.querySelectorAll(".pg.fade .card strong:not([data-cu])"), function (el) {
      el.setAttribute("data-cu", "1");
      var txt = el.textContent.trim();
      if (!/^\d+$/.test(txt) || matchMedia("(prefers-reduced-motion: reduce)").matches) return;
      var to = parseInt(txt, 10);
      if (!to) return;
      var t0 = performance.now(), dur = 800;
      (function step(now) {
        var p = Math.min(1, (now - t0) / dur);
        el.textContent = Math.round(to * (1 - Math.pow(1 - p, 3)));
        if (p < 1) requestAnimationFrame(step); else el.textContent = txt;
      })(t0);
    });
  }
  var raf = 0, main = $("main");
  if (main && window.MutationObserver) {
    new MutationObserver(function () { if (!raf) raf = requestAnimationFrame(function () { raf = 0; enhance(); }); }).observe(main, { childList: true, subtree: true });
  }
  enhance();
})();
