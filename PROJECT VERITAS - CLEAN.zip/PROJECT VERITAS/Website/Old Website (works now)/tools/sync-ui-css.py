"""Re-create portal/assets/css/veritas-ui.css from assets/css/admin.css (read-only on admin.css).
Run from the website folder:  python3 tools/sync-ui-css.py"""
import re, pathlib
root = pathlib.Path(__file__).resolve().parent.parent
css = (root / "assets/css/admin.css").read_text(encoding="utf8")
css = re.sub(r"\A/\*.*?\*/\n", "", css, count=1, flags=re.S).rstrip() + "\n"  # drop admin.css header comment
hdr = """/* VERITAS UI: the COMPLETE stylesheet of admin.html, copied verbatim by tools/sync-ui-css.py (assets/css/admin.css is the source of truth). */\n"""
(root / "portal/assets/css/veritas-ui.css").write_text(hdr + css, encoding="utf8")
print("veritas-ui.css rebuilt from admin.html:", len(css), "bytes")
